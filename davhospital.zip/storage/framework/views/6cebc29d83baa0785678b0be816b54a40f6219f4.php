<thead>
<tr>
    <th width="10%"><?php echo lang('opd_master.opd_number'); ?></th>
    <th width="10%"><?php echo lang('opd_master.visit_date'); ?></th>
    <th width="10%"><?php echo lang('patient.patient_code'); ?></th>
    <th width="10%"><?php echo lang('patient.first_name'); ?></th>
    <th width="8%"><?php echo lang('common.age'); ?></th>
    <th width="6%"><?php echo lang('common.gender'); ?></th>
    <th width="10%"><?php echo lang('common.mobile'); ?></th>
    <th class="text-center"><?php echo lang('common.action'); ?></th>
</tr>
</thead>
<tbody>
<?php
$index = 1;
$genderArr = lang('common.genderArray');
?>
<?php if(count($data) > 0): ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td> <?php echo $detail->opd_number; ?> </td>
            <td>
                <?php echo dateFormat('d.m.Y', $detail->visit_date); ?>

            </td>
            <td>
                <?php echo $detail->patient_code; ?>

            </td>
            <td>
                <?php echo $detail->first_name; ?>

            </td>
            <td><?php echo $detail->age; ?> <?php if($detail->age): ?> Years <?php endif; ?> </td>
            <td><?php if($detail->gender != ''): ?> <?php echo $genderArr[$detail->gender]; ?> <?php endif; ?> </td>
            <td><?php echo $detail->mobile; ?></td>
            <td class="text-center col-md-1">
                <a class="btn btn-xs btn-primary" href="<?php echo route('patient.opd-visit-edit', [$detail->id]); ?>"><i class="fa fa-edit"></i></a>
                <a href="<?php echo route('patient.opd-visit-print', $detail->id); ?>" class="btn btn-xs btn-success"> <i class="fa fa-eye"></i> </a>
                <a class="btn btn-xs btn-danger __drop" data-route="<?php echo route('patient.opd-visit-drop', [$detail->id]); ?>" data-message="<?php echo lang('messages.sure_delete', string_manip(lang('opd_master.opd_visit'))); ?>" href="javascript:void(0)"><i class="fa fa-times"></i></a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php if(count($data) < 1): ?>
    <tr>
        <td class="text-center" colspan="6"> <?php echo lang('messages.no_data_found'); ?> </td>
    </tr>
<?php endif; ?>
</tbody>