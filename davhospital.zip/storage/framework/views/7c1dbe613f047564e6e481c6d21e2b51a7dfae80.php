<?php $__env->startSection('content_header'); ?>
<section class="content-header">
    <h1>
        <?php echo lang('opd_master.opd_visit'); ?>

        <small><?php echo lang('common.view_heading', " Visit Detail"); ?></small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> <?php echo lang('common.back'); ?></a></li>
        <li class="active"><?php echo lang('opd_master.opd_visit'); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <!-- start: PAGE CONTENT -->
    <style>
        dose {
            color: blue;
            font-weight: bold;
            padding: 0 10px;
        }
        anu {
            color:red;
            font-weight: bold;
            padding: 0 10px;
        }
    </style>
    
    <?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-12 padding0">
            <!-- previous patient form id => patient-form -->
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading padding0">
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active">
                                <a href="#personal_tab" aria-controls="personal_tab" role="tab" data-toggle="tab">

                                    <i class="fa fa-external-link-square"></i>
                                    <?php echo lang('opd_master.opd_visit_detail'); ?>

                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <?php $linkCss = [asset('assets/css/bootstrap.min.css'),asset('assets/css/template.css')]; ?>
                            <a onclick="return reportPrint('p-report','<?php echo implode('|', $linkCss); ?>')" style="margin-right: 20px;" class="btn btn-success btn-sm pull-right marginbottom10">
                                &nbsp;<i class="fa fa-print"></i> <?php echo lang('common.print'); ?> &nbsp;&nbsp;
                            </a>
                            <a class="btn btn-sm btn-danger pull-right marginright10" href="<?php echo route('patient.ipd-entry', $result->id); ?>">
                              <i class='fa fa-bed'></i>   Convert to IPD
                            </a>
                            <a class="btn btn-sm btn-danger pull-right marginright10" href="<?php echo route('patient.opd-visit-edit', $result->id); ?>">
                                <i class='fa fa-edit'></i> Edit
                            </a>
                            

                            <div class="tab-content" id="p-report">
                                <div id="personal_tab" class="tab-pane fade in active">
                                    <div class="col-md-12">
                                        <div class="col-md-2">
                                            <img src='/assets/images/logo.png' style="max-height: 100px;float: left;margin-right:50px;">
                                        </div>
                                        <div class="col-md-10">
                                            <h3>M.C. D.A.V. Hospital</h3>
                                            <h5>Mahatama Hans Raj Marg, ,Jalandhar-144008</h5>
                                            <h5>Phone:0181-2253572,08559067185</h5>
                                        </div>
                                    </div>                                    



                                    <div class="col-md-12">
                                        <h2>
                                            Patient Detail
                                        </h2>
                                        
                                        <table class="table table-bordered">
                                            <tr>
                                                <td width="15%"><b><?php echo lang('patient.patient_code'); ?></b></td>
                                                <td><?php echo $result->patient_id; ?></td>

                                                <td width="15%"><b><?php echo lang('patient.first_name'); ?></b></td>
                                                <td><?php echo $result->first_name; ?></td>

                                                <td width="15%"><b><?php echo lang('patient.age'); ?></b></td>
                                                <td><?php echo $result->age; ?> / 
                                                    <?php $genderArr = lang('common.genderArray'); ?>
                                                <?php echo $genderArr[$result->gender]; ?></td>
                                            </tr>
                                            <tr>
                                                <td><b><?php echo lang('opd_master.visit_date'); ?></b></td>
                                                <td><?php echo dateFormat('d.m.Y', $result->visit_date); ?></td>
                                                <td><b><?php echo lang('department.department'); ?></b></td>
                                                <td> <?php echo $result->department; ?> </td>
                                                <td> <b><?php echo lang('doctor.doctor'); ?></b></td>
                                                <td> <?php echo $result->doctor; ?></td>
                                            </tr>
                                            <tr>
                                                <td><b><?php echo lang('patient.address'); ?></b></td>
                                                <td colspan="5"><?php echo $result->address; ?></td>
                                            </tr>
                                        </table>
                                    </div>

                                    <div class="col-md-12">
                                        <h2>
                                            1. Examination
                                        </h2>
                                        

                                        <table class="table table-bordered">
                                            <tr>
                                                <td width="15%"><b><?php echo lang('opd_master.complaints'); ?></b></td>
                                                <td colspan="5"><?php echo nl2br($result->complaints); ?></td>
                                            </tr>
                                            <tr>
                                                <td><b><?php echo lang('opd_master.pulse_rate'); ?></b></td>
                                                <td><?php echo nl2br($result->pulse_rate); ?></td>
                                                <td><b><?php echo lang('opd_master.blood_pressure'); ?></b></td>
                                                <td><?php echo nl2br($result->blood_pressure); ?></td>
                                                <td><b><?php echo lang('opd_master.temperature'); ?></b></td>
                                                <td><?php echo nl2br($result->temperature); ?></td>
                                            </tr>
                                            <tr>
                                                <td><b><?php echo lang('opd_master.examination'); ?></b></td>
                                                <td colspan="5"><?php echo nl2br(str_replace("###","\n",$result->examination)); ?></td>
                                            </tr>
                                            <tr>
                                                <td><b><?php echo lang('rog_type.rog_type'); ?></b></td>
                                                <td colspan="5"><?php echo $result->rog_type_text; ?></td>
                                            </tr>
                                        </table>

                                        
                                    </div>


                                    <div class="col-md-12">
                                        
                                        <h2>
                                            2. Investigations
                                        </h2>
                                        
                                        <div class="form-group">
                                            <?php echo Form::label('test_ids', lang('test.tests'), array('class' => 'col-sm-2 control-label')); ?>

                                            <div class="col-sm-5">
                                                <?php echo $result->tests; ?>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        
                                        <h2>
                                            3. Procedures
                                        </h2>
                                        
                                        <div class="col-md-8 clearfix">
                                            <div class="clearfix place-template">
                                                <table class="table table-bordered">
                                                    <tr>
                                                        <th><b><?php echo lang('opd_master.procedure_date'); ?></b></th>
                                                        <th><b><?php echo lang('opd_master.procedure'); ?></b></th>
                                                        <th><b><?php echo lang('opd_master.medicine'); ?></b></th>
                                                        <th><b><?php echo lang('opd_master.dose'); ?></b></th>
                                                        <th><b><?php echo lang('opd_master.timing'); ?></b></th>
                                                        <th><b><?php echo lang('opd_master.remarks'); ?></b></th>
                                                    </tr>
                                                    <?php $__currentLoopData = $pMedicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo dateFormat('d.m.Y', $detail->procedure_date); ?></td>
                                                            <td><?php echo $detail->procedure; ?></td>
                                                            <td><?php echo $detail->medicine; ?></td>
                                                            <td><?php echo $detail->dose; ?></td>
                                                            <td><?php echo $detail->timing; ?></td>
                                                            <td><?php echo $detail->remarks; ?></td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </table>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        
                                        <h2>
                                            4. Medications
                                        </h2>
                                        
                                        <div class="col-md-8 clearfix">

                                            <table class="table table-bordered">
                                                <tr>
                                                    <th><b><?php echo lang('opd_master.medicine'); ?></b></th>
                                                    <th><b><?php echo lang('opd_master.dose'); ?></b></th>
                                                    <th><b><?php echo lang('opd_master.dose_unit'); ?></b></th>
                                                    <th><b><?php echo lang('opd_master.timing'); ?></b></th>
                                                    <th><b><?php echo lang('opd_master.remarks'); ?></b></th>
                                                </tr>
                                                <?php $__currentLoopData = $mMedicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo $detail->medicine; ?></td>
                                                        <td><?php echo $detail->dose; ?></td>
                                                        <td><?php echo $detail->dose_unit; ?></td>
                                                        <td><?php echo $detail->timing; ?></td>
                                                        <td><?php echo $detail->remarks; ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end: TEXT FIELDS PANEL -->
            </div>
        </div>    
    </div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>