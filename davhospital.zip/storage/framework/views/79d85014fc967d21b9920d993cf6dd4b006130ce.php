<?php $__env->startSection('content_header'); ?>
    <section class="content-header">
        <h1>
            <?php echo lang('doctor.doctor_detail'); ?>

            <small><?php echo lang('common.add_record'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> <?php echo lang('common.back'); ?></a></li>
            <li><a href="<?php echo route('doctor.index'); ?>"><?php echo lang('doctor.doctors'); ?></a></li>
            <li class="active"><?php echo lang('common.create_heading', lang('doctor.doctor')); ?></li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
        <!-- start: PAGE CONTENT -->

        

        <?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="row">
            <div class="col-md-12 padding0">
                <?php echo Form::open(array('method' => 'POST', 'route' => array('doctor.store'), 'id' => 'ajaxSave', 'class' => 'form-horizontal')); ?>


                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-external-link-square"></i> &nbsp;
                            <?php echo lang('doctor.doctor_detail'); ?>

                        </div>
                        <div class="panel-body">
                            <div class="row">

                                <div class="col-md-6">

                                    <div class="form-group required">
                                        <?php echo Form::label('registration_no', lang('doctor.registration_no'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::text('registration_no', $doctorCode, array('class'=>'form-control', 'readonly', 'placeholder' => 'Registration No')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        <?php echo Form::label('association', lang('doctor.association'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::select('association', $associationName, null, array('class' => 'form-control', 'placeholder' => 'Association')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group addassociation required" style="display:none">
                                        <?php echo Form::label('association', lang('doctor.specify'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::text('specifyassociation', null, array('class' => 'form-control', 'placeholder' => 'Please Mention')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        <?php echo Form::label('name', lang('common.name'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::text('name', null, array('class' => 'form-control', 'placeholder' => 'Full Name')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        <?php echo Form::label('contact', lang('doctor.contact'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <div class="input-group">
                                                <span class="input-group-addon"><?php echo lang('common.isd_code_india'); ?></span>
                                                <div>
                                                    <?php echo Form::text('contact', null, array('class' => 'form-control', 'maxlength' => 10,'placeholder' => 'Contact No')); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        <?php echo Form::label('email', lang('common.email'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::text('email', null, array('class' => 'form-control', 'placeholder' => 'example@gmail.com')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        <?php echo Form::label('gender', lang('common.gender'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::select('gender', $gender, null, array('class' => 'form-control')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <?php echo Form::label('date_of_birth', lang('doctor.date_of_birth'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::text('date_of_birth', null, array('class' => 'form-control date-picker', 'readonly' => true, 'placeholder' => 'Date of birth')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <?php echo Form::label('blood_group', lang('common.blood_group'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::select('blood_group', $bloodGroup, null, array('class' => 'form-control')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <?php echo Form::label('marital_status', lang('doctor.marital_status'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::select('marital_status', $maritalStatus, null, array('class' => 'form-control')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        <?php echo Form::label('address', lang('doctor.address'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::textarea('address', null, array('class' => 'form-control', 'id' => 'address', 'size' => '5x4', 'placeholder' => 'Address')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        <?php echo Form::label('fee', lang('doctor.fee'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::text('consultation_fee', null, array('class' => 'form-control', 'placeholder' => 'Consultant Fee', 'id' => 'consultation_fee')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <?php echo Form::label('room_no', lang('doctor.room_no'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::select('room_id', $roomName, null, array('class' => 'form-control')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group hide">
                                        <?php echo Form::label('image', lang('doctor.doctor_image'), array('class' => 'col-sm-3 control-label paddingleft0')); ?>


                                        <div class="col-sm-8 imageDiv">
                                            <img class='showImage img-responsive thumbnail' src="" alt="">
                                            <?php echo Form::label('image', lang('common.choose_image'),  array('class' => 'col-sm-4 control-label', 'id' => 'img-label')); ?>

                                            <?php echo Form::File('image', null); ?>

                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        <?php echo Form::label('status', lang('common.active') . '&nbsp;', array('class' => 'col-sm-3 control-label')); ?>

                                        <div class="col-sm-3 margintop8">
                                            <?php echo Form::checkbox('status', '1', true); ?>

                                        </div>
                                    </div>

                                </div>

                                <div class="col-md-6">

                                    <div class="form-group required">
                                        <?php echo Form::label('designation', lang('doctor.designation'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::select('designation_id', $designationName, null, array('class' => 'form-control', 'id' => 'designation_id')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        <?php echo Form::label('specialization', lang('doctor.specialization'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::select('specialization_id', $specializationName, null, array('class'=>'form-control', 'id' => 'specialization_id')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        <?php echo Form::label('department', lang('doctor.department'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::select('department_id', $departmentName, null, array('class' => 'form-control', 'id' => 'department_id')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <?php echo Form::label('qualification', lang('doctor.qualification'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::textarea('qualification', null, array('class' => 'form-control', 'department' => '5x6', 'cols' => 50, 'rows' => 4, 'placeholder' => 'Qualification')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <?php echo Form::label('joining_date', lang('doctor.date_of_joining'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::text('joining_date', null, array('class' => 'form-control date-picker', 'readonly' => true, 'placeholder' => 'Date of Joining')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <?php echo Form::label('city', lang('doctor.city'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::text('city', null, array('class'=>'form-control', 'placeholder' => 'City')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <?php echo Form::label('state', lang('doctor.state'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::text('state', null, array('class'=>'form-control', 'placeholder' => 'State')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <?php echo Form::label('country', lang('doctor.country'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::text('country', null, array('class'=>'form-control', 'placeholder' => 'Country')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <?php echo Form::label('zipcode', lang('doctor.zip_code'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::text('zipcode', null, array('class'=>'form-control', 'maxlength'=> 6, 'placeholder' => 'Zip Code')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <?php echo Form::label('days', lang('doctor.days'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::select('days[]', $days, null, array('class' => 'form-control select2', 'multiple' => true, 'placeholder' => '-- Select Days --')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <?php echo Form::label('duty', lang('doctor.duty'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::select('duty_type[]', $dutyType, null, array('class' => 'form-control select2', 'multiple' => true, 'placeholder' => '-- Select Duty Type --')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group newDiv">

                                        <?php echo Form::label('in_time', lang('doctor.morning'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-3">
                                            <?php echo Form::text('in_time', null, array('class' => 'form-control time-picker', 'placeholder' => 'In Time')); ?>

                                        </div>

                                        <?php echo Form::label('out_time', lang('doctor.morning'), array('class' => 'col-sm-2 control-label')); ?>


                                        <div class="col-sm-3">
                                            <?php echo Form::text('out_time', null, array('class' => 'form-control time-picker', 'placeholder' => 'Out Time')); ?>

                                        </div>

                                        <div class="form-group addButton hidden ">
                                            <?php echo Form::button(lang('common.add'), array('class' => 'btn btn-primary')); ?>

                                        </div>

                                    </div>

                                    <div class="form-group">

                                        <?php echo Form::label('eve_in_time', lang('doctor.evening'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-3">
                                            <?php echo Form::text('eve_in_time', null, array('class' => 'form-control time-picker', 'placeholder' => 'In Time')); ?>

                                        </div>

                                        <?php echo Form::label('eve_out_time', lang('doctor.evening'), array('class' => 'col-sm-2 control-label')); ?>


                                        <div class="col-sm-3">
                                            <?php echo Form::text('eve_out_time', null, array('class' => 'form-control time-picker', 'placeholder' => 'Out Time')); ?>

                                        </div>

                                    </div>



                                </div>
                                </div>
                                <div class="col-sm-11 margintop20 clearfix text-center">
                                    <div class="form-group">
                                        <?php echo Form::submit(lang('common.save'), array('class' => 'btn btn-primary btn-lg')); ?>

                                    </div>
                                </div>
                            </div>
                        </div>

                    <!-- end: TEXT FIELDS PANEL -->
                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
    <!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $(document).on('change', '#association', function() {
                var value = $(this).val();
                if(value == 3) {
                    $('input[name="specifyassociation"]').val('');
                    $(".addassociation").show();
                }else {
                    $(".addassociation").hide();
                }
            });
        });

        $(document).ready(function() {
            var max_fields      = 2; //maximum input boxes allowed
            var wrapper         = $(".newDiv"); //Fields wrapper
            var add_button      = $(".addButton"); //Add button ID

            var x = 1; //initlal text box count
            $(add_button).click(function(e){ //on add input button click
                e.preventDefault();
                if(x < max_fields){ //max input box allowed
                    x++; //text box increment
                    $(wrapper).append('<div class="col-sm-12">IN TIME : <input type="text" name="in_time[]" class="bootstrap-timepicker"> ' +
                            'OUT TIME :  <input type="text" name="out_time[]">' +
                            '<a href="#" class="remove_field"> <b> X </b> </a>' +
                            '</div>'); //add input box
                }
            });



            $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
                e.preventDefault(); $(this).parent('div').remove(); x--;
            })
        });


            $('#image').on('change',function(){
                var filename = 'No File Selected';
                if($(this)[0].files[0])
                {
                    filename = $(this)[0].files[0]['name'];

                    var fileExtension = filename.substr(filename.lastIndexOf('.') + 1);
                    fileExtension = fileExtension.toLowerCase();
                    var validExtension = ['jpg', 'jpeg', 'png', 'gif'];

                    if($.inArray(fileExtension, validExtension) >= 0){
                        $('#img-label').css('border', '1px dashed #ccc');
                    }else {
                        filename = 'No File Selected';
                        $('#member_image').val('');
                        $('#img-label').css('border', '1px dashed red');
                        alert('Please select an image');
                    }
                }
                readURL(this);
                $('#img-label').text(filename);
            });

            function readURL(input) {

                var html = '', src = '', alt = '';
                if (input.files && input.files[0]) {
                    var reader = new FileReader();

                    $(".backDrop").fadeIn( 100, "linear" );
                    $(".loader").fadeIn( 100, "linear" );

                    reader.onload = function (e) {
                        src = e.target.result;
                        $('.showImage').attr('src', src).attr('alt', alt);

                        setTimeout(function(){
                            $(".backDrop").fadeOut( 100, "linear" );
                            $(".loader").fadeOut( 100, "linear" );
                        }, 200);
                    };
                    reader.readAsDataURL(input.files[0]);
                }else{
                    $('.showImage').attr('src', src).attr('alt', alt);
                }
            }
    </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>