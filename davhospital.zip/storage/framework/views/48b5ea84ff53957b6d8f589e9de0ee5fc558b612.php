<?php $__env->startSection('content_header'); ?>
<section class="content-header">
    <h1>
        <?php echo lang('ipd_master.ipd_visit'); ?>

        <small><?php echo lang('common.view_heading', " Discharge Detail"); ?></small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> <?php echo lang('common.back'); ?></a></li>
        <li class="active"><?php echo lang('ipd_master.ipd_visit'); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <!-- start: PAGE CONTENT -->
    
    
    <?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-12 padding0">
            <!-- previous patient form id => patient-form -->
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading padding0">
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active">
                                <a href="#personal_tab" aria-controls="personal_tab" role="tab" data-toggle="tab">

                                    <i class="fa fa-external-link-square"></i>
                                    <?php echo lang('ipd_master.ipd_visit_detail'); ?>

                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <div class="row">

                            <div class="tab-content" id="p-report">
                                <?php echo Form::open(array('method' => 'POST', 'route' => array('patient.ipd-discharge', $result->id), 'id' => 'ajaxSave', 'class' => 'form-horizontal')); ?>

                                    <div id="personal_tab" class="tab-pane fade in active">
                                        <?php
                                            $genderArr = lang('common.genderArray');
                                            $bloodGroupArr = lang('common.bloodGroupArr');
                                        ?>
                                        <div class="col-md-12">
                                            <h1 class="h-size">
                                                Patient Detail
                                            </h1>
                                            <hr/>
                                            <table class="table table-bordered">
                                                <tr>
                                                    <td width="15%"><b><?php echo lang('patient.first_name'); ?></b></td>
                                                    <td width="18%"><?php echo $patient->first_name; ?></td>
                                                    <td width="15%">
                                                        <b>
                                                            <?php echo lang('doctor.doctor'); ?>

                                                        </b>
                                                    </td>
                                                    <td width="20%">
                                                        <?php echo $result->doctor; ?>

                                                    </td>
                                                    <td width="15%"><b><?php echo lang('ipd_master.ipd_number'); ?></b></td>
                                                    <td>
                                                        <?php echo "IP".$result->ipd_number; ?>

                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><b><?php echo lang('patient.gender'); ?></b></td>
                                                    <td><?php if($patient->gender != ''): ?> <?php echo $genderArr[$patient->gender]; ?> <?php endif; ?></td>
                                                    <td><b><?php echo lang('department.department'); ?></b></td>
                                                    <td>
                                                        <?php echo $result->department; ?>

                                                    </td>
                                                    <td><b><?php echo lang('ipd_master.visit_date'); ?></b></td>
                                                    <td>
                                                        <?php echo dateFormat('d.m.Y', $result->admission_date); ?>

                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><b><?php echo lang('patient.age'); ?></b></td>
                                                    <td><?php echo $patient->age; ?> <?php if($patient->age): ?> Years <?php endif; ?> </td>
                                                    <td><b><?php echo lang('ward.ward'); ?></b></td>
                                                    <td>
                                                        <?php echo $result->ward; ?>

                                                    </td>
                                                    <td>
                                                        <div class="required">
                                                            <?php echo Form::label('doctor', lang('ipd_master.discharge_date'), array('class' => 'control-label')); ?>

                                                        </div>
                                                    </td>
                                                    <td><?php echo Form::text('discharge_date', date('d-m-Y'), array('class' => 'form-control date-future')); ?></td>
                                                </tr>
                                                <tr>
                                                    <td><b><?php echo lang('patient.blood_group'); ?></b></td>
                                                    <td><?php echo $patient->blood_group; ?></td>
                                                    <td><b><?php echo lang('bed_master.bed_master'); ?> No</b></td>
                                                    <td>
                                                        <?php echo $result->bed; ?>

                                                    </td>
                                                    <td>
                                                        <div class="required">
                                                            <?php echo Form::label('doctor', lang('ipd_master.discharge_type'), array('class' => 'control-label')); ?>

                                                        </div>
                                                    </td>
                                                    <td><?php echo Form::select('discharge_type', dischargeType(), null, array('class' => 'form-control select2 padding0', 'id' => 'discharge_type')); ?></td>
                                                </tr>
                                                <tr>
                                                    <td><b><?php echo lang('patient.mobile'); ?></b></td>
                                                    <td><?php echo $patient->mobile; ?></td>
                                                    <td>&nbsp;</td>
                                                    <td> &nbsp;</td>
                                                    <td>
                                                        <div class="required">
                                                            <?php echo Form::label('doctor', lang('ipd_master.discharged_doctor'), array('class' => 'control-label')); ?>

                                                        </div>
                                                        <b></b>
                                                    </td>
                                                    <td width="20%"><?php echo Form::select('doctor', $doctors, null, array('class' => 'form-control select2 padding0', 'id' => 'doctor')); ?> </td>
                                                </tr>
                                            </table>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group clearfix">
                                                <?php echo Form::label('discharge_summary', lang('ipd_master.discharge_summary'), array('class' => 'col-sm-2 control-label')); ?>

                                                <div class="col-sm-8">
                                                    <?php echo Form::textarea('discharge_summary', $result->present_illness, array('class' => 'form-control', 'placeholder' => lang('ipd_master.discharge_summary'), 'size' => '4x6')); ?>

                                                </div>
                                            </div>

                                            <div class="form-group clearfix">
                                                <?php echo Form::label('treatment_given', lang('ipd_master.treatment_given'), array('class' => 'col-sm-2 control-label')); ?>

                                                <div class="col-sm-8">
                                                    <?php echo Form::textarea('treatment_given', null, array('class' => 'form-control', 'placeholder' => lang('ipd_master.treatment_given'), 'size' => '4x6')); ?>

                                                </div>
                                            </div>

                                            <div class="form-group clearfix">
                                                <?php echo Form::label('treatment_advised', lang('ipd_master.treatment_advised'), array('class' => 'col-sm-2 control-label')); ?>

                                                <div class="col-sm-8">
                                                    <?php echo Form::textarea('treatment_advised', null, array('class' => 'form-control', 'placeholder' => lang('ipd_master.treatment_advised'), 'size' => '4x6')); ?>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-11 text-center">
                                            <div class="form-group">
                                                <?php echo Form::submit(lang('common.save'), array('class' => 'btn btn-primary btn-lg')); ?>

                                            </div>
                                        </div>
                                    </div>
                                <?php echo Form::close(); ?>

                            </div>
                        </div>
                    </div>
                </div>
                <!-- end: TEXT FIELDS PANEL -->
            </div>
        </div>    
    </div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>