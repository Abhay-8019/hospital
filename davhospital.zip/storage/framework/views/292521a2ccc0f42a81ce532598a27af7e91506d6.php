<table width="100%">
    <tr class="no-hover">
        <td align="center">
            <h3 style="text-align:center;margin-bottom: 0; margin-top: 0; text-transform: uppercase; font-size: 2.6em; font-weight: 900;"> M.C. D.A.V Hospital </h3>
            <div style="text-align: center; font-size: 1.2em;margin: 0;">
                Mahatma Hans Raj Marg, Dayanand Nagar,
                Jalandhar, Punjab - 144008 <br>
                Phone: 0181-2253572, 08559067185
            </div>
        </td>
    </tr>
</table>