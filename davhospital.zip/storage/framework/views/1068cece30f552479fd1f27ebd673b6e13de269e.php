<?php $__env->startSection('content_header'); ?>
	<section class="content-header">
		<h1>
			<?php echo lang('opd_master.opd_visits'); ?>

			<small><?php echo lang('common.list_record'); ?></small>
		</h1>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="page-wrapper">

	
    <?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="row">
      <div class="col-md-12">
		<!-- start: BASIC TABLE PANEL -->
		<div class="panel panel-default" style="position: static;">
			<div class="panel-heading">
				<i class="fa fa-external-link-square"></i> &nbsp;
				<?php echo lang('opd_master.list_opd_visits'); ?>

			</div>
			<div class="panel-body">
				<div class="col-md-3 text-right pull-right padding0 marginbottom10">
					<?php echo lang('common.per_page'); ?>: <?php echo Form::select('name', ['20' => '20', '40' => '40', '100' => '100', '200' => '200', '300' => '300'], '20', ['id' => 'per-page']); ?>

				</div>
				<div class="col-md-3 padding0 marginbottom10">
					<?php echo Form::hidden('page', 'search'); ?>

					<?php echo Form::hidden('_token', csrf_token()); ?>

					<?php echo Form::text('name', null, array('class' => 'form-control live-search', 'placeholder' => 'Search Patient')); ?>

				</div>
				<?php $route = \Route::currentRouteName(); ?>
				<table id="paginate-load" data-route="<?php echo e(route($route)); ?>" class="table table-hover margin0 col-md-12 padding0">
				</table>
			</div>
		</div>
		<!-- end: BASIC TABLE PANEL -->
	   </div>	
	</div>	
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>