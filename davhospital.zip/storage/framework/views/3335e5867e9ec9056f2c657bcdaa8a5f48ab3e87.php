<?php $__env->startSection('content_header'); ?>
    <section class="content-header">
        <h1>
            <?php echo lang('financial_year.financial_year_detail'); ?>

            <small><?php echo lang('common.add_record'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> <?php echo lang('common.back'); ?></a></li>
            <li><a href="<?php echo route('financial-year.index'); ?>"><?php echo lang('financial_year.financial_year'); ?></a></li>
            <li class="active"><?php echo lang('common.create_heading', lang('financial_year.financial_year')); ?></li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- start: PAGE HEADER -->
<?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row clearfix">
    <div class="col-md-12">
    <!-- start: BASIC TABLE PANEL -->
    <?php echo Form::open(array('method' => 'POST', 'route' => array('financial-year.store'), 'id' => 'ajaxSave', 'class' => 'form-horizontal')); ?>

    <div class="panel panel-default">
        <div class="panel-heading">
            <i class="fa fa-external-link-square"></i> &nbsp;
            <?php echo lang('financial_year.financial_year'); ?>

        </div>
        <div class="panel-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <?php echo Form::label('name', lang('common.name'), array('class' => 'col-sm-3 control-label')); ?>

                        <div class="col-sm-8">
                            <?php echo Form::text('name', null, array('class' => 'form-control')); ?>

                        </div>
                    </div>

                    <div class="form-group">
                        <?php echo Form::label('from_date', lang('financial_year.from_date'), array('class' => 'col-sm-3 control-label')); ?>

                        <div class="col-sm-8">
                            <?php echo Form::text('from_date', null, array('class' => 'form-control date-picker')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('to_date', lang('financial_year.to_date'), array('class' => 'col-sm-3 control-label')); ?>

                        <div class="col-sm-8">
                            <?php echo Form::text('to_date', null, array('class' => 'form-control date-picker')); ?>

                        </div>
                    </div>
                    <div class="form-group hidden">
                        <?php echo Form::label('status', lang('common.active') . '&nbsp;', array('class' => 'col-sm-3 col-xs-3 control-label')); ?>

                        <div class="col-sm-5 col-xs-5 margintop5">
                            <?php echo Form::checkbox('status', '1', true); ?>

                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-12 margintop20 clearfix text-center">
                <div class="form-group">
                    <?php echo Form::submit(lang('common.save'), array('class' => 'btn btn-primary btn-lg')); ?>

                </div>
            </div>

        </div>
    </div>
    <!-- end: TEXT FIELDS PANEL -->
    <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>