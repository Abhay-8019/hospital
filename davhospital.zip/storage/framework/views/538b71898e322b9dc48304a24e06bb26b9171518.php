<thead>
<tr>
    <th width="7%" class="text-center"><?php echo lang('common.id'); ?></th>
    <th width="22%"><?php echo lang('event.event_name'); ?></th>
    <th><?php echo lang('event.event_start'); ?> / <?php echo lang('event.event_end'); ?></th>
    <th><?php echo lang('event.is_holiday'); ?></th>
    <th><?php echo lang('event.event_type'); ?></th>
    <?php if(hasMenuRoute('add_events.edit')): ?>
        <th class="text-center"> <?php echo lang('common.status'); ?> </th>
        <th class="text-center"><?php echo lang('common.action'); ?></th>
    <?php endif; ?>
</tr>
</thead>
<tbody>
<?php
    $index = 1;  $faCheckIcon = "<i class='fa fa-check'>&nbsp;</i>";
    $eventFor = lang('common.event_for');
?>
<?php if(isset($data) && count($data) > 0): ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="order_<?php echo e($detail->id); ?>">
            <td class="text-center"><?php echo pageIndex($index++, $page, $perPage); ?></td>
            <td>
                <?php if(hasMenuRoute('add_events.edit')): ?>
                    <a href="<?php echo route('add_events.edit', [$detail->id]); ?>">
                        <?php echo $detail->event_name.' ['. $detail->event_code .']'; ?>

                    </a>
                <?php else: ?>
                    <?php echo $detail->event_name.' ['. $detail->event_code .']'; ?>

                <?php endif; ?>
            </td>
            <td><?php echo convertToLocal($detail->event_start, 'd-m-Y'); ?> / <?php echo convertToLocal($detail->event_end, 'd-m-Y'); ?></td>
            <td><?php echo ($detail->is_holiday)? $faCheckIcon : '--'; ?></td>
            <td><?php echo ($detail->event_type)? $detail->event_type : '--'; ?></td>
            <?php if(hasMenuRoute('add_events.edit')): ?>
                <td width="7%" class="text-center">
                    <a href="javascript:void(0);" class="toggle-status" data-message="<?php echo lang('messages.change_status'); ?>" data-route="<?php echo route('add_events.toggle', $detail->id); ?>">
                        <?php echo Html::image('assets/images/' . $detail->status . '.gif'); ?>

                    </a>
                </td>
                <td class="text-center col-md-1">
                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('add_events.edit', [$detail->id])); ?>"><i class="fa fa-edit"></i></a>
                </td>
            <?php endif; ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <tr class="margintop10">
        <td colspan="9">
            <?php echo paginationControls($page, $total, $perPage); ?>

        </td>
    </tr>
<?php else: ?>
    <tr>
        <td class="text-center" colspan="9"> <?php echo lang('messages.no_data_found'); ?> </td>
    </tr>
<?php endif; ?>
</tbody>