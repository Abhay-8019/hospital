<?php $__env->startSection('content_header'); ?>
	<section class="content-header">
		<div class="pull-right">
			<a class="btn btn-danger btn-xs" href="<?php echo route('products.create'); ?>">
				<i class="fa fa-plus-circle"></i> <?php echo lang('common.create_heading', lang('products.product')); ?>

			</a>
		</div>
		<h1>
			<?php echo lang('products.products'); ?>

			<small><?php echo lang('common.list_record'); ?></small>
		</h1>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	
    <?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="col-md-12 padding0">
		<?php echo Form::open(array('method' => 'POST',
			'route' => array('products.paginate'), 'id' => 'ajaxForm')); ?>

		<div class="row">
			<div class="col-sm-3">
				<div class="form-group">
					<?php echo Form::label('product_group', lang('products.product_group'), array('class' => 'control-label')); ?>

					<?php echo Form::select('product_group', $groups, (isset($inputs['product_group'])) ? $inputs['product_group'] : '', array('class' => 'form-control padding0 select2')); ?>

				</div>
			</div>

			<div class="col-sm-3 margintop20">
				<div class="form-group">
					<?php echo Form::hidden('form-search', 1); ?>

					<?php echo Form::submit(lang('common.filter'), array('class' => 'btn btn-primary')); ?>

					<a href="<?php echo route('products.index'); ?>" class="btn btn-primary"> <?php echo lang('common.reset_filter'); ?></a>
				</div>
			</div>
		</div>
		<?php echo Form::close(); ?>

	</div>
    <div class="row">
    	<div class="col-md-12">
			<!-- start: BASIC TABLE PANEL -->
			<div class="panel panel-default" style="position: static;">
				<div class="panel-heading">
					<i class="fa fa-external-link-square"></i> &nbsp;
					<?php echo lang('products.product_list'); ?>

					<div class="pull-right hidden">
						<a href="<?php echo route('products.upload-excel'); ?>" class="btn btn-success btn-xs" title="Import Excel"><i class="fa fa-cloud-upload"></i></a>
						<a href="<?php echo route('products.generate-excel'); ?>" class="btn btn-success btn-xs" title="Export Excel"><i class="fa fa-cloud-download"></i></a>
					</div>
				</div>
				<div class="panel-body">
					<form action="<?php echo e(route('products.action')); ?>" method="post">
					<div class="col-md-3 text-right pull-right padding0 marginbottom10">
						<?php echo lang('common.per_page'); ?>: <?php echo Form::select('name', ['20' => '20', '40' => '40', '100' => '100', '200' => '200', '300' => '300'], '20', ['id' => 'per-page']); ?>

					</div>
					<div class="col-md-3 padding0 marginbottom10">
						<?php echo Form::hidden('page', 'search'); ?>

						<?php echo Form::hidden('page-no', session('p_page', 1), ['id' => 'page-no']); ?>

						<?php echo Form::hidden('_token', csrf_token()); ?>

						<?php echo Form::text('keyword', null, array('class' => 'form-control  live-search', 'placeholder' => lang('common.search_heading', lang('products.product')))); ?>

					</div>
					<table id="paginate-load" data-route="<?php echo e(route('products.paginate')); ?>" class="table table-responsive table-hover clearfix margin0 col-md-12 padding0">
					</table>
					</form>
				</div>
			</div>
			<!-- end: BASIC TABLE PANEL -->
		</div>
	</div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>