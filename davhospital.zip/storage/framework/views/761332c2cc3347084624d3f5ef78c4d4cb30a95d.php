<thead>
<tr>
    <th width="7%" class="text-center"><?php echo lang('common.id'); ?></th>
    
    <th width="15%"><?php echo lang('common.name').' ['. lang('staff.register_number').']'; ?></th>
    
    <th><?php echo lang('common.gender'); ?></th>
    <th><?php echo lang('common.email'); ?></th>
    <th><?php echo lang('common.contact_number'); ?></th>
    <th><?php echo lang('staff.department').' / '.lang('staff.designation'); ?></th>
    <th><?php echo lang('staff.do_joining').' / '.lang('staff.do_retirement'); ?></th>
    <?php if(hasMenuRoute('staff.edit')): ?>
     <th class="text-center"> <?php echo lang('common.status'); ?> </th>
     <th class="text-center"><?php echo lang('common.action'); ?></th>
    <?php endif; ?>
</tr>
</thead>
<tbody>
<?php
    $index = 1;
    $genderArr = lang('common.genderArray');
    $bloodGroupArr = lang('common.bloodGroupArr');

    $filePath = \Config::get('constants.UPLOADS');
    $folder = ROOT . $filePath;
?>
<?php if(isset($data) && count($data) > 0): ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $nameAndNumber = ($detail->last_name)? $detail->first_name.' '.$detail->last_name.' ['.$detail->register_number.']' : $detail->first_name . ' ['. $detail->register_number.']';
//            $bloodGroup = ($detail->blood_group != '')? "&nbsp; - &nbsp;".$bloodGroupArr[$detail->blood_group] : '--';
            $gender = ($detail->gender != '')? $genderArr[$detail->gender] : '--';
            $dob = dateFormat('d-m-Y', $detail->dob);
            $doRetirement = ($detail->do_retirement)? "&nbsp; / &nbsp;".convertToLocal($detail->do_retirement, 'd-m-Y') : ' / -- ';
        ?>

        <tr id="order_<?php echo e($detail->id); ?>">
            <td class="text-center"><?php echo pageIndex($index++, $page, $perPage); ?></td>
            <td class="text-center">
                <?php if(hasMenuRoute('staff.edit')): ?>
                    <a href="<?php echo route('staff.edit', [$detail->id]); ?>">
                        <?php if(file_exists($folder . $detail->image) && $detail->image): ?>
                            <?php echo Html::image($filePath.$detail->image, getFileName($detail->image), ['class' => 'img-responsive img-circle margin0-auto', 'width' => '60']); ?>

                        <?php endif; ?>
                        <?php echo $nameAndNumber; ?>

                    </a>
                <?php else: ?>
                    <?php if(file_exists($folder . $detail->image) && $detail->image): ?>
                        <?php echo Html::image($filePath.$detail->image, getFileName($detail->image), ['class' => 'img-responsive img-circle margin0-auto', 'width' => '60']); ?>

                    <?php endif; ?>
                    <?php echo $nameAndNumber; ?>

                <?php endif; ?>
            </td>
            
            <td><?php echo $gender; ?></td>
            <td><?php echo $detail->email; ?></td>
            <td><?php echo $detail->contact_number; ?></td>
            <td><?php echo $detail->department_name."&nbsp; /<br/>".$detail->designation_name; ?></td>
            <td><?php echo convertToLocal($detail->do_joining, 'd-m-Y'). $doRetirement; ?></td>
            <?php if(hasMenuRoute('staff.edit')): ?>
                <td class="text-center">
                    <a href="javascript:void(0);" class="toggle-status" data-message="<?php echo lang('messages.change_status'); ?>" data-route="<?php echo route('staff.toggle', $detail->id); ?>">
                        <?php echo Html::image('assets/images/' . $detail->status . '.gif'); ?>

                    </a>
                </td>
                <td class="text-center col-md-1">
                        <a class="btn btn-xs btn-primary" href="<?php echo e(route('staff.edit', [$detail->id])); ?>"><i class="fa fa-edit"></i></a>
                </td>
            <?php endif; ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <tr class="margintop10">
        <td colspan="10">
            <?php echo paginationControls($page, $total, $perPage); ?>

        </td>
    </tr>
<?php else: ?>
    <tr class="10">
        <td class="text-center" colspan="4"> <?php echo lang('messages.no_data_found'); ?> </td>
    </tr>
<?php endif; ?>
</tbody>