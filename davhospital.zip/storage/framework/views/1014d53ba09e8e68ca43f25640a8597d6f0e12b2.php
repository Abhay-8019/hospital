<?php $__env->startSection('content_header'); ?>
	<section class="content-header">
		<h1>
			<?php echo lang('opd_master.view_patient_visits'); ?>

		</h1>
		<ol class="breadcrumb">
			<li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> <?php echo lang('common.back'); ?></a></li>
			<li class="active"><?php echo lang('opd_master.view_patient_visits'); ?></li>
		</ol>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="page-wrapper">

    <div class="row">

		<div class="col-md-12">
			<!-- start: BASIC TABLE PANEL -->
			<div class="panel panel-default" style="position: static;">
				<div class="panel-heading">
					<i class="fa fa-external-link-square"></i> &nbsp;
					<?php echo lang('opd_master.view_patient_visits'); ?>

				</div>
				<div class="panel-body padding0">
					<div class="col-md-6 hidden marginbottom10">
						<?php echo Form::hidden('page', '1'); ?>

					</div>
					<div id="p-report">
					<?php $json = ""; ?>
					<table id="paginate-loadggg" class="table table-bordered margin0 col-md-12 padding0 font-14">
						<thead>
						<tr>
							<th width="10%"><?php echo lang('opd_master.opd_number'); ?></th>
							<th width="15%"><?php echo lang('opd_master.visit_date'); ?></th>
							<th width="10%"><?php echo lang('opd_master.doctor'); ?></th>
						</tr>
						</thead>
						<tbody>
						<?php if(count($previousVisits) > 0): ?>
							<?php $__currentLoopData = $previousVisits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td>
										<a href="<?php echo route('patient.opd-visit-print', $detail->id); ?>" title="View OPD slip">
											<?php echo $detail->id; ?>

										</a>
									</td>
									<td>
										<?php echo dateFormat('d.m.Y', $detail->visit_date); ?>

									</td>
									<td> <?php echo $detail->doctor; ?> </td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
						<?php if(count($previousVisits) < 1): ?>
							<tr>
								<td class="text-center" colspan="6"> <?php echo lang('messages.no_data_found'); ?> </td>
							</tr>
						<?php endif; ?>
						</tbody>
					</table>
					</div>
				</div>
			</div>
			<!-- end: BASIC TABLE PANEL -->
		</div>

	</div>	
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>