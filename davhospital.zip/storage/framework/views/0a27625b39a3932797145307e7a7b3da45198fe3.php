<thead>
<?php if(count($result) > 0): ?>
    <?php if(!isset($inputs['staff-search'])): ?>
        <tr>
            <td colspan="8" class="print_hide">
                <?php $linkCss = [asset('assets/css/bootstrap.min.css'),asset('assets/css/template.css')]; ?>
                <a onclick="return reportPrint('p-report','<?php echo implode('|', $linkCss); ?>')" class="btn btn-success btn-xs pull-right marginbottom10">
                    &nbsp;<i class="fa fa-print"></i> <?php echo lang('common.print'); ?> &nbsp;&nbsp;
                </a>
            </td>
        </tr>
    <?php endif; ?>
    
    <tr class="no-hover">
        <td colspan="8">
        <div style="text-align: center;margin: 0;">
            <p style="font-size: 1.5em;margin:0;">
                    <b> <span style="text-decoration: underline;"> IPD Patients</span> </b>
            </p>
            <?php if(!isset($inputs['staff-search'])): ?>
                <p style="font-size: 1.2em;margin:0;">
                <span style="font-weight: bold;">

                    <?php if($doctorName != ""): ?>
                        Doctor Wise: "<?php echo $doctorName; ?>"
                    <?php endif; ?>

                    <?php if($departmentName != ""): ?>
                        Department Wise: "<?php echo $departmentName; ?>"
                    <?php endif; ?>

                    <?php if($patientName != ""): ?>
                        Patient Wise: "<?php echo $patientName; ?>"
                    <?php endif; ?>
                    <br/>
                    <?php if($inputs['report_type'] == 1 && isset($inputs['from_date']) && isset($inputs['to_date'])): ?>
                        (Dated: <?php echo dateFormat('d.m.Y', $inputs['from_date']); ?> - <?php echo dateFormat('d.m.Y', $inputs['to_date']); ?>)
                    <?php elseif($inputs['report_type'] == 2): ?>
                        (for the month of <?php echo getMonths($inputs['month']); ?>)
                    <?php endif; ?>
                </span>
            </p>
            <?php endif; ?>
        </div>
    </td>
    </tr>
<?php endif; ?>
<tr>
    <th width="10%"><?php echo lang('ipd_master.visit_date'); ?></th>
    <th width="10%"><?php echo lang('patient.patient_code'); ?>/<?php echo lang('ipd_master.ipd_number'); ?></th>
    <th width="10%"><?php echo lang('patient.first_name'); ?></th>
    <th width="10%"><?php echo lang('doctor.doctor'); ?></th>
    <th width="10%"><?php echo lang('department.department'); ?></th>
    <th width="8%"><?php echo lang('common.age'); ?></th>
    <th width="6%"><?php echo lang('common.gender'); ?></th>
    <th width="10%"><?php echo lang('common.mobile'); ?></th>
    <?php if(isset($inputs['is_discharged']) && $inputs['is_discharged'] ==1): ?>
        <th width="10%"><?php echo lang('ipd_master.discharge_date'); ?></th>
    <?php endif; ?>
    <?php if(isset($inputs['staff-search'])): ?>
        <th width="10%"><?php echo lang('common.action'); ?></th>
    <?php endif; ?>
</tr>
</thead>
<tbody>
<?php $index = 1; $genderArr = lang('common.genderArray'); ?>
<?php if(count($result) > 0): ?>
    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo dateFormat('d.m.Y', $detail->admission_dt); ?></td>
            <?php if(!isset($inputs['staff-search'])): ?>
            <td><a href="<?php echo route('patient.ipd-print', $detail->ipd_master_id   ); ?>"> <?php echo $detail->ipd_number; ?> </a></td>
            <td><a href="<?php echo route('patient.opd-visit-history', $detail->patient_id); ?>"> <?php echo $detail->first_name; ?></a></td>
            <?php else: ?>
            <td>P-<?php echo $detail->patient_id; ?>/<?php echo $detail->ipd_number; ?> </td>
            <td><?php echo $detail->first_name; ?></td>
            <?php endif; ?>            
            <td><?php echo $detail->doctor; ?></td>
            <td><?php echo $detail->department; ?></td>
            <td><?php echo $detail->age; ?> <?php if($detail->age): ?> Years <?php endif; ?> </td>
            <td><?php if($detail->gender != ''): ?> <?php echo $genderArr[$detail->gender]; ?> <?php endif; ?> </td>
            <td><?php echo $detail->mobile; ?></td>
            <?php if(isset($inputs['is_discharged']) && $inputs['is_discharged'] ==1): ?>
                <td width="10%"><a href="<?php echo route('patient.ipd-discharge-summary', $detail->ipd_master_id   ); ?>"><?php echo dateFormat('Y-m-d',$detail->discharge_date); ?></a></td>
            <?php endif; ?>
            <?php if(isset($inputs['staff-search'])): ?>
                <td>
                    <a href="<?php echo route('patient.ipd-procedure-visit', $detail->ipd_master_id); ?>" target="_blank" class="btn btn-xs btn-success"> <i class="fa fa-eye"></i> </a>
                </td>
            <?php endif; ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php if(count($result) < 1): ?>
    <tr>
        <td class="text-center" colspan="8"> <?php echo lang('messages.no_data_found'); ?> </td>
    </tr>
<?php endif; ?>
</tbody>