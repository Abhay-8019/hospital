<?php $__env->startSection('content_header'); ?>
    <section class="content-header">
        <h1>
            <?php echo lang('product_group.product_group'); ?>

            <small><?php echo lang('common.add_record'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> <?php echo lang('common.back'); ?></a></li>
            <li><a href="<?php echo route('product-group.index'); ?>"><?php echo lang('product_group.product_groups'); ?></a></li>
            <li class="active"><?php echo lang('common.create_heading', lang('product_group.product_group')); ?></li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    
    <?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-12 padding0">
            <?php echo $__env->make('admin.product-group.form_common', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>    
    </div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>