<?php $__env->startSection('content_header'); ?>
    <section class="content-header">
        <h1>
            <?php echo lang('department.department_detail'); ?>

            <small><?php echo lang('common.add_record'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> <?php echo lang('common.back'); ?></a></li>
            <li><a href="<?php echo route('department.index'); ?>"><?php echo lang('department.departments'); ?></a></li>
            <li class="active"><?php echo lang('common.create_heading', lang('department.department')); ?></li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <!-- start: PAGE CONTENT -->
    
    
    <?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-12 padding0">
            <?php echo Form::open(array('method' => 'POST', 'route' => array('department.store'), 'id' => 'ajaxSave', 'class' => 'form-horizontal')); ?>

            <!-- department-form -->
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <i class="fa fa-external-link-square"></i> &nbsp;
                        <?php echo lang('department.department_detail'); ?>

                    </div>
                    <div class="panel-body">

                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group required">
                                    <?php echo Form::label('code', lang('common.code'), array('class' => 'col-sm-3 control-label')); ?>


                                    <div class="col-sm-8">
                                        <?php echo Form::text('code', $departmentCode, array('class' => 'form-control', 'readonly')); ?>

                                    </div>
                                </div>

                                <div class="form-group required">
                                    <?php echo Form::label('name', lang('common.name'), array('class' => 'col-sm-3 control-label')); ?>


                                    <div class="col-sm-8">
                                        <?php echo Form::text('name', null, array('class' => 'form-control', 'placeholder' => 'Department Name')); ?>

                                    </div>
                                </div>

                                <div class="form-group required hide">
                                    <?php echo Form::label('head_name', lang('department.head_name'), array('class' => 'col-sm-3 control-label')); ?>


                                    <div class="col-sm-8">
                                        <?php echo Form::text('head_name', null, array('class' => 'form-control', 'placeholder' => 'Head Name')); ?>

                                    </div>
                                </div>

                                <div class="form-group hide">
                                    <?php echo Form::label('address', lang('department.address'), array('class' => 'col-sm-3 control-label')); ?>


                                    <div class="col-sm-8">
                                        <?php echo Form::textarea('address', null, array('class' => 'form-control', 'address' => '5x6', 'cols' => 50, 'rows' => 4, 'placeholder' => 'Head Address')); ?>

                                    </div>
                                </div>

                                <div class="form-group">
                                    <?php echo Form::label('status', lang('common.active') . '&nbsp;', array('class' => 'col-sm-3 control-label')); ?>

                                    <div class="col-sm-5 margintop8">
                                        <?php echo Form::checkbox('status', '1', true); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-5">

                                <div class="form-group required">
                                    <?php echo Form::label('floor_id', lang('department.floor_name'), array('class' => 'col-sm-4 control-label')); ?>

                                    <div class="col-sm-8">
                                        <?php echo Form::select('floor_id', $floorName, null, array('class' => 'form-control select2 padding0')); ?>

                                    </div>
                                </div>

                                <div class="form-group">
                                    <?php echo Form::label('description', lang('common.description'), array('class' => 'col-sm-4 control-label')); ?>


                                    <div class="col-sm-8">
                                        <?php echo Form::textarea('description', null, array('class' => 'form-control', 'department' => '5x6', 'cols' => 50, 'rows' => 4, 'placeholder' => 'Department Description')); ?>

                                    </div>
                                </div>

                                <div class="form-group required hide">
                                    <?php echo Form::label('contact_number', lang('department.head_contact'), array('class' => 'col-sm-4 control-label')); ?>


                                    <div class="col-sm-8">
                                        <div class="input-group">
                                            <span class="input-group-addon"><?php echo lang('common.isd_code_india'); ?></span>
                                            <?php echo Form::text('contact_number', null, array('class' => 'form-control', 'placeholder' => 'Head Contact Number')); ?>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="col-sm-10 margintop20 clearfix text-center">
                            <div class="form-group">
                                <?php echo Form::submit(lang('common.save'), array('class' => 'btn btn-primary btn-lg')); ?>

                            </div>
                        </div>

                    </div>
                </div>
                <!-- end: TEXT FIELDS PANEL -->
            </div>
            <?php echo Form::close(); ?>

        </div>    
    </div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>