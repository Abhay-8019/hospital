<?php $__env->startSection('content_header'); ?>
    <section class="content-header">
        <h1>
            <?php echo lang('rog_type.rog_type'); ?>

            <small><?php echo lang('common.add_record'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> <?php echo lang('common.back'); ?></a></li>
            <li><a href="<?php echo route('rog-types.index'); ?>"><?php echo lang('rog_type.rog_types'); ?></a></li>
            <li class="active"><?php echo lang('common.create_heading', lang('rog_type.rog_type')); ?></li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row">
    <div class="col-md-12 col-lg-12 col-md-12 col-sm-12  padding0">
        <?php echo $__env->make('admin.rog-type.form_common', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>