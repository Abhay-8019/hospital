<?php $__env->startSection('content_header'); ?>
	<section class="content-header">
		<div class="pull-right">
			<a class="btn btn-danger btn-xs" href="<?php echo route('user.create'); ?>">
				<i class="fa fa-plus-circle"></i> <?php echo lang('common.create_heading', lang('user.user')); ?>

			</a>
		</div>
		<h1>
			<?php echo lang('user.user_detail'); ?>

			<small><?php echo lang('common.list_record'); ?></small>
		</h1>
		<ol class="breadcrumb hidden">
			<li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> <?php echo lang('common.back'); ?></a></li>
			<li class="active"><?php echo lang('user.user'); ?></li>
			<li><a href="<?php echo route('user.create'); ?>"><?php echo lang('common.create_heading', lang('user.user')); ?></a></li>
		</ol>
	</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
	
    <?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
	    <div class="col-md-12">

			<!-- start: BASIC TABLE PANEL -->
			<div class="panel panel-default">
				<div class="panel-heading">
					<i class="fa fa-external-link-square"></i> &nbsp;
					<?php echo lang('user.users_list'); ?>

				</div>
				<div class="panel-body">
					<form id="serachable" action="<?php echo e(route('user.action')); ?>" method="post">
					<div class="col-md-3 text-right pull-right padding0 marginbottom10">
						<?php echo lang('common.per_page'); ?>: <?php echo Form::select('name', ['20' => '20', '40' => '40', '100' => '100', '200' => '200', '300' => '300'], '20', ['id' => 'per-page']); ?>

					</div>
					<div class="col-md-3 padding0 marginbottom10">
						<?php echo Form::hidden('page', 'search'); ?>

						<?php echo Form::hidden('_token', csrf_token()); ?>

						
					</div>
					<table id="paginate-load" data-route="<?php echo e(route('user.paginate')); ?>" class="table table-hover clearfix margin0 col-md-12 padding0">
					</table>
					</form>
				</div>
			</div>
			<!-- end: BASIC TABLE PANEL -->
		</div>
	</div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>