<li class="treeview">
    <a href="<?php echo route('dashboard'); ?>">
        <i class="fa fa-dashboard"></i> <span> <?php echo lang('master.dashboard'); ?> </span>
    </a>
</li>
<li class="treeview">
    <a href="javascript:void(0)">
        <i class="fa fa-book"></i>
        <span class="title"> Masters </span>
    </a>
    <ul class="treeview-menu">
        <li>
            <a href="<?php echo route('financial-year.index'); ?>">
                <span class="title"> <?php echo lang('financial_year.financial_years'); ?> </span>
            </a>
        </li>
        <li>
            <a href="<?php echo route('tax.index'); ?>">
                <span class="title"> <?php echo lang('tax.tax'); ?> </span>
            </a>
        </li>

        <li>
            <a href="<?php echo route('hsn-code.index'); ?>">
                <span class="title"> <?php echo lang('hsn_code.hsn_code'); ?> </span>
            </a>
        </li>

        <li>
            <a href="<?php echo route('unit.index'); ?>">
                <span class="title"> <?php echo lang('unit.unit'); ?> </span>
            </a>
        </li>

        <li>
            <a href="<?php echo route('product-group.index'); ?>">
                <span class="title"> <?php echo lang('product_group.product_groups'); ?> </span>
            </a>
        </li>

        <li>
            <a href="<?php echo route('products.index'); ?>">
                <span class="title"> <?php echo lang('products.products'); ?> </span>
            </a>
        </li>
        <li>
            <a href="<?php echo route('role.index'); ?>">
                <span class="title"> <?php echo lang('role.role'); ?> </span>
            </a>
        </li>
        <li>
            <a href="<?php echo route('user.index'); ?>">
                <span class="title"> <?php echo lang('user.users'); ?> </span>
            </a>
        </li>
    </ul>
</li>
<li class="treeview">
    <a href="#">
        <i class="fa fa-hospital-o"></i> <span> <?php echo lang('hospital.hospital'); ?> </span>
    </a>
    <ul class="treeview-menu">
        <li>
            <a href="<?php echo route('department.index'); ?>">
                <i class="fa fa-building-o"></i> <span> <?php echo lang('department.department'); ?> </span>
            </a>
        </li>

        <li>
            <a href="<?php echo route('wards.index'); ?>">
                <i class="fa fa-building-o"></i> <span> <?php echo lang('ward.wards'); ?> </span>
            </a>
        </li>

        <li>
            <a href="<?php echo route('beds.index'); ?>">
                <i class="fa fa-building-o"></i> <span> <?php echo lang('bed_master.bed_masters'); ?> </span>
            </a>
        </li>

        <li>
            <a href="<?php echo route('rog-types.index'); ?>">
                <i class="fa fa-building-o"></i> <span> <?php echo lang('rog_type.rog_types'); ?> </span>
            </a>
        </li>

        <li>
            <a href="<?php echo route('ot-types.index'); ?>">
                <i class="fa fa-building-o"></i> <span> <?php echo lang('ot_type.ot_types'); ?> </span>
            </a>
        </li>

        <li>
            <a href="<?php echo route('procedures.index'); ?>">
                <i class="fa fa-building-o"></i> <span> <?php echo lang('procedure.procedures'); ?> </span>
            </a>
        </li>
    </ul>
</li>

<li class="treeview">
    <a href="#">
        <i class="fa fa-user-md"></i> <span> <?php echo lang('doctor.doctor'); ?> </span>
    </a>
    <ul class="treeview-menu">
        <li>
            <a href="<?php echo route('designation.index'); ?>">
                <i class="fa fa-building-o"></i> <span> <?php echo lang('designation.designation'); ?> </span>
            </a>
            <a href="<?php echo route('specialization.index'); ?>">
                <i class="fa fa-user-md"></i> <span> <?php echo lang('specialization.specialization'); ?> </span>
            </a>
            <a href="<?php echo route('doctor.index'); ?>">
                <i class="fa fa-user-md"></i> <span> <?php echo lang('doctor.doctor'); ?> </span>
            </a>
        </li>
    </ul>
</li>

<li class="treeview hidef">
    <a href="#">
        <i class="fa fa-flask"></i> <span> <?php echo lang('test.tests'); ?> </span>
    </a>
    <ul class="treeview-menu">
        <li>
            <a href="<?php echo route('test-category.index'); ?>">
                <i class="fa fa-flask"></i> <span> <?php echo lang('test_category.test_categories'); ?> </span>
            </a>
        </li>

        <li>
            <a href="<?php echo route('add-test.index'); ?>">
                <i class="fa fa-flask"></i> <span> <?php echo lang('test.add_tests'); ?> </span>
            </a>
        </li>
    </ul>
</li>


<li class="treeview">
    <a href="<?php echo route('patient-registration.index'); ?>">
        <i class="fa fa-user"></i> <span> <?php echo lang('patient.opd_patients'); ?> </span>
    </a>
    <ul class="treeview-menu">
        <li>
            <a href="<?php echo route('patient-registration.create'); ?>">
                <i class="fa fa-circle-o"></i>
                <?php echo lang('patient.new_patient'); ?>

            </a>
        </li>
        <li>
            <a href="<?php echo route('patient-registration.index'); ?>">
                <i class="fa fa-circle-o"></i>
                <?php echo lang('patient.patients_list'); ?>

            </a>
        </li>
        <li>
            <a href="<?php echo route('patient.opd-list'); ?>">
                <i class="fa fa-circle-o"></i>
                <?php echo lang('opd_master.opd_visits'); ?>

            </a>
        </li>

        <li>
            <a href="<?php echo route('patient.opd-re-visit'); ?>">
                <i class="fa fa-circle-o"></i>
                <?php echo lang('opd_master.opd_revisit'); ?>

            </a>
        </li>
    </ul>
</li>

<li class="treeview">
    <a href="<?php echo route('patient.ipd-list'); ?>">
        <i class="fa fa-user"></i> <span> <?php echo lang('ipd_master.ipd_visits'); ?> </span>
    </a>
    <ul class="treeview-menu">
        <li>
            <a href="<?php echo route('patient.ipd-list'); ?>">
                <i class="fa fa-circle-o"></i>
                <?php echo lang('ipd_master.ipd_visits'); ?>

            </a>
        </li>
    </ul>
</li>

<li class="treeview">
    <a href="javascript:void(0)">
        <i class="fa fa-pie-chart"></i> <span> <?php echo lang('reports.reports'); ?> </span>
    </a>
    <ul class="treeview-menu">
        <li>
            <a href="<?php echo route('report.patient-wise-visits'); ?>">
                <i class="fa fa-circle-o"></i>
                <?php echo lang('opd_master.patient_wise_visits'); ?>

            </a>
        </li>

        <li>
            <a href="<?php echo route('report.doctor-wise-visits'); ?>">
                <i class="fa fa-circle-o"></i>
                <?php echo lang('opd_master.doctor_wise_visits'); ?>

            </a>
        </li>

        <li>
            <a href="<?php echo route('report.department-wise-visits'); ?>">
                <i class="fa fa-circle-o"></i>
                <?php echo lang('opd_master.department_wise_visits'); ?>

            </a>
        </li>

        <li>
            <a href="<?php echo route('report.opd-visits'); ?>">
                <i class="fa fa-circle-o"></i>
                <?php echo lang('opd_master.advanced_opd_search'); ?>

            </a>
        </li>

        <li>
            <a href="<?php echo route('report.ipd-patients'); ?>">
                <i class="fa fa-circle-o"></i>
                <?php echo lang('ipd_master.ipd_visits'); ?>

            </a>
        </li>

        <li>
            <a href="<?php echo route('report.bed-occupancy'); ?>">
                <i class="fa fa-circle-o"></i>
                <?php echo lang('ipd_master.department_bed_occupancy'); ?>

            </a>
        </li>
    </ul>
</li>

<li class="treeview hide">
    <a href="<?php echo route('employee-type.index'); ?>">
        <i class="fa fa-building-o"></i> <span> <?php echo lang('employee_type.employee_type'); ?> </span>
    </a>
</li>

<li class="treeview hide">
    <a href="<?php echo route('staff.index'); ?>">
        <i class="fa fa-building-o"></i> <span> <?php echo lang('staff.staff'); ?> </span>
    </a>
</li>