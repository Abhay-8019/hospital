<thead>
<?php if(count($result) > 0): ?>

    <tr>
        <td colspan="8" class="print_hide">
            <?php $linkCss = [asset('assets/css/bootstrap.min.css'),asset('assets/css/template.css')]; ?>
            <a onclick="return reportPrint('p-report','<?php echo implode('|', $linkCss); ?>')" class="btn btn-success btn-xs pull-right marginbottom10">
                &nbsp;<i class="fa fa-print"></i> <?php echo lang('common.print'); ?> &nbsp;&nbsp;
            </a>
        </td>
    </tr>


    <tr class="no-hover">
        <td colspan="8">
        <div style="text-align: center;margin: 0;">
            <p style="font-size: 1.5em;margin:0;">
                    <b> <span style="text-decoration: underline;"> Patient Tests Summary </span> </b>
            </p>
            <p style="font-size: 1.2em;margin:0;">
                <span style="font-weight: bold;">
                    <?php if($doctorName != ""): ?>
                        Doctor Wise: "<?php echo $doctorName; ?>" <br/>
                    <?php endif; ?>

                    <?php if($departmentName != ""): ?>
                        Department Wise: "<?php echo $departmentName; ?>" <br/>
                    <?php endif; ?>

                    <?php if(isset($inputs['report_type']) && $inputs['report_type'] == 1 && isset($inputs['from_date']) && isset($inputs['to_date'])): ?>
                        (Dated: <?php echo dateFormat('d.m.Y', $inputs['from_date']); ?> - <?php echo dateFormat('d.m.Y', $inputs['to_date']); ?>)
                    <?php elseif(isset($inputs['report_type']) && $inputs['report_type'] == 2): ?>
                        (for the month of <?php echo getMonths($inputs['month']); ?>)
                    <?php endif; ?>
                </span>
            </p>
        </div>
    </td>
    </tr>
<?php endif; ?>
<tr>
    <th width="5%" class="text-center"><?php echo "Sr. No"; ?></th>
    <th width="10%" ><?php echo lang('patient_test.receipt_no'); ?></th>
    <th><?php echo lang('patient_test.test_date'); ?></th>
    <th><?php echo lang('patient.first_name'); ?></th>
    <th><?php echo lang('doctor.doctor'); ?></th>
    <th><?php echo lang('department.department'); ?></th>
    <th><?php echo lang('patient_test.amount'); ?></th>
</tr>
</thead>
<tbody>
<?php $index = 1; $total = 0; ?>
<?php if(count($result) > 0): ?>
    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="order_<?php echo e($detail->id); ?>">
            <td class="text-center"><?php echo $index++; ?></td>
            <td>
                <?php echo lang('patient_test.rcpt') . $detail->receipt_no; ?>

            </td>
            <td><?php echo dateFormat('d M, Y', $detail->test_date); ?></td>
            <td><?php echo $detail->first_name; ?> <?php if($detail->age != ""): ?> (<?php echo $detail->age; ?> Y) <?php endif; ?></td>
            <td><?php echo $detail->doctor; ?></td>
            <td><?php echo $detail->department; ?></td>
            <td><?php echo numberFormat($detail->total); ?></td>
            <?php $total += $detail->total; ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td colspan="6" style="font-size: 20px;text-align: right;">
            <strong>Total Amount:</strong>
        </td>
        <td style="font-size: 20px;">
            <strong><?php echo numberFormat($total); ?></strong>
        </td>
    </tr>
<?php endif; ?>
<?php if(count($result) < 1): ?>
    <tr>
        <td class="text-center" colspan="8"> <?php echo lang('messages.no_data_found'); ?> </td>
    </tr>
<?php endif; ?>
</tbody>