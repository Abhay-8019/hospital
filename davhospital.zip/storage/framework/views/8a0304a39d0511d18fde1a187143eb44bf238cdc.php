<?php $__env->startSection('content_header'); ?>
    <section class="content-header">
        <h1>
            <?php echo lang('common.edit_heading', lang('department.department')); ?> #<?php echo $result->name; ?>

            <small><?php echo lang('common.record_update'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> <?php echo lang('common.back'); ?></a></li>
            <li><a href="<?php echo route('dashboard'); ?>"><i class="fa fa-dashboard"></i><?php echo lang('common.dashboard'); ?></a></li>
            <li><a href="<?php echo route('department.index'); ?>"><?php echo lang('department.department'); ?></a></li>
            <li class="active"><?php echo lang('common.edit_heading', lang('department.department')); ?></li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <!-- start: PAGE CONTENT -->
    
    
    <?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-12 padding0">
        <?php echo Form::model($result, array('route' => array('department.update', $result->id), 'method' => 'PATCH', 'id' => 'ajaxSave', 'class' => 'form-horizontal')); ?>

            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <i class="fa fa-external-link-square"></i> &nbsp;
                        <?php echo lang('department.department_detail'); ?>

                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <?php echo Form::label('code', lang('common.code'), array('class' => 'col-sm-3 control-label')); ?>


                                    <div class="col-sm-8">
                                        <?php echo Form::text('code', ($result->code) ? $result->code : null, array('class' => 'form-control', 'readonly')); ?>

                                    </div>
                                </div>

                                <div class="form-group">
                                    <?php echo Form::label('name', lang('common.name'), array('class' => 'col-sm-3 control-label')); ?>


                                    <div class="col-sm-8">
                                        <?php echo Form::text('name', ($result->name) ? $result->name : null, array('class' => 'form-control')); ?>

                                    </div>
                                </div>

                                <div class="form-group required hide">
                                    <?php echo Form::label('head_name', lang('department.head_name'), array('class' => 'col-sm-3 control-label')); ?>


                                    <div class="col-sm-8">
                                        <?php echo Form::text('head_name', null, array('class' => 'form-control', 'placeholder' => 'Head Name')); ?>

                                    </div>
                                </div>

                                <div class="form-group hide">
                                    <?php echo Form::label('address', lang('department.address'), array('class' => 'col-sm-3 control-label')); ?>


                                    <div class="col-sm-8">
                                        <?php echo Form::textarea('address', null, array('class' => 'form-control', 'address' => '5x6', 'cols' => 50, 'rows' => 4, 'placeholder' => 'Head Address')); ?>

                                    </div>
                                </div>

                                <div class="form-group">
                                    <?php echo Form::label('status', lang('common.active') . '&nbsp;', array('class' => 'col-sm-3 control-label')); ?>

                                    <div class="col-sm-5 margintop8">
                                        <?php echo Form::checkbox('status', '1', ($result->status == '1') ? true : false); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-5">

                                <div class="form-group required">
                                    <?php echo Form::label('floor_id', lang('department.floor_name'), array('class' => 'col-sm-4 control-label')); ?>

                                    <div class="col-sm-8">
                                        <?php echo Form::select('floor_id', $floorName, ($result->floor_id) ? $result->floor_id : null, array('class' => 'form-control select2 padding0')); ?>

                                    </div>
                                </div>

                                <div class="form-group">
                                    <?php echo Form::label('description', lang('common.description'), array('class' => 'col-sm-4 control-label')); ?>


                                    <div class="col-sm-8">
                                        <?php echo Form::textarea('description', ($result->description) ? $result->description : null, array('class' => 'form-control', 'department' => '5x6', 'rows' => 4, 'cols' => 50)); ?>

                                    </div>
                                </div>

                                <div class="form-group required hide">
                                    <?php echo Form::label('contact_number', lang('department.head_contact'), array('class' => 'col-sm-4 control-label')); ?>


                                    <div class="col-sm-8">
                                        <div class="input-group">
                                            <span class="input-group-addon"><?php echo lang('common.isd_code_india'); ?></span>
                                            <?php echo Form::text('contact_number', null, array('class' => 'form-control', 'placeholder' => 'Head Contact Number')); ?>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="col-sm-10 margintop20 clearfix text-center">
                            <div class="form-group">
                                <?php echo Form::submit(lang('common.update'), array('class' => 'btn btn-primary')); ?>

                            </div>
                        </div>

                    </div>
                </div>
                <!-- end: TEXT FIELDS PANEL -->
            </div>
            <?php echo Form::close(); ?>

        </div>    
    </div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>