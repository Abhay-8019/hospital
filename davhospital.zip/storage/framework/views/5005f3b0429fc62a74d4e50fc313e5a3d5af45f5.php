<?php $__env->startSection('content_header'); ?>
	<section class="content-header">
		<h1>
			<?php $route = \Route::currentRouteName(); ?>
			<?php echo string_manip(lang('reports.report'), 'UCW'); ?> - <?php echo lang('ipd_master.bed_occupancy'); ?>

		</h1>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div id="page-wrapper">
		
		<?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<div class="col-md-12 padding0">
			<?php echo Form::open(array('method' => 'POST', 'route' => array($route), 'id' => 'ajaxForm')); ?>

			<div class="row">
				

				<div class="col-md-2 width125 date">
					<div class="form-group">
						<?php echo Form::label('from_date', lang('reports.from_date'), array('class' => 'control-label')); ?>

						<?php echo Form::text('from_date', null, array('class' => 'form-control date-picker from_date', 'placeholder' => lang('reports.from_date'))); ?>

					</div>
				</div>


				<div class="col-md-2 width125 date paddingleft0">
					<div class="form-group">
						<?php echo Form::label('to_date', lang('reports.to_date'), array('class' => 'control-label')); ?>

						<?php echo Form::text('to_date', null, array('class' => 'form-control date-picker to_date', 'placeholder' =>  lang('reports.to_date'))); ?>

					</div>
				</div>

				<div class="col-md-2 width125 margintop25 paddingleft0">
					<div class="form-group">
						<?php echo Form::label('Details', 'Show Details', array('class' => 'control-label')); ?>

						<?php echo Form::checkbox('show_details', 1,false); ?>

					</div>
				</div>

				<div class="col-sm-3 margintop25 paddingleft0">
					<div class="form-group">
						<?php echo Form::hidden('form-search', 1); ?>

						<?php echo Form::hidden('report_type', 1); ?>

						<?php echo Form::submit(lang('reports.filter'), array('class' => 'btn btn-primary', 'title' => lang('reports.filter'))); ?>

						<a href="<?php echo route($route); ?>" class="btn btn-primary" title="<?php echo lang('reports.reset_filter'); ?>"> <?php echo lang('reports.reset_filter'); ?></a>
					</div>
				</div>
			</div>
			<?php echo Form::close(); ?>

		</div>

		<div class="row">
			<div class="col-md-12">
				<!-- start: BASIC TABLE PANEL -->
				<div class="panel panel-default" style="position: static;">
					<div class="panel-heading">
						<i class="fa fa-external-link-square"></i> &nbsp;
						<?php echo lang('ipd_master.bed_occupancy'); ?>

					</div>
					<div class="panel-body padding0">
						<div class="col-md-6 hidden marginbottom10">
							<?php echo Form::hidden('page', '1'); ?>

						</div>
						<div id="p-report">
							<table id="paginate-load" data-route="<?php echo e(route($route)); ?>" class="table table-bordered margin0 col-md-12 padding0 font-14">
							</table>
						</div>
					</div>
				</div>
				<!-- end: BASIC TABLE PANEL -->
			</div>
		</div>
	</div>
	<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script type="text/javascript">
		$(document).ready(function(){
			$(".report_type").change(function()
			{
				var report_type = $(this).val();

				if(report_type == '1')
				{
					$(".month, .year").addClass("hidden");
					$(".date").removeClass("hidden");
					//$(".from_date").attr("required", "required");
					//$(".to_date").attr("required", "required");
				}
				else if(report_type == '2')
				{
					$(".date, .year").addClass("hidden");
					$(".month").removeClass("hidden");
					//$(".from_date").removeAttr("required");
					//$(".to_date").removeAttr("required");
				}
				else if(report_type == '3')
				{
					$(".month, .date").addClass("hidden");
					$(".year").removeClass("hidden");
					$(".from_date").removeAttr("required");
					$(".to_date").removeAttr("required");
				}
			});
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>