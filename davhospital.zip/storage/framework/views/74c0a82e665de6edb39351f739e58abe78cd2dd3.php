<thead>
<tr>
    <th width="5%" class="text-center"><?php echo lang('common.id'); ?></th>
    <th><?php echo lang('common.name'); ?></th>
    <?php if(hasMenuRoute('tax.edit') || isAdmin()): ?>
     <th class="text-center"><?php echo lang('common.action'); ?></th>
    <?php endif; ?>
</tr>
</thead>
<tbody>
<?php $index = 1; ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr id="order_<?php echo e($detail->id); ?>">
        <td class="text-center"><?php echo pageIndex($index++, $page, $perPage); ?></td>
        <td>
        <?php if(hasMenuRoute('tax.edit') || isAdmin()): ?>
         <a href="<?php echo e(route('tax.edit', [$detail->id])); ?>">
           <?php echo $detail->name; ?>

         </a>
        <?php else: ?>
           <?php echo $detail->name; ?>

        <?php endif; ?>
        </td>
        <?php if(hasMenuRoute('tax.edit') || isAdmin()): ?>
         <td class="text-center col-md-1">
            <a class="btn btn-xs btn-primary" href="<?php echo e(route('tax.edit', [$detail->id])); ?>"><i class="fa fa-edit"></i></a>
         </td>
        <?php endif; ?>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if(count($data) < 1): ?>
    <tr>
        <td class="text-center" colspan="6"> <?php echo lang('messages.no_data_found'); ?> </td>
    </tr>
<?php else: ?>
    <tr class="margintop10">
        <td colspan="6">
            <?php echo paginationControls($page, $total, $perPage); ?>

        </td>
    </tr>
<?php endif; ?>
</tbody>