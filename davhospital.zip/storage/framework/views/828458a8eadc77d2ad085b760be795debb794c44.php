<?php $__env->startSection('content_header'); ?>
<section class="content-header">
    <h1>
        <?php echo lang('patient.patient_detail'); ?>

        <small><?php echo lang('common.add_record'); ?></small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> <?php echo lang('common.back'); ?></a></li>
        <li><a href="<?php echo route('patient-registration.index'); ?>"><?php echo lang('patient.opd_patients'); ?></a></li>
        <li class="active"><?php echo lang('common.create_heading', lang('patient.patient')); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <!-- start: PAGE CONTENT -->
    
    
    <?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-12 padding0">
            <!-- previous patient form id => patient-form -->
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading padding0">
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active">
                                <a href="#personal_tab" aria-controls="personal_tab" role="tab" data-toggle="tab">
                                    <i class="fa fa-external-link-square"></i>
                                    <?php echo lang('patient.personal_detail'); ?>

                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="tab-content">
                                <div id="personal_tab" class="tab-pane fade in active">
                                    <?php echo Form::open(array('method' => 'POST', 'route' => array('patient-registration.store'), 'id' => 'ajaxSave', 'class' => 'form-horizontal')); ?>


                                    <div class="col-md-4 margintop20">
                                        <div class="form-group">
                                            <?php echo Form::label('patient_code', lang('patient.patient_code'), array('class' => 'col-sm-4 control-label')); ?>

                                            <div class="col-sm-8">
                                                <?php echo Form::text('patient_code', $patientCode, array('class' => 'form-control', 'readonly' => 'readonly')); ?>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-4 margintop20">
                                        <div class="form-group required">
                                            <?php echo Form::label('first_name', lang('patient.first_name'), array('class' => 'col-sm-4 control-label')); ?>

                                            <div class="col-sm-8">
                                                <?php echo Form::text('first_name', null, array('class' => 'form-control', 'placeholder' => lang('patient.first_name'))); ?>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="clearfix"></div>

                                    <div class="col-md-4 margintop20 hide">
                                        <div class="form-group required">
                                            <?php echo Form::label('patient_type', lang('patient.patient_type'), array('class' => 'col-sm-4 control-label')); ?>

                                            <div class="col-sm-8">
                                                <?php echo Form::select('patient_type', $patientTypeArray, 2, array('class' => 'form-control select2 padding0')); ?>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-4 margintop20">
                                        <div class="form-group required">
                                            <?php echo Form::label('doctor', lang('doctor.name'), array('class' => 'col-sm-4 control-label')); ?>

                                            <div class="col-sm-8">
                                                <?php echo Form::select('doctor_id', $doctorArray, null, array('class' => 'form-control select2 padding0', 'id' => 'doctor_id')); ?>

                                            </div>
                                        </div>
                                    </div>


                                    

                                    <div class="col-md-4 margintop20">
                                        <div class="form-group required">
                                            <?php echo Form::label('age', lang('patient.age'), array('class' => 'col-sm-4 control-label')); ?>

                                            <div class="col-sm-8">
                                                <?php echo Form::text('age', null, array('id' => 'age', 'class' => 'form-control', 'placeholder' => 'Age In Years')); ?>

                                            </div>
                                        </div>
                                    </div>



                                    <div class="col-md-4 clearfix">

                                        <div class="form-group">
                                            <?php echo Form::label('mobile', lang('common.mobile'), array('class' => 'col-sm-4 control-label')); ?>

                                            <div class="col-sm-8">
                                                <div class="input-group">
                                                    <span class="input-group-addon"><?php echo lang('common.isd_code_india'); ?></span>
                                                    <?php echo Form::text('mobile', null, array('class' => 'form-control', 'maxlength' => 10, 'placeholder' => 'Mobile Number')); ?>

                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group ">
                                            <?php echo Form::label('email', lang('common.email'), array('class' => 'col-sm-4 control-label')); ?>

                                            <div class="col-sm-8">
                                                <?php echo Form::text('email', null, array('class' => 'form-control', 'placeholder' => 'Email : example@mail.com')); ?>

                                            </div>
                                        </div>

                                        <div class="form-group required hide">
                                            <?php echo Form::label('date_of_birth', lang('patient.date_of_birth'), array('class' => 'col-sm-4 control-label')); ?>

                                            <div class="col-sm-8">
                                                <?php echo Form::text('date_of_birth', null, array('id' => 'dob', 'class' => 'form-control date-picker', 'placeholder' => 'Date Of Birth', 'data-input' => 'age')); ?>

                                            </div>
                                        </div>

                                        <div class="form-group required">
                                            <?php echo Form::label('gender', lang('patient.gender'), array('class' => 'col-sm-4 control-label')); ?>

                                            <div class="col-sm-8">
                                                <?php echo Form::select('gender', $genderArr, null, array('class' => 'form-control select2 padding0')); ?>

                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <?php echo Form::label('address', lang('patient.address'), array('class' => 'col-sm-4 control-label')); ?>

                                            <div class="col-sm-8">
                                                <?php echo Form::textarea('address', null, array('class' => 'form-control address', 'placeholder' => 'Address', 'rows' => 4, 'cols' => 50)); ?>

                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <?php echo Form::label('status', lang('common.active') . '&nbsp;', array('class' => 'col-sm-4 control-label')); ?>

                                            <div class="col-sm-8">
                                                <label class="checkbox col-sm-3">
                                                    <?php echo Form::checkbox('status', '1', true); ?>

                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-4">


                                        

                                        <div class="form-group">
                                            <?php echo Form::label('alternate_contact_no', lang('patient.alternate_no'), array('class' => 'col-sm-4 control-label')); ?>

                                            <div class="col-sm-8">
                                                <div class="col-sm-4 padding0">
                                                    <?php echo Form::text('std_code', null, array('class' => 'form-control', 'min' => 1, 'maxlength' => 4, 'placeholder' => 'STD CODE')); ?>

                                                </div>
                                                <div class="col-sm-8 paddingright0">
                                                    <?php echo Form::text('alternate_contact_no', null, array('class' => 'form-control', 'placeholder' => 'Phone Number', 'min' => 1, 'maxlength' => 7)); ?>

                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <?php echo Form::label('blood_group', lang('patient.blood_group'), array('class' => 'col-sm-4 control-label')); ?>

                                            <div class="col-sm-8">
                                                <?php echo Form::select('blood_group', $bloodGroupArr, null, array('class' => 'form-control select2 padding0')); ?>

                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <?php echo Form::label('city', lang('patient.city'), array('class' => 'col-sm-4 control-label')); ?>

                                            <div class="col-sm-8">
                                                <?php echo Form::text('city', null, array('class' => 'form-control', 'placeholder' => 'City')); ?>

                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <?php echo Form::label('country', lang('patient.country'), array('class' => 'col-sm-4 control-label')); ?>

                                            <div class="col-sm-8">
                                                <?php echo Form::text('country', null, array('class' => 'form-control', 'placeholder' => 'Country')); ?>

                                            </div>
                                        </div>

                                    </div>

                                    <div class="col-md-4">


                                        

                                        

                                        <div class="form-group required">
                                            <?php echo Form::label('department', lang('department.department'), array('class' => 'col-sm-4 control-label')); ?>

                                            <div class="col-sm-8">
                                                <?php echo Form::select('department', $departments, null, array('class' => 'form-control select2 padding0')); ?>

                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <?php echo Form::label('marital_status', lang('patient.marital_status'), array('class' => 'col-sm-4 control-label')); ?>

                                            <div class="col-sm-8">
                                                <?php echo Form::select('marital_status', $maritalStatusArr, null, array('class' => 'form-control select2 padding0')); ?>

                                            </div>
                                        </div>

                                        

                                        <div class="form-group">
                                            <?php echo Form::label('state', lang('patient.state'), array('class' => 'col-sm-4 control-label')); ?>

                                            <div class="col-sm-8">
                                                <?php echo Form::text('state', null, array('class' => 'form-control', 'placeholder' => 'State')); ?>

                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <?php echo Form::label('zip_code', lang('patient.zip_code'), array('class' => 'col-sm-4 control-label')); ?>

                                            <div class="col-sm-8">
                                                <?php echo Form::text('zip_code', null, array('class' => 'form-control', 'placeholder' => 'Area Zip Code', 'maxlength' => 6)); ?>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-11 text-center">
                                        <div class="form-group">
                                            <?php echo Form::submit(lang('common.save'), array('class' => 'btn btn-primary btn-lg')); ?>

                                        </div>
                                    </div>

                                    <?php echo Form::close(); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end: TEXT FIELDS PANEL -->
            </div>
        </div>    
    </div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            var datePicker = $('#dob').datepicker({
                showButtonPanel: false,
                dateFormat: "dd-mm-yy",
                dayNamesMin: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
                changeYear: true,
                changeMonth: true,
                yearRange: '1960:' + new Date().getFullYear(),
                defaultDate: new Date()
            });

            $(datePicker).on('change', function(){
                var thisVal = $(this).val();
                var target = $(this).data('input');
                if(thisVal != '')
                {
                    var route = "<?php echo route('calculate-age'); ?>";
                    calculateAge(thisVal, route, target);
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>