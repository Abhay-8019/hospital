<thead>
<tr>
    <th width="5%" class="text-center"><?php echo lang('common.id'); ?></th>
    <th width="10%" ><?php echo lang('patient_test.receipt_no'); ?></th>
    <th><?php echo lang('common.name'); ?></th>
    <th><?php echo lang('patient_test.test_date'); ?></th>
    <th><?php echo lang('patient_test.amount'); ?></th>
    <th><?php echo lang('patient_test.report'); ?></th>
    <th width="10%" class="text-center"><?php echo lang('common.action'); ?></th>
</tr>
</thead>
<tbody>
<?php $index = 1; ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr id="order_<?php echo e($detail->id); ?>">
    <td class="text-center"><?php echo pageIndex($index++, $page, $perPage); ?></td>
    <td>
        <?php echo lang('patient_test.rcpt') . $detail->receipt_no; ?>

    </td>
    <td><?php echo $detail->first_name; ?> <?php if($detail->age != ""): ?> (<?php echo $detail->age; ?> Y) <?php endif; ?></td>
    <td><?php echo dateFormat('d M, Y', $detail->test_date); ?></td>
    <td><?php echo numberFormat($detail->total); ?></td>
    <td><a href="<?php echo e(route('patient-test.generate_report', [$detail->id])); ?>"> <?php echo lang('patient_test.gen_report'); ?></a> </td>
    <td class="text-center">
        <a class="btn btn-xs btn-primary" href="<?php echo e(route('patient-test.edit', [$detail->id])); ?>"><i class="fa fa-edit"></i></a>
        <a class="btn btn-xs btn-success" href="<?php echo e(route('patient-test.show', [$detail->id])); ?>" target="_blank"><i class="fa fa-print"></i></a>
        <a class="btn btn-xs btn-danger" href="<?php echo e(route('patient-test.report', [$detail->id])); ?>" target="_blank"><i class="fa fa-print"></i></a>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if(count($data) < 1): ?>
<tr>
    <td class="text-center" colspan="7"> <?php echo lang('messages.no_data_found'); ?> </td>
</tr>
<?php else: ?>
<tr class="margintop10">
    <td colspan="7">
        <?php echo paginationControls($page, $total, $perPage); ?>

    </td>
</tr>
<?php endif; ?>
</tbody>