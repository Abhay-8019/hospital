<?php $__env->startSection('content_header'); ?>
<section class="content-header">
    <h1>
        <?php $route = \Route::currentRouteName(); ?>
        <?php if($route == 'patient.ipd-discharge-summary' && $result->is_discharged == 1): ?>
            <?php echo lang('ipd_master.discharge_summary'); ?>

        <?php else: ?>
            <?php echo lang('ipd_master.ipd_visit'); ?>

            <small><?php echo lang('common.view_heading', " Visit Detail"); ?></small>
        <?php endif; ?>
    </h1>
    <ol class="breadcrumb">
        <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> <?php echo lang('common.back'); ?></a></li>
        <li class="active"><?php echo lang('ipd_master.ipd_visit'); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <!-- start: PAGE CONTENT -->
    
    
    <?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-12 padding0">
            <!-- previous patient form id => patient-form -->
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading padding0">
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active">
                                <a href="#personal_tab" aria-controls="personal_tab" role="tab" data-toggle="tab">

                                    <?php if($route == 'patient.ipd-discharge-summary' && $result->is_discharged == 1): ?>
                                        <?php echo lang('ipd_master.ipd_discharge_summary'); ?>

                                    <?php else: ?>
                                        <i class="fa fa-external-link-square"></i>
                                        <?php echo lang('ipd_master.ipd_visit_detail'); ?>

                                    <?php endif; ?>

                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <?php $linkCss = [asset('assets/css/bootstrap.min.css'),asset('assets/css/template.css')]; ?>
                            <a onclick="return reportPrint('p-report','<?php echo implode('|', $linkCss); ?>')" style="margin-right: 20px;" class="btn btn-success btn-sm pull-right marginbottom10">
                                &nbsp;<i class="fa fa-print"></i> <?php echo lang('common.print'); ?> &nbsp;&nbsp;
                            </a>

                            <?php if($result->is_discharged == 0): ?>
                                <a class="btn btn-sm btn-danger pull-right marginright10" href="<?php echo route('patient.ipd-discharge', $result->id); ?>">
                                    Discharge Patient
                                </a>
                            <?php endif; ?>

                            <div class="tab-content" id="p-report">

                                <?php echo $__env->make('layouts.template.college-name-head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                                <div id="personal_tab" class="tab-pane fade in active">
                                    <?php
                                        $genderArr = lang('common.genderArray');
                                        $bloodGroupArr = lang('common.bloodGroupArr');
                                    ?>
                                    <div class="col-md-12">

                                        <h1 class="h-size">
                                            <?php if($route != 'patient.ipd-discharge-summary'): ?>
                                                Patient Detail
                                            <?php else: ?> <br/>
                                                <center>DISCHARGE SUMMARY</center>
                                            <?php endif; ?>
                                        </h1>
                                        <hr/>
                                        <table class="table table-bordered">
                                            <tr>
                                                <td><b><?php echo lang('patient.patient_code'); ?></b></td>
                                                <td><?php echo $patient->patient_code; ?></td>
                                                
                                                <td width="15%"><b><?php echo lang('patient.first_name'); ?></b></td>
                                                <td width="18%"><?php echo $patient->first_name; ?></td>
                                                <td width="15%"><b><?php echo lang('doctor.doctor'); ?></b></td>
                                                <td width="18%"><?php echo $result->doctor; ?> </td>
                                            </tr>

                                            <tr>
                                                
                                                <td width="15%"><b><?php echo lang('ipd_master.ipd_number'); ?></b></td>
                                                <td><?php echo $result->ipd_number; ?></td>
                                                
                                                <td><b><?php echo lang('department.department'); ?></b></td>
                                                <td>
                                                    <?php echo $result->department; ?>

                                                </td>
                                                <td><b><?php echo lang('ipd_master.visit_date'); ?></b></td>
                                                <td>
                                                    <?php echo dateFormat('d.m.Y', $result->admission_date); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <td><b><?php echo lang('patient.age'); ?></b>/<b><?php echo lang('patient.gender'); ?></b></td>
                                                <td><?php echo $patient->age; ?> <?php if($patient->age): ?> Years <?php endif; ?>  / <?php if($patient->gender != ''): ?> <?php echo $genderArr[$patient->gender]; ?> <?php endif; ?></td>                                                
                                                <td><b><?php echo lang('ward.ward'); ?></b></td>
                                                <td>
                                                    <?php echo $result->ward; ?>

                                                </td>
                                                <?php if($route == 'patient.ipd-discharge-summary' && $result->is_discharged == 1): ?>
                                                    <td>
                                                        <b>Discharge Date</b> <br/>
                                                        <b>Total Admitted Day(s)</b>
                                                    </td>
                                                    <td>
                                                        <?php echo dateFormat('d.m.Y h:i A', $result->discharge_date); ?> <br/>
                                                        <b><?php echo daysDiff($result->admission_date, $result->discharge_date); ?> Day(s)</b>
                                                    </td>
                                                <?php else: ?>
                                                    <td><b> </b></td>
                                                    <td> </td>
                                                <?php endif; ?>
                                            </tr>
                                            <tr>
                                                <td><b><?php echo lang('patient.blood_group'); ?></b></td>
                                                <td><?php echo $patient->blood_group; ?></td>
                                                <td><b><?php echo lang('bed_master.bed_master'); ?> No</b></td>
                                                <td>
                                                    <?php echo $result->bed; ?>

                                                </td>
                                                <?php if($route == 'patient.ipd-discharge-summary' && $result->is_discharged == 1): ?>
                                                    <td><b>Discharge Type</b></td>
                                                    <td><?php echo dischargeType($result->discharge_type); ?></td>
                                                <?php else: ?>
                                                    <td><b> </b></td>
                                                    <td> </td>
                                                <?php endif; ?>
                                            </tr>
                                            <tr>
                                                <td><b><?php echo lang('patient.address'); ?></b></td>
                                                <td colspan="3"><?php echo $patient->address; ?></td>
                                                <?php if($route == 'patient.ipd-discharge-summary' && $result->is_discharged == 1): ?>
                                                    <td><b>Discharged Doctor</b></td>
                                                    <td><?php echo $result->discharge_doctor; ?></td>
                                                <?php else: ?>
                                                    <td><b> </b></td>
                                                    <td> </td>
                                                <?php endif; ?>
                                            </tr>
                                        </table>
                                    </div>

                                    <?php if($route == 'patient.ipd-discharge-summary' && $result->is_discharged == 1): ?>
                                        <div class="col-md-12">
                                            <table class="table table-bordered">
                                                
                                                <?php if(strlen($result->diagnose) > 2): ?>
                                                <tr>
                                                    <td width="15%"><b><?php echo lang('ipd_master.diagnose'); ?></b></td>
                                                    <td colspan="5"><?php echo nl2br($result->diagnose); ?></td>
                                                </tr>
                                                <?php endif; ?>

                                                <tr>
                                                    <td width="15%"><b><?php echo lang('ipd_master.discharge_summary'); ?></b></td>
                                                    <td colspan="5"><?php echo nl2br($result->discharge_summary); ?></td>
                                                </tr>
                                                <tr>
                                                    <td width="15%"><b><?php echo lang('ipd_master.treatment_given'); ?></b></td>
                                                    <td colspan="5"><?php echo nl2br($result->treatment_given); ?></td>
                                                </tr>
                                                <tr>
                                                    <td width="15%"><b><?php echo lang('ipd_master.treatment_advised'); ?></b></td>
                                                    <td colspan="5"><?php echo nl2br($result->treatment_advised); ?></td>
                                                </tr>
                                            </table>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($route != 'patient.ipd-discharge-summary'): ?>
                                        <div class="col-md-12">
                                            <h1 class="h-size">
                                                Examination
                                            </h1>
                                            <hr/>

                                            <table class="table table-bordered">
                                                <tr>
                                                    <td width="15%"><b><?php echo lang('ipd_master.present_illness'); ?></b></td>
                                                    <td colspan="5"><?php echo nl2br($result->present_illness); ?></td>
                                                </tr>
                                                <tr>
                                                    <td width="15%"><b><?php echo lang('ipd_master.previous_medical'); ?></b></td>
                                                    <td colspan="5"><?php echo nl2br($result->previous_medical); ?></td>
                                                </tr>
                                                <tr>
                                                    <td width="15%"><b><?php echo lang('ipd_master.family_history'); ?></b></td>
                                                    <td colspan="5"><?php echo nl2br($result->family_history); ?></td>
                                                </tr>
                                                <tr>
                                                    <td><b><?php echo lang('ipd_master.pulse_rate'); ?></b></td>
                                                    <td><?php echo nl2br($result->pulse_rate); ?></td>
                                                    <td><b><?php echo lang('ipd_master.blood_pressure'); ?></b></td>
                                                    <td><?php echo nl2br($result->blood_pressure); ?></td>
                                                    <td><b><?php echo lang('ipd_master.temperature'); ?></b></td>
                                                    <td><?php echo nl2br($result->temperature); ?></td>
                                                </tr>

                                                <tr>
                                                    <td><b><?php echo lang('ipd_master.hr'); ?></b></td>
                                                    <td><?php echo nl2br($result->hr); ?></td>
                                                    <td><b><?php echo lang('ipd_master.rr'); ?></b></td>
                                                    <td><?php echo nl2br($result->rr); ?></td>
                                                    <td>&nbsp;</td>
                                                    <td>&nbsp;</td>
                                                </tr>
                                                <tr style="display: none;">
                                                    <td><b><?php echo lang('ipd_master.other_information'); ?></b></td>
                                                    <td colspan="5"><?php echo nl2br($result->other_information); ?></td>
                                                </tr>
                                                <tr>
                                                    <td><b><?php echo lang('ipd_master.general_examination'); ?></b></td>
                                                    <td colspan="5"><?php echo str_replace('###','<br>',$result->general_examination); ?></td>
                                                </tr>
                                                <?php if(strlen($result->diagnose) > 2): ?>
                                                <tr>
                                                    <td><b><?php echo lang('ipd_master.diagnose'); ?></b></td>
                                                    <td colspan="5"><?php echo $result->diagnose; ?></td>
                                                </tr>
                                                <?php endif; ?>

                                                <?php if($result->admission_date < '2020-02-23'): ?>
                                                <tr>
                                                    <td width="15%"><b><?php echo lang('ipd_master.present_treatment'); ?></b></td>
                                                    <td colspan="5"><?php echo str_replace('###',"<br>",$result->present_treatment); ?></td>
                                                </tr>
                                                <?php endif; ?>
                                                
                                            </table>
                                        </div>

                                        <div class="col-md-12">
                                            <hr/>
                                            <h1 class="h-size">
                                                Procedures
                                            </h1>
                                            <hr/>
                                            <div class="col-md-8 padding0 clearfix">
                                                <div class="clearfix place-template">
                                                    <table class="table table-bordered">
                                                        <tr>
                                                            <th><b><?php echo lang('ipd_master.procedure_date'); ?></b></th>
                                                            <th><b><?php echo lang('ipd_master.procedure'); ?></b></th>
                                                            <th><b><?php echo lang('ipd_master.medicine'); ?></b></th>
                                                            <th><b><?php echo lang('ipd_master.dose'); ?></b></th>
                                                            <th><b><?php echo lang('ipd_master.timing'); ?></b></th>
                                                            <th><b><?php echo lang('opd_master.procedure_days'); ?></b></th>
                                                            <th><b><?php echo lang('ipd_master.remarks'); ?></b></th>
                                                        </tr>
                                                        <?php $__currentLoopData = $pMedicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo dateFormat('d.m.Y', $detail->procedure_date); ?></td>
                                                                <td><?php echo $detail->procedure; ?></td>
                                                                <td><?php echo $detail->medicine; ?></td>
                                                                <td><?php echo $detail->dose; ?> <?php echo $detail->dose_unit; ?></td>
                                                                <td><?php echo $detail->timing; ?></td>
                                                                <td><?php echo $detail->procedure_days; ?></td>            
                                                                <td><?php echo $detail->remarks; ?></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <hr/>
                                            <h1 class="h-size">
                                                Medications
                                            </h1>
                                            <hr/>
                                            <div class="col-md-8 padding0 clearfix">

                                                <table class="table table-bordered">
                                                    <tr>
                                                        <th><b><?php echo lang('ipd_master.medicine'); ?></b></th>
                                                        <th><b><?php echo lang('ipd_master.dose'); ?></b></th>
                                                        <th><b><?php echo lang('ipd_master.dose_unit'); ?></b></th>
                                                        <th><b><?php echo lang('ipd_master.timing'); ?></b></th>
                                                            <th><b><?php echo lang('opd_master.medicine_days'); ?></b></th>

                                                        <th><b><?php echo lang('ipd_master.remarks'); ?></b></th>
                                                    </tr>
                                                    <?php $__currentLoopData = $mMedicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo $detail->medicine; ?></td>
                                                            <td><?php echo $detail->dose; ?></td>
                                                            <td><?php echo $detail->dose_unit; ?></td>
                                                            <td><?php echo $detail->timing; ?></td>
                                                            <td><?php echo $detail->medicine_days; ?></td>                            
                                                            <td><?php echo $detail->remarks; ?></td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </table>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end: TEXT FIELDS PANEL -->
            </div>
        </div>    
    </div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>