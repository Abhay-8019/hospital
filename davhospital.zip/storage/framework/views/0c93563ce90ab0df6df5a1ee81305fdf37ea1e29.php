<?php $__env->startSection('content_header'); ?>
<section class="content-header">
    <h1>
        <?php echo lang('role.role_detail'); ?>

        <small><?php echo lang('common.add_record'); ?></small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> <?php echo lang('common.back'); ?></a></li>
        <li><a href="<?php echo route('role.index'); ?>"><?php echo lang('role.role'); ?></a></li>
        <li class="active"><?php echo lang('common.create_heading', lang('role.role')); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <!-- start: PAGE CONTENT -->
    
    
    <?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-12 padding0">
            <?php echo Form::open(array('method' => 'POST', 'route' => array('role.store'), 'id' => 'ajaxSave', 'class' => 'form-horizontal')); ?>

            <!-- previous role form id => role-form -->
            <div class="col-md-12">
                <div class="panel panel-danger">
                    <div class="panel-heading">
                        <i class="fa fa-external-link-square"></i> &nbsp;
                        <?php echo lang('role.role_detail'); ?>

                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('code', lang('common.code'), array('class' => 'col-sm-3 control-label')); ?>

                                    <div class="col-sm-8">
                                        <?php echo Form::text('code', null, array('class' => 'form-control')); ?>

                                    </div>
                                </div>

                                <div class="form-group">
                                    <?php echo Form::label('name', lang('common.name'), array('class' => 'col-sm-3 control-label')); ?>

                                    <div class="col-sm-8">
                                        <?php echo Form::text('name', null, array('class' => 'form-control')); ?>

                                    </div>
                                </div>

                                <div class="form-group">
                                    <?php echo Form::label('status', lang('common.active') . '&nbsp;', array('class' => 'col-sm-3 control-label')); ?>

                                    <div class="col-sm-5 margintop8">
                                        <?php echo Form::checkbox('status', '1', true); ?>

                                    </div>
                                </div>
                            </div>
                            <?php if(isset($tree) && count($tree) > 0): ?>
                                <div class="col-md-6 uac-scroll">
                                <ul id="tree">
                                    <?php $__currentLoopData = $tree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <?php if(array_key_exists('child', $value)): ?>
                                                <i class="fa fa-plus collapsee ulclose cursorPointer"></i>
                                                <a href="javascript:void(0)" class="collapsee ulclose">
                                                    <?php echo $value['name']; ?>

                                                </a>
                                            <?php else: ?>
                                                <input type="checkbox" name="section[]" value="<?php echo $value['id']; ?>" id="<?php echo $value['name']; ?>"/>
                                                <?php echo Form::label($value['name'], $value['name']); ?>

                                            <?php endif; ?>
                                        </li>

                                        <?php if(array_key_exists('child', $value)): ?>
                                            <ul class="hidden">
                                                <?php $__currentLoopData = $value['child']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyDrop => $valueDrop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <?php if(array_key_exists('child', $valueDrop)): ?>
                                                            <i class="fa fa-plus collapsee ulclose cursorPointer"></i>
                                                            <a href="javascript:void(0)" class="collapsee ulclose">
                                                                <?php echo $valueDrop['name']; ?>

                                                            </a>
                                                        <?php else: ?>
                                                            <input type="checkbox" name="section[]" value="<?php echo $value['id'].','.$valueDrop['id']; ?>" id="<?php echo $valueDrop['name']; ?>"/>
                                                            <?php echo Form::label($valueDrop['name'], $valueDrop['name']); ?>

                                                        <?php endif; ?>
                                                    </li>
                                                    <?php if(array_key_exists('child', $valueDrop)): ?>
                                                        <ul class="hidden">
                                                            <?php $__currentLoopData = $valueDrop['child']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyThirdDrop => $valueThirdDrop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li>
                                                                    <label>
                                                                        <input type="checkbox" name="section[]" value="<?php echo $value['id'].','.$valueDrop['id'].','.$valueThirdDrop['id']; ?>" />
                                                                        <?php echo $valueThirdDrop['name']; ?>

                                                                    </label>
                                                                </li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>

                            <div class="col-sm-11 margintop20 clearfix text-center">
                                <div class="form-group">
                                    <?php echo Form::submit(lang('common.save'), array('class' => 'btn btn-primary btn-lg')); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end: TEXT FIELDS PANEL -->
            </div>
            <?php echo Form::close(); ?>

        </div>    
    </div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $('#tree').checktree();
        $('i.collapsee').on('click', function() {
            if($(this).hasClass('ulclose')) {
                $(this).removeClass('ulclose').addClass('ulopen');
                $(this).parent().next('ul').removeClass('hidden');
                $(this).removeClass('fa-plus').addClass('fa-minus');
                $(this).next('a').removeClass('ulclose').addClass('ulopen');
            } else {
                $(this).removeClass('ulopen').addClass('ulclose');
                $(this).parent().next('ul').addClass('hidden');
                $(this).removeClass('fa-minus').addClass('fa-plus');
                $(this).next('a').removeClass('ulopen').addClass('ulclose');
            }
        });
        $('a.collapsee').on('click', function() {
            if($(this).hasClass('ulclose')) {
                $(this).removeClass('ulclose').addClass('ulopen');
                $(this).parent().next('ul').removeClass('hidden');
                $(this).siblings('i').removeClass('fa-plus').addClass('fa-minus').removeClass('ulclose').addClass('ulopen');
            } else {
                $(this).removeClass('ulopen').addClass('ulclose');
                $(this).parent().next('ul').addClass('hidden');
                $(this).siblings('i').removeClass('fa-minus').addClass('fa-plus').removeClass('ulopen').addClass('ulclose');
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>