<thead>
<tr>
    <th width="1%" class="text-center"><?php echo lang('common.id'); ?></th>
    <th><?php echo lang('common.name'); ?></th>
    <th><?php echo lang('doctor.contact'); ?></th>
    <th><?php echo lang('doctor.specialization'); ?></th>
    <th><?php echo lang('doctor.department'); ?></th>
    <th><?php echo lang('doctor.doctor_image'); ?></th>
    <th><?php echo lang('doctor.fee'); ?></th>
    <?php if(hasMenuRoute('doctor.edit')): ?>
        <th class="text-center"> <?php echo lang('common.status'); ?> </th>
        <th class="text-center"><?php echo lang('common.action'); ?></th>
    <?php endif; ?>
</tr>
</thead>
<tbody>
<?php $index = 1;
$dutyType = lang('common.duty_type');
$filePath = \Config::get('constants.UPLOADS');
$folder = ROOT . $filePath;
?>
<?php if(isset($data) && count($data) > 0): ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="order_<?php echo e($detail->id); ?>">
            <td class="text-center"><?php echo pageIndex($index++, $page, $perPage); ?></td>
            <td>
                <?php if(hasMenuRoute('doctor.edit')): ?>
                    <a href="<?php echo route('doctor.edit', [$detail->id]); ?>">
                        <?php echo $detail->name; ?>

                    </a>
                <?php else: ?>
                    <?php echo $detail->name; ?>

                <?php endif; ?>
            </td>
            <td> <?php echo $detail->contact; ?> </td>
            <td> <?php echo $detail->specialization_name; ?> </td>
            <td> <?php echo $detail->department_name; ?> </td>
            <td> <?php if(file_exists($folder . $detail->image) && $detail->image): ?>
                    <?php echo Html::image($filePath.$detail->image, getFileName($detail->image), ['class' => 'img-responsive img-circle margin0-auto', 'width' => '60','align'=>'left']); ?>

                <?php endif; ?>
            </td>
            <td> <?php echo numberFormat($detail->consultation_fee); ?> </td>
            <?php if(hasMenuRoute('doctor.edit')): ?>
                <td class="text-center">
                    <a href="javascript:void(0);" class="toggle-status" data-message="<?php echo lang('messages.change_status'); ?>" data-route="<?php echo route('doctor.toggle', $detail->id); ?>">
                        <?php echo Html::image('assets/images/' . $detail->status . '.gif'); ?>

                    </a>
                </td>
                <td class="text-center col-md-1">
                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('doctor.edit', [$detail->id])); ?>"><i class="fa fa-edit"></i></a>
                </td>
            <?php endif; ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <tr class="margintop10">
        <td colspan="10">
            <?php echo paginationControls($page, $total, $perPage); ?>

        </td>
    </tr>
<?php else: ?>
    <tr>
        <td class="text-center" colspan="10"> <?php echo lang('messages.no_data_found'); ?> </td>
    </tr>
<?php endif; ?>
</tbody>