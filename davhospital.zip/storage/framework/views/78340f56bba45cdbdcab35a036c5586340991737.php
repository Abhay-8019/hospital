<thead>
<tr>
    <th width="1%" class="text-center"><?php echo lang('common.id'); ?></th>
    <th><?php echo lang('common.name'); ?></th>
    <th><?php echo lang('test.test_cost'); ?></th>
    <th><?php echo lang('test.testrange'); ?></th>
    <th><?php echo lang('test.min_value'); ?></th>
    <th><?php echo lang('test.max_value'); ?></th>
    <?php if(hasMenuRoute('add-test.edit')): ?>
        <th class="text-center"> <?php echo lang('common.status'); ?> </th>
        <th class="text-center"><?php echo lang('common.action'); ?></th>
        <?php if(isAdmin()): ?>
            <th>&nbsp;</th>
        <?php endif; ?>
    <?php endif; ?>
</tr>
</thead>
<tbody>
<?php $index = 1; ?>
<?php if(isset($data) && count($data) > 0): ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="order_<?php echo e($detail->id); ?>">
            <td class="text-center"><?php echo pageIndex($index++, $page, $perPage); ?></td>
            <td>
                <?php if(hasMenuRoute('add-test.edit')): ?>
                    <a href="<?php echo route('add-test.edit', [$detail->id]); ?>">
                        <?php echo $detail->name; ?>

                    </a>
                <?php else: ?>
                    <?php echo $detail->name; ?>

                <?php endif; ?>
            </td>
            <td> <?php echo $detail->cost; ?> </td>
            <td> <?php echo $detail->testrange; ?> </td>
            <td> <?php echo $detail->minval; ?> </td>
            <td> <?php echo $detail->maxval; ?> </td>
            <?php if(hasMenuRoute('add-test.edit')): ?>
                <td class="text-center">
                    <a href="javascript:void(0);" class="toggle-status" data-message="<?php echo lang('messages.change_status'); ?>" data-route="<?php echo route('add-test.toggle', $detail->id); ?>">
                        <?php echo Html::image('assets/images/' . $detail->status . '.gif'); ?>

                    </a>
                </td>
                <td class="text-center col-md-1">
                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('add-test.edit', [$detail->id])); ?>"><i class="fa fa-edit"></i></a>
                </td>
                <?php if(isAdmin()): ?>
                    <td class="text-center col-md-1">
                        <a class="btn btn-xs btn-danger __drop" data-route="<?php echo route('add-test.drop', [$detail->id]); ?>" data-message="<?php echo lang('messages.sure_delete', string_manip(lang('test.test'))); ?>" href="javascript:void(0)"><i class="fa fa-times"></i></a>
                    </td>
                <?php endif; ?>                
            <?php endif; ?>
            
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <tr class="margintop10">
        <td colspan="7">
            <?php echo paginationControls($page, $total, $perPage); ?>

        </td>
    </tr>
<?php else: ?>
    <tr>
        <td class="text-center" colspan="7"> <?php echo lang('messages.no_data_found'); ?> </td>
    </tr>
<?php endif; ?>
</tbody>