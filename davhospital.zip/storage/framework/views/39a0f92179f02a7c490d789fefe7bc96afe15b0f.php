<thead>
<tr>
    <th width="5%" class="text-center"><?php echo lang('common.id'); ?></th>
    <th width="10%"><?php echo lang('common.registration_date'); ?></th>    
    <th width="10%"><?php echo lang('patient.patient_code'); ?></th>
    <th width="15%"><?php echo lang('patient.first_name'); ?></th>
    <th width="10%"><?php echo lang('common.age'); ?> / <?php echo lang('common.gender'); ?></th>
    <th width="10%"><?php echo lang('common.mobile'); ?></th>
    <th width="15%"><?php echo lang('doctor.doctor'); ?></th>
    
    <?php if(hasMenuRoute('patient-registration.edit')): ?>
     <th class="text-center"><?php echo lang('common.action'); ?></th>
    <?php endif; ?>
</tr>
</thead>
<tbody>
<?php
    $index = 1;
    $genderArr = lang('common.genderArrayShort');
    $bloodGroupArr = lang('common.bloodGroupArr');
?>
<?php if(isset($data) && count($data) > 0): ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="patientId_<?php echo e($detail->id); ?>">
            <td class="text-center"><?php echo pageIndex($index++, $page, $perPage); ?></td>
            <td><?php echo convertToLocal($detail->registration_date, 'd-m-Y'); ?></td>
            <td>
                <a href="<?php echo route('patient.opd-visit-history', $detail->id); ?>">
                    <?php echo $detail->patient_code; ?>

                </a>

            </td>
            <td>
                <?php echo $detail->first_name; ?>

            </td>
            <td>
                <?php echo $detail->age; ?> <?php if($detail->age): ?> <?php endif; ?> /
                <?php if($detail->gender != ''): ?> <?php echo $genderArr[$detail->gender]; ?> <?php endif; ?>
            </td>
            <td><?php echo $detail->mobile; ?></td>
            <td> <?php if($detail->doctor_id !=0): ?> <?php echo $doctorArray[$detail->doctor_id]; ?> <?php endif; ?></td>
            
            <?php if(hasMenuRoute('patient-registration.edit')): ?>
                <td class="text-center col-md-1">
                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('patient-registration.edit', [$detail->id])); ?>"><i class="fa fa-edit"></i></a>
                </td>
            <?php endif; ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr class="margintop10">
        <td colspan="9">
            <?php echo paginationControls($page, $total, $perPage); ?>

        </td>
    </tr>
<?php else: ?>
    <tr>
        <td class="text-center" colspan="9"> <?php echo lang('messages.no_data_found'); ?> </td>
    </tr>
<?php endif; ?>
</tbody>