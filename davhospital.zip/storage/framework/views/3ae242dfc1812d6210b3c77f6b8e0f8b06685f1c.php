<?php $__env->startSection('content_header'); ?>
	<section class="content-header">
		<div class="pull-right">
			<a class="btn btn-danger btn-xs" href="<?php echo route('patient-registration.create'); ?>">
				<i class="fa fa-plus-circle"></i> <?php echo lang('common.create_heading', lang('patient.opd_patient')); ?>

			</a>
		</div>
		<h1>
			<?php echo lang('patient.opd_patients'); ?>

			<small><?php echo lang('common.list_record'); ?></small>
		</h1>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="page-wrapper">

	
    <?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="col-md-12 padding0">
		<?php echo Form::open(array('method' => 'POST', 'route' => array('patient-registration.paginate'), 'id' => 'ajaxForm')); ?>

		<div class="row">

			<div class="col-md-2 width150">
				<div class="form-group">
					<?php echo Form::label('patient_code', lang('patient.patient_code'), array('class' => 'control-label')); ?>

					<?php echo Form::text('patient_code', null, array('class' => 'form-control', 'placeholder' => lang('patient.patient_code'))); ?>

				</div>
			</div>

			<div class="col-md-2 paddingleft0">
				<div class="form-group">
					<?php echo Form::label('patient_name', lang('patient.first_name'), array('class' => 'control-label')); ?>

					<?php echo Form::text('patient_name', null, array('class' => 'form-control', 'placeholder' => lang('patient.first_name'))); ?>

				</div>
			</div>

			<div class="col-md-2 width150 paddingleft0">
				<div class="form-group">
					<?php echo Form::label('mobile', lang('patient.mobile'), array('class' => 'control-label')); ?>

					<?php echo Form::text('mobile', null, array('class' => 'form-control', 'placeholder' =>  lang('patient.mobile'))); ?>

				</div>
			</div>

			<div class="col-md-3 paddingleft0">
				<div class="form-group">
					<?php echo Form::label('address', lang('patient.address'), array('class' => 'control-label')); ?>

					<?php echo Form::text('address', null, array('class' => 'form-control', 'placeholder' =>  lang('patient.address'))); ?>

				</div>
			</div>

			<div class="col-sm-3 margintop20">
				<div class="form-group">
					<?php echo Form::hidden('form-search', 1); ?>

					<?php echo Form::submit(lang('reports.filter'), array('class' => 'btn btn-primary', 'title' => lang('reports.filter'))); ?>

					<a href="<?php echo route('patient-registration.index'); ?>" class="btn btn-primary" title="<?php echo lang('reports.reset_filter'); ?>"> <?php echo lang('reports.reset_filter'); ?></a>
				</div>
			</div>
		</div>
		<?php echo Form::close(); ?>

	</div>

    <div class="row">
      <div class="col-md-12">
		<!-- start: BASIC TABLE PANEL -->
		<div class="panel panel-default" style="position: static;">
			<div class="panel-heading">
				<i class="fa fa-external-link-square"></i> &nbsp;
				<?php echo lang('patient.patients_list'); ?>

			</div>
			<div class="panel-body">
				<div class="col-md-3 text-right pull-right padding0 marginbottom10">
					<?php echo lang('common.per_page'); ?>: <?php echo Form::select('name', ['20' => '20', '40' => '40', '100' => '100', '200' => '200', '300' => '300'], '20', ['id' => 'per-page']); ?>

				</div>
				<div class="col-md-3 padding0 marginbottom10">
					<?php echo Form::hidden('page', 'search'); ?>

					<?php echo Form::hidden('_token', csrf_token()); ?>

					<?php echo Form::text('name', null, array('class' => 'form-control live-search', 'placeholder' => 'Search Patient')); ?>

				</div>
				<table id="paginate-load" data-route="<?php echo e(route('patient-registration.paginate')); ?>" class="table table-hover clearfix margin0 col-md-12 padding0">
				</table>
			</div>
		</div>
		<!-- end: BASIC TABLE PANEL -->
	   </div>	
	</div>	
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>