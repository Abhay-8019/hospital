<div class="col-md-12">
    <div class="errorList">
    </div>
</div>
<div class="col-md-12 padding0">
    <div class="clearfix">
        <?php if(count($pMedicines) > 0): ?>
            <?php echo Form::open(array('method' => 'POST', 'route' => array('patient.opd-procedure-visit', $result->id), 'id' => 'ajaxSaveForm', 'class' => 'form-horizontal')); ?>

            <b> ::Procedure Entry for OPD Patients::</b>
            <table class="table table-bordered">
                <tr>
                    <th><b>&nbsp;</b></th>
                    <th><b><?php echo lang('opd_master.procedure'); ?></b></th>
                    <th><b><?php echo lang('opd_master.medicine'); ?></b></th>
                    <th><b><?php echo lang('opd_master.dose'); ?></b></th>
                    <th><b><?php echo lang('opd_master.timing'); ?></b></th>
                    <th><b><?php echo lang('opd_master.remarks'); ?></b></th>
                    <th><b><?php echo lang('opd_master.instruction'); ?></b></th>
                </tr>
                <?php $pId = 0; ?>
                <?php if(count($procedure) > 0): ?>
                    <?php $__currentLoopData = $pMedicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($procedure->procedure_id ==  $detail->procedure_id): ?>
                            <tr>
                                <td>
                                    <div class="hidden"><?php echo Form::checkbox('add_procedure[' . $detail->procedure_id . '##' . $detail->procedure_medicine_id.']', 1, true); ?></div>
                                </td>
                                <td><?php echo $result->patient_id; ?> <?php echo $detail->procedure; ?></td>
                                <td><?php echo $detail->medicine; ?></td>
                                <td><?php echo $detail->dose; ?></td>
                                <td><?php echo $detail->timing; ?></td>
                                <td><?php echo $detail->remarks; ?></td>
                                <td>
                                    <?php
                                        $remarks = ""; $pId = 0;
                                        if($procedure->procedure_id ==  $detail->procedure_id) { $remarks =  $procedure->remarks; $pId = $procedure->id;}
                                    ?>
                                    <?php echo Form::textarea('procedure_remark['. $detail->procedure_id . '##' . $detail->procedure_medicine_id.']', $remarks, ['class' => 'form-control', 'size' => '5x2']); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <?php $__currentLoopData = $pMedicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo Form::checkbox('add_procedure[' . $detail->procedure_id . '##' . $detail->procedure_medicine_id .']', 1); ?>

                                </td>
                                <td><?php echo $detail->procedure; ?></td>
                                <td><?php echo $detail->medicine; ?></td>
                                <td><?php echo $detail->dose; ?></td>
                                <td><?php echo $detail->timing; ?></td>
                                <td><?php echo $detail->remarks; ?></td>
                                <td>
                                    <?php echo Form::textarea('procedure_remark['. $detail->procedure_id . '##' . $detail->procedure_medicine_id  .']', null, ['class' => 'form-control', 'size' => '5x2']); ?>

                                </td>
                            </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>
            </table>

            <div class="col-sm-11 text-center">
                <div class="form-group">
                    <?php echo Form::hidden('pid', $pId); ?>

                    <?php echo Form::hidden('patient_id', $result->patient_id); ?>

                    <?php echo Form::hidden('department_id', $result->department_id); ?>

                    <?php echo Form::hidden('doctor_id', $result->doctor_id); ?>



                    <?php echo Form::submit(lang('common.save'), array('class' => 'btn btn-primary btn-lg')); ?>

                </div>
            </div>
            <?php echo Form::close(); ?>

        <?php else: ?>
            <h2 class="text-center"> No procedure advised for Patient! </h2>
        <?php endif; ?>
    </div>
</div>
<script>
    // Submit modal form with ajax
    $('#ajaxSaveForm').submit(function(e){
        e.preventDefault();
        ajaxSaveModalForm("#ajaxSaveForm");
        return false;
    });
</script>