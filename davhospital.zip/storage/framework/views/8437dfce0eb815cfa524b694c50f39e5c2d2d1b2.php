<div class="padding0">
    <?php if(Session::has('success')): ?>
        <div class="alert alert-success">
            <button data-dismiss="alert" class="close">
                &times;
            </button>
            <i class="fa fa-check-circle"></i> &nbsp;
            <?php echo Session::get('success'); ?>

        </div>        
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <div class="alert alert-danger">
            <button data-dismiss="alert" class="close">
                &times;
            </button>
            <i class="fa fa-times-circle"></i> &nbsp;
            <?php echo Session::get('error'); ?>

        </div>
    <?php endif; ?>
    <?php if(Session::has('warning')): ?>
        <div class="alert alert-warning">
            <button data-dismiss="alert" class="close">
                &times;
            </button>
            <i class="fa fa-exclamation-triangle"></i> &nbsp;
            <?php echo Session::get('warning'); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->count() > 0): ?>
     <div class="col-md-6 padding0">
        <!-- if there are creation errors, they will show here -->
        <div class="alert alert-danger">
            <div class="marginbottom10">
                <i class="fa fa-times-circle"></i> &nbsp;
                <?php echo Lang::get('messages.please_fix'); ?>

            </div>
            <?php echo Html::ul($errors->all()); ?>

        </div>
    </div>
    <?php endif; ?>

    <div class="col-md-6 padding0 hidden">
        <!-- if there are creation errors, they will show here -->
        <div class="alert alert-danger">
            <div class="marginbottom10">
                <i class="fa fa-times-circle"></i> &nbsp;
                <?php echo Lang::get('messages.please_fix'); ?>

            </div>
            <ul class="error-messages">
            </ul>
        </div>
    </div>

    <div class="alert hidden">
        
        <div class="single-response">
            
        </div>
    </div> 
</div>