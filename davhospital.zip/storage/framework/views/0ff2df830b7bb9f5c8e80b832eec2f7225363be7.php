<thead>
<tr>
    <th width="1%">#</th>
    <th width="5%"><?php echo lang('patient.patient_code'); ?></th>
    <th width="10%"><?php echo lang('common.name'); ?></th>
    <th width="5%"><?php echo lang('common.age'); ?> / <?php echo lang('common.gender'); ?></th>
    <th width="5%"><?php echo lang('common.mobile'); ?></th>
    <th class="text-center" colspan="3" width="20%"><?php echo lang('common.action'); ?></th>
</tr>
</thead>
<tbody>
<?php
    $index = 1;
    $genderArr = lang('common.genderArrayShort');
?>
<?php if(count($data) > 0): ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td> <?php echo $index++; ?> </td>
            <td> <a href="<?php echo route('patient.opd-re-visit', [$detail->patient_code]); ?>"> <?php echo $detail->patient_code; ?> </a></td>
            <td>
                <?php echo $detail->first_name; ?>

            </td>
            <td><?php echo $detail->age; ?> <?php if($detail->age): ?> Y <?php endif; ?> / <?php if($detail->gender != ''): ?> <?php echo $genderArr[$detail->gender]; ?> <?php endif; ?></td>
           
            <td><?php echo $detail->mobile; ?></td>
            <td class="text-center col-md-1">
                <?php if(count($data) == 1): ?>
                    <?php echo Form::select('department', $departments, null, array('class' => 'form-control select2d padding0')); ?>

                <?php endif; ?>
            </td>
            <td class="text-center col-md-1">
                <?php if(count($data) == 1): ?>
                    <?php echo Form::select('doctor', $doctors, null, array('class' => 'form-control select2d padding0')); ?>

                <?php endif; ?>
                <?php echo Form::hidden('p_id', $detail->patient_id); ?>

            </td>
            <td class="text-center col-md-1">
                <?php if(count($data) == 1): ?>
                    <?php echo Form::text('opdremarks', null, array('class' => 'form-control', 'placeholder' => 'Remarks')); ?>

                <?php endif; ?>
            </td>

        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td colspan="5">&nbsp;</td>
        <td colspan="3" class="text-center">
            <?php echo Form::submit(lang('common.save'), array('class' => 'btn btn-primary btn-lg')); ?>

        </td>
    </tr>
<?php endif; ?>
<?php if(count($data) < 1): ?>
    <tr>
        <td class="text-center" colspan="6"> <?php echo lang('messages.no_data_found'); ?> </td>
    </tr>
<?php endif; ?>
</tbody>