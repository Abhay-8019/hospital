<thead>
<tr>
    <th width="1%" class="text-center"><?php echo lang('common.id'); ?></th>
    <th><?php echo lang('hospital.hospital_code'); ?></th>
    <th><?php echo lang('hospital.hospital_name'); ?></th>
    <th><?php echo lang('hospital.contact_person'); ?></th>
    <th><?php echo lang('hospital.gst_number'); ?></th>
    <th><?php echo lang('hospital.email'); ?></th>
    <th><?php echo lang('hospital.mobile'); ?></th>
    <?php if(hasMenuRoute('hospital.edit')): ?>
        <th class="text-center"> <?php echo lang('common.status'); ?> </th>
        <th class="text-center"><?php echo lang('common.action'); ?></th>
    <?php endif; ?>
</tr>
</thead>
<tbody>
<?php $index = 1;
$dutyType = lang('common.duty_type');
$filePath = \Config::get('constants.UPLOADS');
$folder = ROOT . $filePath;
?>
<?php if(isset($data) && count($data) > 0): ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="order_<?php echo e($detail->id); ?>">
            <td class="text-center"><?php echo pageIndex($index++, $page, $perPage); ?></td>
            <td> <?php echo $detail->hospital_code; ?> </td>
            <td>
                <?php if(hasMenuRoute('hospital.edit')): ?>
                    <a href="<?php echo route('hospital.edit', [$detail->id]); ?>">
                        <?php echo $detail->hospital_name; ?>

                    </a>
                <?php else: ?>
                    <?php echo $detail->hospital_name; ?>

                <?php endif; ?>
            </td>
            <td> <?php echo $detail->contact_person; ?> </td>
            <td> <?php echo $detail->tin_number; ?> </td>
            <td> <?php echo $detail->email; ?> </td>
            <td> <?php echo $detail->mobile; ?> </td>
            <?php if(hasMenuRoute('hospital.edit')): ?>
                <td class="text-center">
                    <a href="javascript:void(0);" class="toggle-status" data-message="<?php echo lang('messages.change_status'); ?>" data-route="<?php echo route('hospital.toggle', $detail->id); ?>">
                        <?php echo Html::image('assets/images/' . $detail->status . '.gif'); ?>

                    </a>
                </td>
                <td class="text-center col-md-1">
                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('hospital.edit', [$detail->id])); ?>"><i class="fa fa-edit"></i></a>
                </td>
            <?php endif; ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <tr class="margintop10">
        <td colspan="10">
            <?php echo paginationControls($page, $total, $perPage); ?>

        </td>
    </tr>
<?php else: ?>
    <tr>
        <td class="text-center" colspan="10"> <?php echo lang('messages.no_data_found'); ?> </td>
    </tr>
<?php endif; ?>
</tbody>