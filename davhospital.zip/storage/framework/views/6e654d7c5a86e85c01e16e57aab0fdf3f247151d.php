<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        table tr td, div {
            font-family: Verdana, Arial, Helvetica, sans-serif;
        }

        table.innertable tr td.trb {
            border-right: 1px solid #000000;
            border-bottom: 1px solid #000000;
            border-top: 1px solid #000000;
        }

        table.innertable tr td.tb {
            border-top: 1px solid #000000;
            border-bottom: 1px solid #000000;
        }

        table.innertable tr td.rb {
            border-right: 1px solid #000000;
            border-bottom: 1px solid #000000;
        }

        table.innertable tr td.r {
            border-right: 1px solid #000000;
        }

        table.innertable tr td.b {
            border-bottom: 1px solid #000000;
        }

        table.innertable tr td.t {
            border-top: 1px solid #000000;
        }
        @page
        {
            size: A4 portrait;
            margin: 3mm 0 -2mm 1mm;
            page-break-inside: avoid;
            page-break-after: always;
        }
        h3, h5 {margin:0;padding:0;}
    </style>
</head>
<body onload="printIt();">
<div id="wrapper">
    <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0" class="innertable" style="border: 1px solid #000000;">
        <tr>
            <td align="center">
                <table width="100%" border="0" cellspacing="0" cellpadding="4" style="border:0px;">
                    <tr>
                        <td width="20%">
                            <img src='/assets/images/logo.png' style="max-height: 100px;float: left;margin-right:50px;">
                        </td>
                        <td>
                            <h3>M.C. D.A.V. Hospital</h3>
                            <h5>Mahatama Hans Raj Marg, Jalandhar-144008</h5>
                            <h5>Phone: 0181-2253572, 08559067185</h5>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td align="center">
                <hr style="border-top: 1px solid #000000"/>
            </td>
        </tr>
        <tr>
            <td>
                <table width="100%" border="0" cellspacing="0" cellpadding="4" style="border:0;">
                    <tr>
                        <td width="20%"><strong><?php echo lang('patient_test.receipt_no'); ?>. </strong></td>
                        <td> <?php echo lang('patient_test.rcpt') . $result->receipt_no; ?></td>
                        <td width="10%"><strong>Date </strong></td>
                        <td> <?php echo dateFormat('d M, Y', $result->report_generate_date); ?> </td>
                    </tr>
                    <tr>
                        <td><strong>Patient Name </strong></td>
                        <td><?php echo $patient->first_name; ?></td>
                        <td><strong>Age </strong></td>
                        <td><?php echo $patient->age; ?> years</td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td height="10"></td>
        </tr>
        <tr>
            <td class="t">&nbsp;<strong>Test(s) Report:</strong></td>
        </tr>
        <tr>
            <td height="7"></td>
        </tr>
        <tr>
            <td>
                <table width="100%" border="0" cellspacing="0" cellpadding="4" class="innertable" style="border: 0;">
                    <tr>
                        <td align="left" class="trb"><strong>Test Name </strong></td>
                        <td width="18%" align="left" class="trb"><strong>Test Value </strong></td>
                        <td width="18%" align="left" class="tb"><strong> Test Range </strong></td>
                    </tr>
                    <?php $total = 0; $subTests = [];  ?>
                    <?php $__currentLoopData = $result->tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td align="left" class="rb"><?php echo $detail->diagnostics->name; ?> </td>
                            <td align="left" class="rb">
                                <?php
                                    $testValue = '';
                                    if (array_key_exists($detail->id, $tests))
                                    {
                                        $testValue = $tests[$detail->id]['test_result'];
                                        $subTest = $tests[$detail->id]['sub_tests_result'];
                                        if ($subTest != "") {
                                            $subTests = json_decode($subTest, true);
                                        }
                                    }
                                ?>
                                <?php if(count($subTest) < 1): ?>
                                    <?php echo $testValue; ?>

                                <?php endif; ?>
                            </td>
                            <td align="left" class="b">
                                <?php if(count($subTest) < 1): ?>
                                    <?php echo $detail->diagnostics->testrange; ?>

                                <?php endif; ?>
                                <?php
                                    /*$normal2 = ($detail->diagnostics->maxval != "") ? '-' . $detail->diagnostics->maxval : '';
                                    $unit = ($detail->diagnostics->unit != "") ? ' ' . $detail->diagnostics->unit : '';
                                    echo '('.$detail->diagnostics->minval.$normal2.$unit.')';*/
                                ?>
                            </td>
                        </tr>
                        <?php if(count($subTests) > 0): ?>
                            <?php $__currentLoopData = $subTests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testId => $testValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php $tDet = getTestName(['id' => $testId]); ?>
                                    <td align="left" class="rb">
                                        &nbsp; <?php echo $tDet->name; ?>

                                    </td>
                                    <td align="left" class="rb">
                                        <?php echo $testValue; ?>

                                    </td>
                                    <td align="left" class="rb">
                                        <?php echo $tDet->testrange; ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </td>
        </tr>
    </table>

    <div style="width: 50%; float: right;text-align: right;">
        <br/>
        <span style="font-weight: bold;font-size: 20px;">For M.C. D.A.V. Hospital &nbsp; </span>

        <br/> <br/> <br/>
        Auth. Signatory &nbsp; &nbsp; &nbsp;
    </div>
    <div style="width: 50%; float: left;">

    </div>
</div>
</body>
<script type="text/javascript">
    function printIt() {
        window.print();
        //setTimeout(function () { window.close(); }, 100);
    }
</script>
</html>