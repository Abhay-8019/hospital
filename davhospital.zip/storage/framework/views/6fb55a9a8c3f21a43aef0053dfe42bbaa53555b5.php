<?php $__env->startSection('content_header'); ?>
    <section class="content-header">
        <h1>
            <?php echo lang('common.dashboard'); ?>

        </h1>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
        <!-- start: PAGE CONTENT -->
        
        <?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="row">
            <div class="col-md-12 padding0">
                <div class="col-md-12">
                    <div class="panel panel-danger">
                        <div class="panel-heading">
                            <i class="fa fa-external-link-square"></i>
                            <?php echo lang('common.dashboard'); ?>                            
                        </div>
                        <div class="panel-body">
                            <?php if(isAdmin()): ?>
                                <div class="col-md-12">
                                    <div class="col-md-1 pull-right">
                                        <a href="<?php echo route('patient.daily-opd-list'); ?>" class="btn btn-danger btn-sm"> <i class="fa fa-stethoscope"></i> View All</a>
                                    </div>
                                </div>
                                <hr>
                                <div class="col-md-12 padding0">
                                <?php echo Form::open(array('method' => 'POST', 'route' => array('patient-registration.paginate'), 'id' => 'ajaxForm')); ?>

                                <div class="row">

                                <div class="col-md-2 width150">
                                <div class="form-group">
                                <?php echo Form::label('patient_code', lang('patient.patient_code'), array('class' => 'control-label')); ?>

                                <?php echo Form::text('patient_code', null, array('class' => 'form-control', 'placeholder' => lang('patient.patient_code'))); ?>

                                </div>
                                </div>

                                <div class="col-md-2 width150">
                                <div class="form-group">
                                <?php echo Form::label('opd_id', lang('patient.opd_id'), array('class' => 'control-label')); ?>

                                <?php echo Form::text('opd_id', null, array('class' => 'form-control', 'placeholder' => lang('patient.opd_id'))); ?>

                                </div>
                                </div>

                                <div class="col-md-2 paddingleft0">
                                <div class="form-group">
                                <?php echo Form::label('patient_name', lang('patient.first_name'), array('class' => 'control-label')); ?>

                                <?php echo Form::text('patient_name', null, array('class' => 'form-control', 'placeholder' => lang('patient.first_name'))); ?>

                                </div>
                                </div>

                                <div class="col-md-2 width150 paddingleft0">
                                <div class="form-group">
                                <?php echo Form::label('mobile', lang('patient.mobile'), array('class' => 'control-label')); ?>

                                <?php echo Form::text('mobile', null, array('class' => 'form-control', 'placeholder' =>  lang('patient.mobile'))); ?>

                                </div>
                                </div>

                                <div class="col-md-2 paddingleft0">
                                <div class="form-group">
                                <?php echo Form::label('address', lang('patient.address'), array('class' => 'control-label')); ?>

                                <?php echo Form::text('address', null, array('class' => 'form-control', 'placeholder' =>  lang('patient.address'))); ?>

                                </div>
                                </div>

                                <div class="col-sm-3 margintop20">
                                <div class="form-group">
                                <?php echo Form::hidden('form-search', 1); ?>

                                <?php echo Form::submit(lang('reports.filter'), array('class' => 'btn btn-primary', 'title' => lang('reports.filter'))); ?>

                                <a href="<?php echo route('patient-registration.index'); ?>" class="btn btn-primary" title="<?php echo lang('reports.reset_filter'); ?>"> <?php echo lang('reports.reset_filter'); ?></a>
                                </div>
                                </div>
                                </div>
                                <?php echo Form::close(); ?>

                                </div>
                                <div class="row">
                                  <div class="col-md-12">
                                    <!-- start: BASIC TABLE PANEL -->
                                    <div class="panel panel-default" style="position: static;">
                                        <div class="panel-heading">
                                            <i class="fa fa-external-link-square"></i> &nbsp;
                                            <?php echo lang('patient.patients_list'); ?>

                                        </div>
                                        <div class="panel-body">
                                            <div class="col-md-3 text-right pull-right padding0 marginbottom10">
                                                <?php echo lang('common.per_page'); ?>: <?php echo Form::select('name', ['20' => '20', '40' => '40', '100' => '100', '200' => '200', '300' => '300'], '20', ['id' => 'per-page']); ?>

                                            </div>
                                            <div class="col-md-3 padding0 marginbottom10">
                                                <?php echo Form::hidden('page', 'search'); ?>

                                                <?php echo Form::hidden('_token', csrf_token()); ?>

                                                
                                            </div>
                                            <table id="paginate-load" data-route="<?php echo e(route('patient-registration.paginate')); ?>" class="table table-hover clearfix margin0 col-md-12 padding0">
                                            </table>
                                        </div>
                                    </div>
                                    <!-- end: BASIC TABLE PANEL -->
                                   </div>   
                                </div>

                            <?php endif; ?>

                            <div class="row">
                                <?php if(isDoctor()): ?>
                                    <div class="col-md-6">
                                        <h2 class="bg-red margin0 padding10"> :: Pending Patient Visit(s) </h2>
                                        <table class="table table-bordered">
                                            <tr>
                                                <th><?php echo lang('common.id'); ?></th>
                                                <th><?php echo lang('opd_master.visit_date'); ?></th>
                                                <th><?php echo lang('patient.patient_code'); ?></th>
                                                <th><?php echo lang('patient.first_name'); ?></th>
                                                <th><?php echo lang('patient.age'); ?> / <?php echo lang('patient.gender'); ?></th>

                                                
                                                <th><?php echo lang('common.action'); ?></th>
                                            </tr>

                                            <?php
                                                $index = 1;
                                                $genderArr = lang('common.genderArray');
                                                $bloodGroupArr = lang('common.bloodGroupArr');

                                            ?>

                                            <?php if(count($pendingVisits) > 0): ?>
                                                <?php $__currentLoopData = $pendingVisits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo $index++; ?></td>
                                                        <td> <?php echo $detail->visit_date; ?> </td>
                                                        <td> <?php echo $detail->patient_code; ?> </td>
                                                        <td>
                                                            <?php echo $detail->first_name; ?>

                                                        </td>
                                                        <td><?php echo $detail->age; ?> <?php if($detail->age): ?> <?php endif; ?> / <?php if($detail->gender != ''): ?> <?php echo $genderArr[$detail->gender]; ?> <?php endif; ?></td>
                                                        

                                                        <td> <a href="<?php echo route('patient.opd-visit', $detail->id); ?>" class="btn btn-xs btn-info"><i class="fa fa-mail-forward"></i> View </a></td>
                                                    </tr>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                   
                                            <?php endif; ?>
                                        </table>
                                    </div>

                                    <div class="col-md-6 paddingleft0">
                                        <h2 class="bg-green margin0 padding10"> :: Completed Patient Visit(s) </h2>
                                        <table class="table table-bordered">
                                            <tr>
                                                <th><?php echo lang('common.id'); ?></th>
                                                <th><?php echo lang('patient.patient_code'); ?></th>
                                                <th><?php echo lang('patient.first_name'); ?></th>
                                                <th><?php echo lang('patient.age'); ?> / <?php echo lang('patient.gender'); ?></th>
                                                <th><?php echo lang('common.action'); ?></th>
                                            </tr>

                                            <?php
                                                $index = 1;
                                                $genderArr = lang('common.genderArray');
                                                $bloodGroupArr = lang('common.bloodGroupArr');
                                            ?>
                                            <?php if(count($completedVisits) > 0): ?>
                                                <?php $__currentLoopData = $completedVisits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo $index++; ?></td>
                                                        <td> <?php echo $detail->patient_code; ?> </td>
                                                        <td>
                                                            <?php echo $detail->first_name; ?>

                                                        </td>
                                                        <td><?php echo $detail->age; ?> <?php if($detail->age): ?> <?php endif; ?> / <?php if($detail->gender != ''): ?> <?php echo $genderArr[$detail->gender]; ?> <?php endif; ?> </td>
                                                        <td> <a href="<?php echo route('patient.opd-visit-print', $detail->id); ?>" class="btn btn-xs btn-success"><i class="fa fa-eye"></i> View </a></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <!--     <tr>
                                                <td colspan="6">
                                                    <a href="<?php echo route('patient.daily-opd-list'); ?>" class="btn btn-danger btn-block"> View All OPD(s)</a>
                                                </td>
                                            </tr> -->
                                        </table>
                                    </div>
                                <?php endif; ?>

                                <?php if(isStaff()): ?>


                                    <?php
                                        $route = "report.patient-wise-visits";
                                        if($t == 2) {
                                            $route = "report.ipd-patients";
                                        }
                                    ?>
                                    <div class="col-md-12">
                                        <h2 class="bg-red margin0 padding10"> :: Procedure Search </h2>
                                        <div class="col-md-12 padding0">
                                            <?php echo Form::open(array('method' => 'POST', 'route' => array($route), 'id' => 'ajaxForm')); ?>

                                            <div class="row margintop10">
                                                <div class="col-md-2 width150">
                                                    <div class="form-group">
                                                        <?php echo Form::label('p_type', "Procedure For", array('class' => 'control-label')); ?>

                                                        <div class="control-label">
                                                            <?php echo Form::radio('p_type', 1, ($t == 1) ? true : false, array('class' => 'p_type')); ?> OPD &nbsp; &nbsp; &nbsp;
                                                            <?php echo Form::radio('p_type', 2, ($t == 2) ? true : false, array('class' => 'p_type')); ?> IPD
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-2 width115 paddingleft0 opd_procedure <?php if($t != 1): ?> hidden <?php endif; ?>">
                                                    <div class="form-group">
                                                        <!-- <?php echo Form::label('opd_number', lang('patient.opd_number'), array('class' => 'control-label')); ?> -->
                                                        <?php echo Form::text('opd_number', null, array('class' => 'form-control', 'placeholder' => lang('patient.opd_number'))); ?>

                                                    </div>
                                                </div>

                                                <div class="col-md-2 width115 paddingleft0 ipd_procedure <?php if($t != 2): ?> hidden <?php endif; ?>">
                                                    <div class="form-group">
                                                    <!-- <?php echo Form::label('ipd_number', lang('ipd_master.ipd_number'), array('class' => 'control-label')); ?> -->
                                                        <?php echo Form::text('ipd_number', null, array('class' => 'form-control', 'placeholder' => lang('ipd_master.ipd_number'))); ?>

                                                    </div>
                                                </div>

                                                <div class="col-md-2 width150 paddingleft0">
                                                    <div class="form-group">
                                                        <!-- <?php echo Form::label('patient_code', lang('patient.patient_code'), array('class' => 'control-label')); ?> -->
                                                        <?php echo Form::text('patient_code', null, array('class' => 'form-control', 'placeholder' => lang('patient.patient_code'))); ?>

                                                    </div>
                                                </div>

                                                <div class="col-md-2 width150 paddingleft0">
                                                    <div class="form-group">
                                                       <!--  <?php echo Form::label('patient_name', lang('patient.first_name'), array('class' => 'control-label')); ?> -->
                                                        <?php echo Form::text('patient_name', null, array('class' => 'form-control', 'placeholder' => lang('patient.first_name'))); ?>

                                                    </div>
                                                </div>

                                                <div class="col-md-2 width115 date paddingleft0">
                                                    <div class="form-group">
                                                        <?php echo Form::text('from_date', null, array('class' => 'form-control date-picker from_date', 'placeholder' => lang('reports.from_date'))); ?>

                                                    </div>
                                                </div>


                                                <div class="col-md-2 width115 date paddingleft0">
                                                    <div class="form-group">
                                                        <?php echo Form::text('to_date', null, array('class' => 'form-control date-picker to_date', 'placeholder' =>  lang('reports.to_date'))); ?>

                                                    </div>
                                                </div>
                                                <div class="col-md-2 paddingleft0">
                                                    <div class="form-group">
                                                        <?php echo Form::hidden('form-search', 1); ?>

                                                        <?php echo Form::hidden('staff-search', 1); ?>

                                                        <?php echo Form::hidden('report_type', 1); ?>

                                                        <?php echo Form::submit(lang('reports.filter'), array('class' => 'btn btn-primary', 'title' => lang('reports.filter'))); ?>

                                                        <a href="<?php echo route("home"); ?>" class="btn btn-primary" title="<?php echo lang('reports.reset_filter'); ?>"> <?php echo lang('reports.reset_filter'); ?></a>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            
                                            <?php echo Form::close(); ?>

                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <h2 class="bg-green margin0 padding10"> :: Procedure Results </h2>
                                        <div class="col-md-12 padding0">
                                            <table id="paginate-load" data-route="<?php echo e(route($route)); ?>" class="table table-responsive table-hover clearfix margin0 col-md-12 padding0 table-fullbox">
                                            </table>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <!-- end: TEXT FIELDS PANEL -->
                </div>
            </div>
        </div>
    </div>
    <!-- /#page-wrapper -->

    <script>
        // Submit modal form with ajax
        $('body').on('change', '.p_type', function(event)
        {
            var val = $(this).val();
            if (val == 1) {
                /*$('.opd_procedure').removeClass('hidden');
                $('.ipd_procedure').addClass('hidden');*/
                window.location.href = "<?php echo route("home", ['t' => 1]); ?>";
            } else {
                /*$('.ipd_procedure').removeClass('hidden');
                $('.opd_procedure').addClass('hidden');*/
                window.location.href = "<?php echo route("home", ['t' => 2]); ?>";
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>