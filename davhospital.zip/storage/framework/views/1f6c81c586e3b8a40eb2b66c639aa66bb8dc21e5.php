<thead>
<tr>
    <th width="5%" class="text-center"><?php echo lang('common.id'); ?></th>
    <th>
        <?php echo lang('hsn_code.hsn_code'); ?>

    </th>

    <?php if(hasMenuRoute('hsn-code.edit') || isAdmin()): ?>
      <th width="6%" class="text-center"> <?php echo lang('common.status'); ?> </th>
    <?php endif; ?>
    <?php if(hasMenuRoute('hsn-code.drop') || hasMenuRoute('hsn-code.edit') || isAdmin()): ?>
      <th class="text-center">
          <?php echo lang('common.action'); ?>

      </th>
    <?php endif; ?>
</tr>
</thead>
<tbody>
<?php $index = 1; ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr id="order_<?php echo e($detail->id); ?>">
    <td class="text-center"><?php echo pageIndex($index++, $page, $perPage); ?></td>
    <td>
    <?php if(hasMenuRoute('hsn-code.edit') || isAdmin()): ?>
     <a title="<?php echo lang('common.edit'); ?>" href="<?php echo route('hsn-code.edit', [$detail->id]); ?>">
        <?php echo $detail->hsn_code; ?>

     </a>
     <?php else: ?>
        <?php echo $detail->hsn_code; ?>

     <?php endif; ?>
    </td>
    <?php if(hasMenuRoute('hsn_code.toggle') || isAdmin()): ?>
      <td class="text-center">
        <a title="<?php echo lang('common.status'); ?>" href="javascript:void(0);" class="toggle-status" data-message="<?php echo lang('messages.change_status'); ?>" data-route="<?php echo route('hsn_code.toggle', $detail->id); ?>">
            <?php echo Html::image('assets/images/' . $detail->status . '.gif'); ?>

        </a>
      </td>
    <?php endif; ?>
      <td class="text-center col-md-1">
          <?php if(hasMenuRoute('hsn-code.edit') || isAdmin()): ?>
            <a title="<?php echo lang('common.edit'); ?>" class="btn btn-xs btn-primary" href="<?php echo e(route('hsn-code.edit', [$detail->id])); ?>"><i class="fa fa-edit"></i></a>
          <?php endif; ?>
          
      </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if(count($data) < 1): ?>
<tr>
    <td class="text-center" colspan="9"> <?php echo lang('messages.no_data_found'); ?> </td>
</tr>
<?php else: ?>
<tr class="margintop10">
    <td colspan="4">
        <?php echo paginationControls($page, $total, $perPage); ?>

    </td>
</tr>
<?php endif; ?>
</tbody>