<?php $__env->startSection('content_header'); ?>
	<section class="content-header">
		<h1>
			<?php $route = \Route::currentRouteName(); ?>
			<?php if($route == "report.patient-wise-visits"): ?>
				<?php echo string_manip(lang('reports.report'), 'UCW'); ?> - <?php echo lang('opd_master.patient_wise_visits'); ?>

			<?php elseif($route == "report.doctor-wise-visits"): ?>
				<?php echo string_manip(lang('reports.report'), 'UCW'); ?> - <?php echo lang('opd_master.doctor_wise_visits'); ?>

			<?php elseif($route == "report.department-wise-visits"): ?>
				<?php echo string_manip(lang('reports.report'), 'UCW'); ?> - <?php echo lang('opd_master.department_wise_visits'); ?>

			<?php elseif($route == "report.opd-visits"): ?>
				<?php echo string_manip(lang('reports.report'), 'UCW'); ?> - <?php echo lang('opd_master.advanced_opd_search'); ?>

			<?php endif; ?>
		</h1>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div id="page-wrapper">
		
		<?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<div class="col-md-12 padding0">
			<?php echo Form::open(array('method' => 'POST', 'route' => array($route), 'id' => 'ajaxForm')); ?>

			<div class="row">
				<?php if(!isDoctor()): ?>
					<?php if($route == "report.doctor-wise-visits"): ?>
						<div class="col-sm-2">
							<div class="form-group">
								<?php echo Form::label('doctor', lang('doctor.doctor'), array('class' => 'control-label')); ?>

								<?php echo Form::select('doctor', $doctors, null, array('class' => 'form-control padding0 select2')); ?>

							</div>
						</div>
					<?php endif; ?>

					<?php if($route == "report.department-wise-visits"): ?>
						<div class="col-sm-2">
							<div class="form-group">
								<?php echo Form::label('department', lang('department.department'), array('class' => 'control-label')); ?>

								<?php echo Form::select('department', $departments, null, array('class' => 'form-control padding0 select2')); ?>

							</div>
						</div>
					<?php endif; ?>

					<?php if($route == "report.patient-wise-visits"): ?>
						<div class="col-md-3">
							<div class="form-group">
								<?php echo Form::label('patient_name', lang('patient.first_name'), array('class' => 'control-label')); ?>

								<?php echo Form::text('patient_name', null, array('class' => 'form-control', 'placeholder' => lang('patient.first_name'))); ?>

							</div>
						</div>
					<?php endif; ?>

					<?php if($route == "report.opd-visits"): ?>
						<div class="col-sm-2">
							<div class="form-group">
								<?php echo Form::label('doctor', lang('doctor.doctor'), array('class' => 'control-label')); ?>

								<?php echo Form::select('doctor', $doctors, null, array('class' => 'form-control padding0 select2')); ?>

							</div>
						</div>
						<div class="col-sm-2 paddingleft0">
							<div class="form-group">
								<?php echo Form::label('department', lang('department.department'), array('class' => 'control-label')); ?>

								<?php echo Form::select('department', $departments, null, array('class' => 'form-control padding0 select2')); ?>

							</div>
						</div>
						<div class="col-md-2 paddingleft0">
							<div class="form-group">
								<?php echo Form::label('patient_name', lang('patient.first_name'), array('class' => 'control-label')); ?>

								<?php echo Form::text('patient_name', null, array('class' => 'form-control', 'placeholder' => lang('patient.first_name'))); ?>

							</div>
						</div>
					<?php endif; ?>
				<?php endif; ?>

				<div class="col-md-2 width125 date paddingleft0">
					<div class="form-group">
						<?php echo Form::label('from_date', lang('reports.from_date'), array('class' => 'control-label')); ?>

						<?php echo Form::text('from_date', null, array('class' => 'form-control date-picker from_date', 'placeholder' => lang('reports.from_date'))); ?>

					</div>
				</div>


				<div class="col-md-2 width125 date paddingleft0">
					<div class="form-group">
						<?php echo Form::label('to_date', lang('reports.to_date'), array('class' => 'control-label')); ?>

						<?php echo Form::text('to_date', null, array('class' => 'form-control date-picker to_date', 'placeholder' =>  lang('reports.to_date'))); ?>

					</div>
				</div>

				<div class="col-sm-3 margintop20 paddingleft0">
					<div class="form-group">
						<?php echo Form::hidden('form-search', 1); ?>

						<?php echo Form::hidden('report_type', 1); ?>

						<?php echo Form::submit(lang('reports.filter'), array('class' => 'btn btn-primary', 'title' => lang('reports.filter'))); ?>

						<a href="<?php echo route($route); ?>" class="btn btn-primary" title="<?php echo lang('reports.reset_filter'); ?>"> <?php echo lang('reports.reset_filter'); ?></a>
					</div>
				</div>
			</div>
			<?php echo Form::close(); ?>

		</div>

		<div class="row">
			<div class="col-md-12">
				<!-- start: BASIC TABLE PANEL -->
				<div class="panel panel-default" style="position: static;">
					<div class="panel-heading">
						<i class="fa fa-external-link-square"></i> &nbsp;
						<?php echo lang('opd_master.opd_visits'); ?>

					</div>
					<div class="panel-body padding0">
						<div class="col-md-6 hidden marginbottom10">
							<?php echo Form::hidden('page', '1'); ?>

						</div>
						<div id="p-report">
							<?php $json = ''; $route = \Route::currentRouteName(); ?>
							<table id="paginate-load" data-route="<?php echo e(route($route)); ?>" class="table table-bordered margin0 col-md-12 padding0 font-14">
							</table>

							


						</div>
					</div>
				</div>
				<!-- end: BASIC TABLE PANEL -->
			</div>
		</div>
	</div>
	<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script type="text/javascript">
		$(document).ready(function(){
			$(".report_type").change(function()
			{
				var report_type = $(this).val();

				if(report_type == '1')
				{
					$(".month, .year").addClass("hidden");
					$(".date").removeClass("hidden");
					//$(".from_date").attr("required", "required");
					//$(".to_date").attr("required", "required");
				}
				else if(report_type == '2')
				{
					$(".date, .year").addClass("hidden");
					$(".month").removeClass("hidden");
					//$(".from_date").removeAttr("required");
					//$(".to_date").removeAttr("required");
				}
				else if(report_type == '3')
				{
					$(".month, .date").addClass("hidden");
					$(".year").removeClass("hidden");
					$(".from_date").removeAttr("required");
					$(".to_date").removeAttr("required");
				}
			});

			$('body').on('click', 'a.__switcher', function(event)
			{
				$(".backDrop").fadeIn( 100, "linear" );
				$(".loader").fadeIn( 100, "linear" );

				$(".__switcher").removeClass('hidden');
				$(this).addClass('hidden');
				var targetShow = $(this).data("show");
				var targetHide = $(this).data("hide");

				//alert(targetShow + ' ' + targetHide); return false;
				$(targetShow).removeClass('hidden');
				$(targetHide).addClass('hidden');
				$(targetShow).removeClass('print_hide');
				$(targetHide).addClass('print_hide');

				setTimeout(function (){
					$(".backDrop").fadeOut( 100, "linear" );
					$(".loader").fadeOut( 100, "linear" );
				}, 80);
			});
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>