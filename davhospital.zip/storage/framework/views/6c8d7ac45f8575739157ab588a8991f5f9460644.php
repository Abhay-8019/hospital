<?php $__env->startSection('content_header'); ?>
    <section class="content-header">
        <div class="pull-right">
            <a class="btn btn-danger btn-xs" href="<?php echo route('hospital.create'); ?>">
                <i class="fa fa-plus-circle"></i> <?php echo lang('common.create_heading', lang('hospital.hospital')); ?>

            </a>
        </div>
        <h1>
            <?php echo lang('hospital.hospitals'); ?>

            <small><?php echo lang('common.list_record'); ?></small>
        </h1>
        <ol class="breadcrumb hidden">
            <li><a href="javascript:void(0)" class="btn btn-primary btn-xs _back"><i class="fa fa-arrow-left"></i> <?php echo lang('common.back'); ?></a></li>
            
            
            <li><a class="btn btn-info btn-xs" href="<?php echo route('hospital.create'); ?>"><?php echo lang('common.create_heading', lang('hospital.hospital')); ?></a></li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">

        
        <?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default" style="position:static;">
                    <div class="panel-heading">
                        <i class="fa fa-external-link-square"></i> &nbsp;
                        <?php echo lang('hospital.hospital_list'); ?>

                    </div>
                    <div class="panel-body">
                        <form id="serachable" action="<?php echo e(route('hospital.action')); ?>" method="post">
                            <div class="col-md-3 text-right pull-right padding0 marginbottom10">
                                <?php echo lang('common.per_page'); ?>: <?php echo Form::select('name', ['20' => '20', '40' => '40', '100' => '100', '200' => '200', '300' => '300'], '20', ['id' => 'per-page']); ?>

                            </div>
                            <div class="col-md-3 padding0 marginbottom10">
                                <?php echo Form::hidden('page', 'search'); ?>

                                <?php echo Form::hidden('_token', csrf_token()); ?>

                                <?php echo Form::text('name', null, array('class' => 'form-control live-search', 'placeholder' => 'Search hospital by name')); ?>

                            </div>
                            <table id="paginate-load" data-route="<?php echo e(route('hospital.paginate')); ?>" class="table table-hover clearfix margin0 col-md-12 padding0">
                            </table>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>