<?php $__env->startSection('content_header'); ?>
<section class="content-header">
    <h1>
        <?php echo lang('ipd_master.ipd_visit'); ?>

        <small><?php echo lang('common.create_heading', 'IPD History'); ?></small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> <?php echo lang('common.back'); ?></a></li>
        <li class="active"><?php echo lang('ipd_master.ipd_visit'); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <!-- start: PAGE CONTENT -->
    
    
    <?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-12 padding0">
            <!-- previous patient form id => patient-form -->
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading padding0">
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active">
                                <a href="#personal_tab" aria-controls="personal_tab" role="tab" data-toggle="tab">
                                    <i class="fa fa-external-link-square"></i>
                                    <?php echo lang('ipd_master.ipd_visit_detail'); ?>

                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="tab-content">
                                <div id="personal_tab" class="tab-pane fade in active">
                                    <?php echo Form::open(array('method' => 'POST', 'route' => array('patient.ipd-store', $result->id), 'id' => 'ajaxSave', 'class' => 'form-horizontal')); ?>

                                    <?php
                                        $genderArr = lang('common.genderArray');
                                        $bloodGroupArr = lang('common.bloodGroupArr');
                                    ?>
                                    <div class="col-md-12">
                                        <h1>
                                            Patient Detail
                                        </h1>
                                        <hr/>
                                        <table class="table table-bordered">
                                            <tr>
                                                <td width="15%"><b><?php echo lang('patient.first_name'); ?></b></td>
                                                <td width="18%"><?php echo $patient->first_name; ?></td>
                                                <td width="15%">
                                                    <div class="required">
                                                        <?php echo Form::label('doctor', lang('doctor.doctor'), array('class' => 'control-label')); ?>

                                                    </div>
                                                </td>
                                                <td width="20%"><?php echo Form::select('doctor', $doctors, null, array('class' => 'form-control select2 padding0', 'id' => 'doctor')); ?> </td>
                                                <td width="15%">
                                                    <div class="required">
                                                        <?php echo Form::label('ipd_number', lang('ipd_master.ipd_number'), array('class' => 'control-label')); ?>

                                                    </div>
                                                </td>
                                                <td><?php echo Form::text('ipd_number', $ipdNumber, array('class' => 'form-control', 'readonly' => true)); ?></td>
                                            </tr>
                                            <tr>
                                                <td><b><?php echo lang('patient.gender'); ?></b></td>
                                                <td><?php if($patient->gender != ''): ?> <?php echo $genderArr[$patient->gender]; ?> <?php endif; ?></td>
                                                <td>
                                                    <div class="required">
                                                        <?php echo Form::label('department', lang('department.department'), array('class' => 'control-label')); ?>

                                                    </div>
                                                </td>
                                                <td> <?php echo Form::select('department', $departments, null, array('class' => 'form-control select2 padding0', 'id' => 'department')); ?> </td>
                                                <td>
                                                    <div class="required">
                                                        <?php echo Form::label('admission_date', lang('ipd_master.visit_date'), array('class' => 'control-label')); ?>

                                                    </div>
                                                </td>
                                                <td><?php echo Form::text('admission_date', date('d-m-Y'), array('class' => 'form-control date-future')); ?></td>
                                            </tr>
                                            <tr>
                                                <td><b><?php echo lang('patient.age'); ?></b></td>
                                                <td><?php echo $patient->age; ?> <?php if($patient->age): ?> Years <?php endif; ?> </td>
                                                <td>
                                                    <div class="required">
                                                        <?php echo Form::label('ward', lang('ward.ward'), array('class' => 'control-label')); ?>

                                                    </div>
                                                </td>
                                                <td>  <?php echo Form::select('ward', $wards, null, array('class' => 'form-control select2 padding0', 'id' => 'ward')); ?> </td>
                                                <td><b> </b></td>
                                                <td> </td>
                                            </tr>
                                            <tr>
                                                <td><b><?php echo lang('patient.blood_group'); ?></b></td>
                                                <td><?php echo $patient->blood_group; ?></td>
                                                <td>
                                                    <div class="required">
                                                        <?php echo Form::label('bed', lang('bed_master.bed_master') . " No", array('class' => 'control-label')); ?>

                                                    </div>
                                                </td>
                                                <td> <?php echo Form::select('bed', $beds, null, array('class' => 'form-control select2 padding0', 'id' => 'bed')); ?> </td>
                                                <td>&nbsp;</td>
                                                <td> &nbsp; </td>
                                            </tr>
                                            <tr>
                                                <td><b><?php echo lang('patient.address'); ?></b></td>
                                                <td colspan="3"><?php echo $patient->address; ?></td>
                                                <td>&nbsp;</td>
                                                <td> &nbsp; </td>
                                            </tr>
                                        </table>
                                    </div>

                                    <div class="col-md-12">
                                        <h1>
                                            1. IPD Medical History
                                            <small>Patient Treatment Detail</small>
                                        </h1>
                                        <hr/>

                                        <div class="form-group clearfix">
                                            <?php echo Form::label('examination', lang('ipd_master.present_illness'), array('class' => 'col-sm-2 control-label')); ?>

                                            <div class="col-sm-8">
                                                <?php echo Form::textarea('present_illness', null, array('class' => 'form-control', 'placeholder' => lang('ipd_master.present_illness'), 'size' => '4x6')); ?>

                                            </div>
                                        </div>

                                        <div class="form-group clearfix">
                                            <?php echo Form::label('complaints', lang('ipd_master.previous_medical'), array('class' => 'col-sm-2 control-label')); ?>

                                            <div class="col-sm-8">
                                                <?php echo Form::textarea('previous_medical', null, array('class' => 'form-control', 'placeholder' => lang('ipd_master.previous_medical'), 'size' => '4x6')); ?>

                                            </div>
                                        </div>

                                        <div class="form-group hidden clearfix">
                                            <?php echo Form::label('present_treatment', lang('ipd_master.present_treatment'), array('class' => 'col-sm-2 control-label')); ?>

                                            <div class="col-sm-8">
                                                <?php echo Form::textarea('present_treatment', null, array('class' => 'form-control', 'placeholder' => lang('ipd_master.present_treatment'), 'size' => '4x6')); ?>

                                            </div>
                                        </div>

                                        <div class="form-group clearfix">
                                            <?php echo Form::label('family_history', lang('ipd_master.family_history'), array('class' => 'col-sm-2 control-label')); ?>

                                            <div class="col-sm-8">
                                                <?php echo Form::textarea('family_history', null, array('class' => 'form-control', 'placeholder' => lang('ipd_master.family_history'), 'size' => '4x6')); ?>

                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <?php echo Form::label('pulse_rate', lang('ipd_master.pulse_rate'), array('class' => 'col-sm-2 control-label')); ?>

                                            <div class="col-sm-1 width125">
                                                <?php echo Form::text('pulse_rate', null, array('class' => 'form-control', 'placeholder' => lang('ipd_master.pulse_rate'))); ?>

                                            </div>

                                            <?php echo Form::label('blood_pressure', lang('ipd_master.blood_pressure'), array('class' => 'col-sm-1 width70 control-label')); ?>

                                            <div class="col-sm-1">
                                                <?php echo Form::text('blood_pressure', null, array('class' => 'form-control', 'placeholder' => lang('ipd_master.blood_pressure'))); ?>

                                            </div>

                                            <?php echo Form::label('temperature', lang('ipd_master.temperature'), array('class' => 'col-sm-1 width70 control-label')); ?>

                                            <div class="col-sm-1">
                                                <?php echo Form::text('temperature', null, array('class' => 'form-control', 'placeholder' => lang('ipd_master.temperature'))); ?>

                                            </div>

                                            <?php echo Form::label('hr', lang('ipd_master.hr'), array('class' => 'col-sm-1 width70 control-label')); ?>

                                            <div class="col-sm-1">
                                                <?php echo Form::text('hr', null, array('class' => 'form-control', 'placeholder' => lang('ipd_master.hr'))); ?>

                                            </div>

                                            <?php echo Form::label('rr', lang('ipd_master.rr'), array('class' => 'col-sm-1 width70 control-label')); ?>

                                            <div class="col-sm-1">
                                                <?php echo Form::text('rr', null, array('class' => 'form-control', 'placeholder' => lang('ipd_master.rr'))); ?>

                                            </div>
                                        </div>

                                        <div class="form-group hidden clearfix">
                                            <?php echo Form::label('other_information', lang('ipd_master.other_information'), array('class' => 'col-sm-2 control-label')); ?>

                                            <div class="col-sm-8">
                                                <?php echo Form::textarea('other_information', null, array('class' => 'form-control', 'placeholder' => lang('ipd_master.other_information'), 'size' => '4x6')); ?>

                                            </div>
                                        </div>

                                        <div class="form-group clearfix">
                                            <?php echo Form::label('general_examination', lang('ipd_master.general_examination'), array('class' => 'col-sm-2 control-label')); ?>

                                            <div class="col-sm-8">
                                                <?php echo Form::textarea('general_examination', null, array('class' => 'form-control', 'placeholder' => lang('ipd_master.general_examination'), 'size' => '4x6')); ?>

                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <hr/>
                                        <h1>
                                            2. Procedures
                                        </h1>

                                        <div class="procedure-placer hidden">
                                            <hr/>
                                            <div class="form-group required">
                                                <?php echo Form::hidden('p_id', $result->patient_id); ?>

                                            </div>
                                            <div class="col-md-10 clearfix">
                                                <div class="clearfix place-template">
                                                    <div class="col-md-12 heavy margintop5 marginbottom10 paddingleft0">
                                                        <div class="col-md-2 padding0 paddingright5">
                                                            <?php echo lang('ipd_master.procedure'); ?>

                                                        </div>

                                                        <div class="col-md-2 padding0 paddingright5">
                                                            <?php echo lang('ipd_master.medicine'); ?>

                                                        </div>

                                                        <div class="col-md-2 width70 padding0 paddingright5">
                                                            <?php echo lang('ipd_master.dose'); ?>

                                                        </div>

                                                        <div class="col-md-3 width90 padding0 paddingright5">
                                                            <?php echo lang('ipd_master.timing'); ?>

                                                        </div>

                                                        <div class="col-md-4 padding0 paddingright5">
                                                            <?php echo lang('ipd_master.remarks'); ?>

                                                        </div>
                                                    </div>

                                                    <div class="col-md-12 margintop5 paddingleft0 data-placer">

                                                        <div class="col-sm-2 padding0 paddingright5">
                                                            <?php echo Form::select('procedure[0]', $procedures, null, array('class' => 'form-control select2 procedure padding0', 'id' => 'procedure0')); ?>

                                                        </div>

                                                        <div class="col-sm-2 padding0 paddingright5">
                                                            <?php echo Form::select('procedure_medicine[0]', $medicines, null, array('class' => 'form-control select2 procedure_medicine padding0', 'id' => 'procedure_medicine0')); ?>

                                                        </div>

                                                        <div class="col-sm-1 width70 padding0 paddingright5">
                                                            <?php echo Form::text('procedure_dose[0]', null, array('class' => 'form-control procedure_dose', 'id' => 'procedure_dose0')); ?>

                                                        </div>

                                                        <div class="col-md-2 width70 padding0">
                                                            <?php echo Form::text('timing[0]', null, array('class' => 'form-control', 'id' => 'timing0')); ?>

                                                        </div>

                                                        <div class="col-md-4 paddingleft5">
                                                            <?php echo Form::textarea('remarks[0]', null, array('class' => 'form-control', 'size' => '3x2')); ?>

                                                        </div>

                                                        <a href="javascript:void(0)" class="btn btn-danger pull-left btn-xs hidden add-hidden remove-this">X</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-8 clearfix">
                                                <a href="javascript:void(0)" class="__add btn btn-success btn-sm"> <i class="fa fa-plus-circle"></i> <?php echo lang('common.add_more'); ?></a>
                                            </div>
                                            <?php echo Form::hidden('addpro', 0, ['id' => 'addpro']); ?>

                                        </div>
                                        <a href="javascript:void(0)" class="btn btn-info btn-sm addpro _addpro"> <i class="fa fa-plus-circle"></i> Add Procedure </a>
                                        <a href="javascript:void(0)" class="btn btn-danger hidden btn-sm removepro _addpro"> <i class="fa fa-times-circle"></i> Remove Procedure </a>
                                    </div>

                                    <div class="col-md-12">
                                        <hr/>
                                        <h1>
                                            3. Medications
                                        </h1>
                                        <div class="medicine-placer hidden">
                                            <hr/>
                                            <div class="col-md-8 clearfix">
                                                <div class="clearfix place-template-m">
                                                    <div class="col-md-12 heavy margintop5 marginbottom10 paddingleft0">
                                                        <div class="col-md-3 padding0 paddingright5">
                                                            <?php echo lang('ipd_master.medicine'); ?>

                                                        </div>

                                                        <div class="col-md-2 width70 padding0 paddingright5">
                                                            <?php echo lang('ipd_master.dose'); ?>

                                                        </div>

                                                        <div class="col-md-2 width70 padding0 paddingright5">
                                                            <?php echo lang('ipd_master.dose_unit'); ?>

                                                        </div>

                                                        <div class="col-md-3 width90 padding0 paddingright5">
                                                            <?php echo lang('ipd_master.timing'); ?>

                                                        </div>

                                                        <div class="col-md-4 padding0 paddingright5">
                                                            <?php echo lang('ipd_master.remarks'); ?>

                                                        </div>
                                                    </div>

                                                    <div class="col-md-12 margintop5 paddingleft0 data-placer">

                                                        <div class="col-sm-3 padding0 paddingright5">
                                                            <?php echo Form::select('medicine[0]', $medicines, null, array('class' => 'form-control select2 medicine padding0', 'id' => 'medicine0')); ?>

                                                        </div>

                                                        <div class="col-sm-1 width70 padding0 paddingright5">
                                                            <?php echo Form::text('medicine_dose[0]', null, array('class' => 'form-control medicine_dose', 'id' => 'medicine_dose0')); ?>

                                                        </div>

                                                        <div class="col-sm-1 width70 padding0 paddingright5">
                                                            <?php echo Form::text('medicine_dose_unit[0]', null, array('class' => 'form-control medicine_dose_unit', 'id' => 'medicine_dose_unit0')); ?>

                                                        </div>

                                                        <div class="col-md-2 width70 padding0">
                                                            <?php echo Form::text('medicine_timing[0]', null, array('class' => 'form-control', 'id' => 'medicine_timing0')); ?>

                                                        </div>

                                                        <div class="col-md-4 paddingleft5">
                                                            <?php echo Form::textarea('medicine_remarks[0]', null, array('class' => 'form-control', 'size' => '3x2')); ?>

                                                        </div>

                                                        <a href="javascript:void(0)" class="btn btn-danger pull-left btn-xs hidden add-hidden-m remove-this-m">X</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-8 clearfix">
                                                <a href="javascript:void(0)" class="__add-m btn btn-success btn-sm"> <i class="fa fa-plus-circle"></i> <?php echo lang('common.add_more'); ?></a>
                                            </div>
                                            <?php echo Form::hidden('addmedi', 0, ['id' => 'addmedi']); ?>

                                        </div>
                                        <a href="javascript:void(0)" class="btn btn-info btn-sm addmedi _addmedi"> <i class="fa fa-plus-circle"></i> Add Medicine </a>
                                        <a href="javascript:void(0)" class="btn btn-danger hidden btn-sm removemedi _addmedi"> <i class="fa fa-times-circle"></i> Remove Medicine </a>
                                    </div>


                                    <div class="col-sm-11 text-center">
                                        <div class="form-group">
                                            <?php echo Form::submit(lang('common.save'), array('class' => 'btn btn-primary btn-lg')); ?>

                                        </div>
                                    </div>
                                    <?php echo Form::close(); ?>

                                </div>

                                <div class="get-template hidden">
                                    <div class="col-md-12 margintop5 paddingleft0 data-placer">

                                        <div class="col-sm-2 padding0 paddingright5">
                                            <?php echo Form::select('procedure', $procedures, null, array('class' => 'form-control sselect2 procedure padding0')); ?>

                                        </div>

                                        <div class="col-sm-2 padding0 paddingright5">
                                            <?php echo Form::select('procedure_medicine', $medicines, null, array('class' => 'form-control sselect2 padding0 procedure_medicine')); ?>

                                        </div>

                                        <div class="col-sm-1 width70 padding0 paddingright5">
                                            <?php echo Form::text('procedure_dose[0]', null, array('class' => 'form-control procedure_dose')); ?>

                                        </div>

                                        <div class="col-md-2 width70 padding0">
                                            <?php echo Form::text('timing[0]', null, array('class' => 'form-control timing')); ?>

                                        </div>

                                        <div class="col-md-4 paddingleft5">
                                            <?php echo Form::textarea('remarks[0]', null, array('class' => 'form-control remarks', 'size' => '3x2')); ?>

                                        </div>
                                        <a href="javascript:void(0)" class="btn btn-danger pull-left btn-xs add-hidden remove-this">X</a>
                                    </div>
                                </div>


                                <div class="get-template-m hidden">
                                    <div class="col-md-12 margintop5 paddingleft0 data-placer">
                                        <div class="col-sm-3 padding0 paddingright5">
                                            <?php echo Form::select('medicine', $medicines, null, array('class' => 'form-control sselect2 padding0 medicine')); ?>

                                        </div>

                                        <div class="col-sm-1 width70 padding0 paddingright5">
                                            <?php echo Form::text('medicine_dose[0]', null, array('class' => 'form-control medicine_dose')); ?>

                                        </div>

                                        <div class="col-sm-1 width70 padding0 paddingright5">
                                            <?php echo Form::text('medicine_dose_unit[0]', null, array('class' => 'form-control medicine_dose_unit')); ?>

                                        </div>

                                        <div class="col-md-2 width70 padding0">
                                            <?php echo Form::text('medicine_timing[0]', null, array('class' => 'form-control medicine_timing')); ?>

                                        </div>

                                        <div class="col-md-4 paddingleft5">
                                            <?php echo Form::textarea('medicine_remarks[0]', null, array('class' => 'form-control medicine_remarks', 'size' => '3x2')); ?>

                                        </div>
                                        <a href="javascript:void(0)" class="btn btn-danger pull-left btn-xs add-hidden-m remove-this-m">X</a>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <!-- end: TEXT FIELDS PANEL -->
            </div>
        </div>    
    </div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready(function()
        {
            $('._addpro').on('click', function(event)
            {
                var addPro = $('#addpro').val();

                if (addPro == 0) {
                    $('.procedure-placer').removeClass('hidden');
                    $('.addpro').addClass('hidden');
                    $('.removepro').removeClass('hidden');
                    $('#addpro').val(1);
                } else {
                    $('.procedure-placer').addClass('hidden');
                    $('.addpro').removeClass('hidden');
                    $('.removepro').addClass('hidden');
                    $('#addpro').val(0);
                }
            });

            $('._addmedi').on('click', function(event)
            {
                var addMedi = $('#addmedi').val();

                if (addMedi == 0) {
                    $('.medicine-placer').removeClass('hidden');
                    $('.addmedi').addClass('hidden');
                    $('.removemedi').removeClass('hidden');
                    $('#addmedi').val(1);
                } else {
                    $('.medicine-placer').addClass('hidden');
                    $('.addmedi').removeClass('hidden');
                    $('.removemedi').addClass('hidden');
                    $('#addmedi').val(0);
                }
            });

            var count = 1;
            $('.__add').on('click', function(event)
            {
                var dimension = $('.get-template').html();

                $('.place-template').append(dimension);

                var target = $('.place-template').find('.data-placer:last');


                target.find(".procedure").attr({
                    'name': 'procedure['+count + ']',
                    'id': 'procedure' + count,
                });

                target.find(".procedure_medicine").attr({
                    'name': 'procedure_medicine['+count + ']',
                    'id': 'procedure_medicine' + count,
                });

                target.find(".procedure_dose").attr({
                    'name': 'procedure_dose['+count + ']',
                    'id': 'procedure_dose' + count,
                });

                target.find(".timing").attr({
                    'name': 'timing['+count + ']',
                    'id': 'timing' + count,
                });

                target.find(".remarks").attr({
                    'name': 'remarks['+count + ']',
                    'id': 'remarks' + count,
                });

                target.find('.sselect2').select2({
                    allowClear: true
                });
                $(".sselect2").trigger('select2:updated');

                $('.remove-this').removeClass('hidden');
                count++;
            });

            $('body').on('click', 'a.remove-this', function() {
                var length = $('a.remove-this').length;
                if(length > 2) {
                    $(this).parent().remove();
                }
                var length = $('a.remove-this').length;
                if (length == 2) {
                    $('.add-hidden').addClass('hidden');
                }
            });


            var count2 = 1;
            $('.__add-m').on('click', function(event)
            {
                var dimension = $('.get-template-m').html();

                $('.place-template-m').append(dimension);

                var target = $('.place-template-m').find('.data-placer:last');

                target.find(".medicine").attr({
                    'name': 'medicine['+count2 + ']',
                    'id': 'medicine' + count2,
                });

                target.find(".medicine_dose").attr({
                    'name': 'medicine_dose['+ count2 + ']',
                    'id': 'medicine_dose' + count2,
                });

                target.find(".medicine_dose_unit").attr({
                    'name': 'medicine_dose_unit['+ count2 + ']',
                    'id': 'medicine_dose_unit' + count2,
                });

                target.find(".medicine_timing").attr({
                    'name': 'medicine_timing['+ count2 + ']',
                    'id': 'medicine_timing' + count2,
                });

                target.find(".medicine_remarks").attr({
                    'name': 'medicine_remarks['+ count2 + ']',
                    'id': 'medicine_remarks' + count2,
                });

                target.find('.sselect2').select2({
                    allowClear: true
                });
                $(".sselect2").trigger('select2:updated');

                $('.remove-this-m').removeClass('hidden');
                count++;
            });

            $('body').on('click', 'a.remove-this-m', function() {
                var length = $('a.remove-this-m').length;
                if(length > 2) {
                    $(this).parent().remove();
                }
                var length = $('a.remove-this-m').length;
                if (length == 2) {
                    $('.add-hidden-m').addClass('hidden');
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>