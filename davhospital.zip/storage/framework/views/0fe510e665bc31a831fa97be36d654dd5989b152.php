<?php $__env->startSection('content_header'); ?>
    <section class="content-header">
        <h1>
            <?php echo lang('common.edit_heading', lang('test.test')); ?> #<?php echo $result->name; ?>

            <small><?php echo lang('common.record_update'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> <?php echo lang('common.back'); ?></a></li>
            <li><a href="<?php echo route('add-test.index'); ?>"><?php echo lang('test.test'); ?></a></li>
            <li class="active"><?php echo lang('common.edit_heading', lang('test.test')); ?></li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
        <!-- start: PAGE CONTENT -->

        
        <?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="row">
            <div class="col-md-12 padding0">
                <?php echo Form::model($result, array('route' => array('add-test.update', $result->id), 'method' => 'PATCH', 'id' => 'ajaxSave', 'class' => 'form-horizontal')); ?>

                        <!-- previous AddTest form id => AddTest-form -->
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-external-link-square"></i> &nbsp;
                            <?php echo lang('test.test_detail'); ?>

                        </div>
                        <div class="panel-body">

                            <div class="row">
                                <div class="col-sm-6">

                                    <div class="form-group required">
                                        <?php echo Form::label('name', lang('test_category.test_category'), array('class' => 'col-sm-3 control-label')); ?>

                                        <div class="col-sm-8">
                                            <?php echo Form::select('test_category', $category, ($result->test_category_id) ? $result->test_category_id : null, array('class' => 'form-control select2 padding0', 'id' => 'test_category')); ?>

                                        </div>

                                    </div>

                                    <div class="form-group required">
                                        <?php echo Form::label('name', lang('common.name'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::text('name', ($result->name) ? $result->name : null, array('class' => 'form-control')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        <?php echo Form::label('cost', lang('test.test_cost'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::text('cost', ($result->cost) ? $result->cost : null, array('class' => 'form-control')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <?php echo Form::label('detail', lang('test.description'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::textarea('description', ($result->description) ? $result->description : null, array('class' => 'form-control', 'rows'=>'4')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <?php echo Form::label('status', lang('common.active') . '&nbsp;', array('class' => 'col-sm-3 control-label')); ?>

                                        <div class="col-sm-5 margintop8">
                                            <?php echo Form::checkbox('status', '1', ($result->status == '1') ? true : false); ?>

                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">

                                    <div class="form-group">
                                        <?php echo Form::label('minVal', lang('test.min_value'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::text('minval', ($result->minval) ? $result->minval : null, array('class' => 'form-control')); ?>

                                        </div>

                                    </div>

                                    <div class="form-group">
                                        <?php echo Form::label('maxVal', lang('test.max_value'), array('class' => 'col-sm-3 control-label')); ?>


                                        <div class="col-sm-8">
                                            <?php echo Form::text('maxval', ($result->maxval) ? $result->maxval : null, array('class' => 'form-control')); ?>

                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        <?php echo Form::label('name', lang('test_category.sub_tests'), array('class' => 'col-sm-3 control-label')); ?>

                                        <div class="col-sm-8">
                                            <?php echo Form::select('sub_tests[]', $tests, ($result->sub_test_ids != "") ? explode(',', $result->sub_test_ids) : [], array('class' => 'form-control fSelect padding0', 'multiple' => true, 'id' => 'sub_tests')); ?>

                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-11 margintop20 clearfix text-center">
                                    <div class="form-group">
                                        <?php echo Form::hidden('permission_id', (isset($userPermissions) && $userPermissions != '')? $userPermissions->permission_id : null); ?>

                                        <?php echo Form::submit(lang('common.update'), array('class' => 'btn btn-primary btn-lg')); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end: TEXT FIELDS PANEL -->
                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
    <!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>