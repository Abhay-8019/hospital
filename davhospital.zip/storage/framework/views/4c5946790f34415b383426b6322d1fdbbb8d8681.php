<?php $__env->startSection('content_header'); ?>
    <section class="content-header">
        <h1>
            <?php echo lang('patient_test.generate_report'); ?> #<?php echo e($result->receipt_no); ?>

        </h1>
        <ol class="breadcrumb">
            <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> <?php echo lang('common.back'); ?></a></li>
            <li><a href="<?php echo route('patient-test.index'); ?>"><?php echo lang('patient_test.patient_tests'); ?></a></li>
            <li class="active"><?php echo lang('common.edit_heading', lang('patient_test.patient_test')); ?> </li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <style>
        table tr td {
            font-family: Verdana, Arial, Helvetica, sans-serif;
        }

        table.innertable tr td {
            font-size: 13px;
        }

        table.innertable tr td.trb {
            border-right: 1px solid #000000;
            border-bottom: 1px solid #000000;
            border-top: 1px solid #000000;
        }

        table.innertable tr td.tb {
            border-top: 1px solid #000000;
            border-bottom: 1px solid #000000;
        }

        table.innertable tr td.rb {
            border-right: 1px solid #000000;
            border-bottom: 1px solid #000000;
        }

        table.innertable tr td.r {
            border-right: 1px solid #000000;
        }

        table.innertable tr td.b {
            border-bottom: 1px solid #000000;
        }

        table.innertable tr td.t {
            border-top: 1px solid #000000;
        }
        h4.test-head {
            font-size: 18px;
            margin: 8px 0;
            text-align: center;
            text-decoration: underline;
            font-weight: bold;
        }
    </style>
    
    <?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-12 padding0">
            <?php echo Form::open(array('method' => 'POST', 'route' => array('patient-test.generate_report', $result->id), 'id' => 'ajaxSave', 'class' => 'form-horizontal')); ?>

            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <i class="fa fa-external-link-square"></i> &nbsp;
                        <?php echo lang('patient_test.report_detail'); ?>

                    </div>
                    <div class="panel-body">

                        <table width="950" border="0" align="center" cellpadding="0" cellspacing="0">
                            <tr>
                                <td>
                                    <table style="border:1px solid #ececec;" cellpadding="6" cellspacing="0" width="100%">
                                        <tbody>
                                        <tr>
                                            <td width="50%"><strong>Receipt No. </strong> <?php echo $result->receipt_no; ?></td>
                                            <td width="30%" align="right"><strong>Date: </strong> <input type="text" class="date-picker" name="test_date" value="<?php echo ($result->report_generate_date == "") ? date('d-m-Y') : dateFormat('d-m-Y', $result->report_generate_date); ?>" /> </td>
                                            <td align="center">&nbsp;</td>
                                        </tr>

                                        <tr>
                                            <td align="center">&nbsp;</td>
                                            <td align="center">&nbsp;</td>
                                            <td align="center">&nbsp;</td>
                                        </tr>

                                        <tr>
                                            <td><strong>Patient Name </strong> <?php echo $patient->first_name; ?> (<?php echo $patient->patient_code; ?>)</td>
                                            <td align="center"><strong>Age </strong> <?php echo $patient->age; ?> years</td>
                                            <td align="center">&nbsp;</td>
                                        </tr>
                                        </tbody>
                                    </table>
                                    <br/>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <table width="100%" border="0" cellspacing="0" cellpadding="4" >
                                        <tr>
                                            <td align="left" class="trb"><strong>Test Name </strong></td>
                                            <td  align="left" class="trb"><strong>Test Value </strong></td>
                                            <td  align="left" class="tb"><strong> Test Range </strong></td>
                                        </tr>
                                        <?php $total = 0; $subTests = []; ?>
                                        <?php $__currentLoopData = $result->tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <?php
                                                    $testValue = '';
                                                    if (array_key_exists($detail->id, $tests))
                                                    {
                                                        $testValue = $tests[$detail->id]['test_result'];
                                                        $subTest = $tests[$detail->id]['sub_tests_result'];
                                                        if ($subTest != "") {
                                                            $subTests = json_decode($subTest, true);
                                                        }
                                                    }
                                                ?>
                                                <td align="left" class="rb"><?php echo $detail->diagnostics->name; ?> </td>
                                                <td align="left" class="rb">
                                                    <?php if(count($subTest) < 1): ?>
                                                        <?php echo Form::text('test['.$detail->id.']', $testValue); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td align="left" class="rb">
                                                    <?php if(count($subTest) < 1): ?>
                                                        <?php echo $detail->diagnostics->testrange; ?>

                                                    <?php endif; ?>
                                                    <?php
                                                    /*$normal2 = ($detail->diagnostics->maxval != "") ? '-' . $detail->diagnostics->maxval : '';
                                                    $unit = ($detail->diagnostics->unit != "") ? ' ' . $detail->diagnostics->unit : '';
                                                    echo '('.$detail->diagnostics->minval.$normal2.$unit.')';*/
                                                    ?>
                                                </td>
                                            </tr>
                                            <?php if(count($subTests) > 0): ?>
                                                <?php $__currentLoopData = $subTests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testId => $testValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <?php $tDet = getTestName(['id' => $testId]); ?>
                                                        <td align="left" class="rb">
                                                            &nbsp; <?php echo $tDet->name; ?>

                                                        </td>
                                                        <td align="left" class="rb">
                                                            <?php echo Form::text('test['.$detail->id.']['.$testId.']', $testValue); ?>

                                                        </td>
                                                        <td align="left" class="rb">
                                                            <?php echo $tDet->testrange; ?>

                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </td>
                            </tr>
                        </table>

                        <div class="col-sm-12 margintop10 clearfix text-center">
                            <div class="form-group">
                                <?php echo Form::submit("Save Report", array('class' => 'btn btn-primary btn-lg')); ?>

                            </div>
                        </div>

                    </div>
                </div>
            <!-- end: TEXT FIELDS PANEL -->
            </div>
            <?php echo Form::close(); ?>

        </div>    
    </div>
</div>
<!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>