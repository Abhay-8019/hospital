@extends('layouts.admin')
@section('content_header')
    <section class="content-header">
        <h1>
            {!! lang('common.edit_heading', lang('doctor.doctor')) !!} #{!! $result->name !!}
            <small>{!! lang('common.record_update') !!}</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> {!! lang('common.back') !!}</a></li>
            <li><a href="{!! route('doctor.index') !!}">{!! lang('doctor.doctor') !!}</a></li>
            <li class="active">{!! lang('common.edit_heading', lang('doctor.doctor')) !!}</li>
        </ol>
    </section>
@stop
@section('content')
    <div id="page-wrapper">
        <!-- start: PAGE CONTENT -->

        {{-- for message rendering --}}
        @include('layouts.messages')
        <div class="row">
            <div class="col-md-12 padding0">
                {!! Form::model($result, array('route' => array('doctor.update', $result->id), 'method' => 'PATCH', 'id' => 'ajaxSave', 'class' => 'form-horizontal')) !!}

                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-external-link-square"></i> &nbsp;
                            {!! lang('test.test_detail') !!}
                        </div>
                        <div class="panel-body">

                            <div class="row">
                                <div class="col-md-6">

                                    <div class="form-group required">
                                        {!! Form::label('registration_no', lang('doctor.registration_no'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::text('registration_no', ($result->registration_no)? $result->registration_no : null, array('class'=>'form-control','readonly', 'placeholder' => 'Registration No')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        {!! Form::label('association', lang('doctor.association'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::select('association', $associationName, ($result->association)? $result->association : null, array('class' => 'form-control','id'=>'association', 'placeholder' => 'Association')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group addassociation required " @if($result->association && $result->association != 3) style="display:none" @endif>
                                        {!! Form::label('association', lang('doctor.specify'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::text('specifyassociation',($result->specifyassociation)? $result->specifyassociation : null, array('class' => 'form-control', 'placeholder' => 'Please Mention')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        {!! Form::label('name', lang('common.name'), array('class' => 'col-sm-3 control-label')) !!}
                                        <div class="col-sm-8">
                                            {!! Form::text('name', ($result->name)? $result->name : null, array('class' => 'form-control', 'placeholder' => 'Full Name')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        {!! Form::label('contact', lang('doctor.contact'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::text('contact', ($result->contact)? $result->contact : null, array('class' => 'form-control','maxlength'=> 10, 'placeholder' => 'Contact No')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        {!! Form::label('email', lang('common.email'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::text('email', ($result->email)? $result->email : null, array('class' => 'form-control', 'placeholder' => 'example@gmail.com')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        {!! Form::label('gender', lang('common.gender'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::select('gender', $gender, ($result->gender)? $result->gender : null, array('class' => 'form-control')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        {!! Form::label('date_of_birth', lang('doctor.date_of_birth'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::text('date_of_birth', $result->date_of_birth ? convertToLocal($result->date_of_birth, 'd-m-Y') : null, array('class' => 'form-control date-picker', 'readonly' => true, 'placeholder' => 'Date of birth')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        {!! Form::label('blood_group', lang('common.blood_group'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::select('blood_group', $bloodGroup, ($result->blood_group)? $result->blood_group : null, array('class' => 'form-control')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        {!! Form::label('marital_status', lang('doctor.marital_status'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::select('marital_status', $maritalStatus, ($result->maruta_status)? $result->marital_status : null, array('class' => 'form-control')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        {!! Form::label('address', lang('doctor.address'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::textarea('address', ($result->address)? $result->address : null, array('class' => 'form-control', 'id' => 'address', 'size' => '5x4', 'placeholder' => 'Address')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        {!! Form::label('consultation_fee', lang('doctor.fee'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::text('consultation_fee', ($doctorFee->consultation_fee) ? $doctorFee->consultation_fee : null, array('class' => 'form-control', 'placeholder' => 'Consultant Fee', 'id' => 'consultation_fee')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        {!! Form::label('room_no', lang('doctor.room_no'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::select('room_id', $roomName, ($result->room_id)? $result->room_id : null, array('class' => 'form-control')) !!}
                                        </div>
                                    </div>

                                    <?php
                                        $labelText = lang('common.choose_image');
                                        $filePath = ($result->image != '')? \Config::get('constants.UPLOADS').$result->image : null;
                                        $fileName = ($result->image != '')? getFileName($result->image, '_', true) : null;

                                        $folder = ROOT .  \Config::get('constants.UPLOADS');
                                    ?>
                                    <div class="form-group hide">
                                        {!! Form::label('image', lang('doctor.doctor_image'), array('class' => 'col-sm-3 control-label paddingleft0')) !!}
                                        <div class="col-sm-8 imageDiv">
                                            @if(file_exists($folder . $result->image) &&  $result->image)
                                                {!! Html::image($filePath, $fileName, ['class' => 'showImage img-responsive thumbnail']) !!}
                                            @else
                                                <img class='showImage img-responsive thumbnail' src="" alt="">
                                            @endif
                                            {!! Form::label('image', (file_exists($folder . $result->image) && $fileName != '')? $fileName : $labelText, array('class' => 'col-sm-4 control-label', 'id' => 'img-label')) !!}
                                            {!! Form::file('image', null) !!}
                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        {!! Form::label('status', lang('common.active') . '&nbsp;', array('class' => 'col-sm-3 control-label')) !!}
                                        <div class="col-sm-3 margintop8">
                                            {!! Form::checkbox('status', '1', true) !!}
                                        </div>
                                    </div>

                                </div>

                                <div class="col-md-6">

                                    <div class="form-group">
                                        {!! Form::label('qualification', lang('doctor.qualification'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::textarea('qualification', ($result->qualification)? $result->qualification : null, array('class' => 'form-control', 'size' => '5x4', 'placeholder' => 'Qualification')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        {!! Form::label('joining_date', lang('doctor.date_of_joining'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::text('joining_date', ($result->joining_date) ? convertToLocal($result->joining_date, 'd-m-Y'): null, array('class' => 'form-control date-picker', 'readonly' => true, 'placeholder' => 'Date of Joining')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        {!! Form::label('designation', lang('doctor.designation'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::select('designation_id', $designationName, ($result->designation_id)? $result->designation_id : null, array('class' => 'form-control', 'id' => 'designation_id')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        {!! Form::label('specialization', lang('doctor.specialization'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::select('specialization_id',$specializationName, ($result->specialization_id)? $result->specialization_id : null, array('class'=>'form-control', 'id' => 'specialization_id')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        {!! Form::label('department', lang('doctor.department'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::select('department_id', $departmentName, ($result->department_id)? $result->department_id : null, array('class' => 'form-control', 'id' => 'department_id')) !!}
                                        </div>
                                    </div>


                                    <div class="form-group">
                                        {!! Form::label('city', lang('doctor.city'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::text('city', ($result->city) ? $result->city : null, array('class' => 'form-control', 'placeholder' => 'City')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        {!! Form::label('state', lang('doctor.state'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::text('state', ($result->state) ? $result->state : null, array('class'=>'form-control', 'placeholder' => 'State')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        {!! Form::label('country', lang('doctor.country'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::text('country', ($result->country)? $result->country : null, array('class'=>'form-control', 'placeholder' => 'Country')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        {!! Form::label('zipcode', lang('doctor.zip_code'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::text('zipcode', ($result->zipcode)? $result->zipcode : null, array('class'=>'form-control', 'placeholder' => 'Zip Code')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        {!! Form::label('days', lang('doctor.days'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::select('days[]', $daysArr, ($days)? $days : null, array('class' => 'form-control select2', 'multiple'=>true, 'placeholder' => '-- Select Days -- ')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        {!! Form::label('duty', lang('doctor.duty'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::select('duty_type[]', $dutyTypeArr, ($dutyType)? $dutyType : null, array('class' => 'form-control select2', 'multiple' => true, 'placeholder' => '-- Select Duty Type -- ' )) !!}
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        {!! Form::label('in_time', lang('doctor.morning'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-3">
                                            {!! Form::text('in_time', ($result->in_time)? convertToLocal($result->in_time, 'h:m') : null, array('class' => 'form-control time-picker', 'placeholder' => 'In Time')) !!}
                                        </div>

                                        {!! Form::label('out_time', lang('doctor.morning'), array('class' => 'col-sm-2 control-label')) !!}

                                        <div class="col-sm-3">
                                            {!! Form::text('out_time', ($result->out_time)? convertToLocal($result->out_time, 'h:m' ): null, array('class' => 'form-control time-picker', 'placeholder' => 'Out Time')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group">

                                        {!! Form::label('eve_in_time', lang('doctor.evening'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-3">
                                            {!! Form::text('eve_in_time', ($result->eve_in_time)? convertToLocal($result->eve_in_time, 'h:m'): null, array('class' => 'form-control time-picker', 'placeholder' => 'In Time')) !!}
                                        </div>

                                        {!! Form::label('eve_out_time', lang('doctor.evening'), array('class' => 'col-sm-2 control-label')) !!}

                                        <div class="col-sm-3">
                                            {!! Form::text('eve_out_time', ($result->eve_out_time)? convertToLocal($result->eve_out_time, 'h:m'): null, array('class' => 'form-control time-picker', 'placeholder' => 'Out Time')) !!}
                                        </div>

                                    </div>

                                </div>

                                <div class="col-sm-11 margintop20 clearfix text-center">
                                    <div class="form-group">
                                        {!! Form::hidden('permission_id', (isset($userPermissions) && $userPermissions != '')? $userPermissions->permission_id : null) !!}
                                        {!! Form::submit(lang('common.update'), array('class' => 'btn btn-primary btn-lg')) !!}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end: TEXT FIELDS PANEL -->
                </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
    <!-- /#page-wrapper -->
@stop
@section('script')
    <script type="text/javascript">
        $(document).ready(function() {

            $(document).on('change', '#association', function() {
                var value = $(this).val();
                   if(value == 3) {
                       $('input[name="specifyassociation"]').val('');
                       $(".addassociation").show();
                   }else {
                       $('input[name="specifyassociation"]').val('');
                      $(".addassociation").hide();
                   }
            });

        });

        $('#image').on('change',function(){
            var filename = 'No File Selected';
            if($(this)[0].files[0])
            {
                filename = $(this)[0].files[0]['name'];

                var fileExtension = filename.substr(filename.lastIndexOf('.') + 1);
                fileExtension = fileExtension.toLowerCase();
                var validExtension = ['jpg', 'jpeg', 'png', 'gif'];

                if($.inArray(fileExtension, validExtension) >= 0){
                    $('#img-label').css('border', '1px dashed #ccc');
                }else {
                    filename = 'No File Selected';
                    $('#member_image').val('');
                    $('#img-label').css('border', '1px dashed red');
                    alert('Please select an image');
                }
            }
            readURL(this);
            $('#img-label').text(filename);
        });

        function readURL(input) {

            var html = '', src = '', alt = '';
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                $(".backDrop").fadeIn( 100, "linear" );
                $(".loader").fadeIn( 100, "linear" );

                reader.onload = function (e) {
                    src = e.target.result;
                    $('.showImage').attr('src', src).attr('alt', alt);

                    setTimeout(function(){
                        $(".backDrop").fadeOut( 100, "linear" );
                        $(".loader").fadeOut( 100, "linear" );
                    }, 200);
                };
                reader.readAsDataURL(input.files[0]);
            }else{
                $('.showImage').attr('src', src).attr('alt', alt);
            }
        }

    </script>
@stop