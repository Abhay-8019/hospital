<thead>
<tr>
    <th width="1%" class="text-center">{!! lang('common.id') !!}</th>
    <th>{!! lang('common.name') !!}</th>
    <th>{!! lang('doctor.contact') !!}</th>
    <th>{!! lang('doctor.specialization') !!}</th>
    <th>{!! lang('doctor.department') !!}</th>
    <th>{!! lang('doctor.doctor_image') !!}</th>
    <th>{!! lang('doctor.fee') !!}</th>
    @if(hasMenuRoute('doctor.edit'))
        <th class="text-center"> {!! lang('common.status') !!} </th>
        <th class="text-center">{!! lang('common.action') !!}</th>
    @endif
</tr>
</thead>
<tbody>
<?php $index = 1;
$dutyType = lang('common.duty_type');
$filePath = \Config::get('constants.UPLOADS');
$folder = ROOT . $filePath;
?>
@if (isset($data) && count($data) > 0)
    @foreach($data as $detail)
        <tr id="order_{{ $detail->id }}">
            <td class="text-center">{!! pageIndex($index++, $page, $perPage) !!}</td>
            <td>
                @if(hasMenuRoute('doctor.edit'))
                    <a href="{!! route('doctor.edit', [$detail->id]) !!}">
                        {!! $detail->name !!}
                    </a>
                @else
                    {!! $detail->name !!}
                @endif
            </td>
            <td> {!! $detail->contact !!} </td>
            <td> {!! $detail->specialization_name !!} </td>
            <td> {!! $detail->department_name !!} </td>
            <td> @if(file_exists($folder . $detail->image) && $detail->image)
                    {!! Html::image($filePath.$detail->image, getFileName($detail->image), ['class' => 'img-responsive img-circle margin0-auto', 'width' => '60','align'=>'left']) !!}
                @endif
            </td>
            <td> {!! numberFormat($detail->consultation_fee) !!} </td>
            @if(hasMenuRoute('doctor.edit'))
                <td class="text-center">
                    <a href="javascript:void(0);" class="toggle-status" data-message="{!! lang('messages.change_status') !!}" data-route="{!! route('doctor.toggle', $detail->id) !!}">
                        {!! Html::image('assets/images/' . $detail->status . '.gif') !!}
                    </a>
                </td>
                <td class="text-center col-md-1">
                    <a class="btn btn-xs btn-primary" href="{{ route('doctor.edit', [$detail->id]) }}"><i class="fa fa-edit"></i></a>
                </td>
            @endif
        </tr>
    @endforeach

    <tr class="margintop10">
        <td colspan="10">
            {!! paginationControls($page, $total, $perPage) !!}
        </td>
    </tr>
@else
    <tr>
        <td class="text-center" colspan="10"> {!! lang('messages.no_data_found') !!} </td>
    </tr>
@endif
</tbody>