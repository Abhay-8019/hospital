@extends('layouts.admin')
@section('content_header')
    <section class="content-header">
        <h1>
            {!! lang('patient_test.patient_test') !!}
            <small>{!! lang('common.create_heading', lang('patient_test.patient_test')) !!}</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> {!! lang('common.back') !!}</a></li>
            <li><a href="{!! route('patient-test.index') !!}">{!! lang('patient_test.patient_tests') !!}</a></li>
            <li class="active">{!! lang('common.create_heading', lang('patient_test.patient_test')) !!}</li>
        </ol>
    </section>
@stop
@section('content')
<div id="page-wrapper">
    {{-- for message rendering --}}
    @include('layouts.messages')
    <div class="add-more-section hidden">
        <div class="separator margintop10 single-section clearfix">
            <div class="col-md-3">
                {!! Form::select('test[]', $tests, null, array('class' => 'form-control sselect2 ajaxChange padding0 test', 'data-action' => 1, 'data-target' => 'test_rate0', 'data-route' => route('add-test.get-rate'))) !!}
            </div>
            <div class="col-md-2">
                {!! Form::text('test_rate[]', null, array('class' => 'form-control test_rate', 'placeholder' => 'Test Rate', 'readonly' => true)) !!}
            </div>
            <a href="javascript:void(0)" class="btn btn-danger pull-left btn-xs hidden add-hidden remove-this">X</a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 padding0">
            {!! Form::open(array('method' => 'POST', 'route' => array('patient-test.store'), 'id' => 'ajaxSave', 'class' => 'form-horizontal')) !!}
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <i class="fa fa-external-link-square"></i> &nbsp;
                        {!! lang('patient_test.patient_test_detail') !!}
                    </div>
                    <div class="panel-body">
                        <div class="col-md-1">
                            <div class="form-group">
                                {!! Form::text('receipt_no', $count+1, array('class' => 'form-control', 'placeholder' => lang('patient_test.receipt_no'), 'readonly' => true)) !!}
                            </div>
                        </div>

                        <div class="col-md-2 marginleft15">
                            <div class="form-group">
                                {!! Form::text('test_date', date('d-m-Y'), array('class' => 'form-control date-picker', 'placeholder' => lang('patient_test.test_date'))) !!}
                            </div>
                        </div>

                        <div class="col-md-2 marginleft15">
                            <div class="form-group">
                                {!! Form::select('patient', ['' => '-Select Patient-'], null, array('class' => 'form-control select2-ajax padding0', 'data-select2-ajax' => route('patient-registration.get-patients'), 'id' => 'patient')) !!}
                            </div>
                        </div>

                        <div class="clearfix"></div>

                        <div class="col-md-2">
                            <div class="form-group">
                                {!! Form::select('doctor', $doctors, null, array('class' => 'form-control select2 padding0', 'id' => 'doctor')) !!}
                            </div>
                        </div>

                        <div class="col-md-2 paddingleft20">
                            <div class="form-group">
                                {!! Form::select('department', $departments, null, array('class' => 'form-control select2 padding0', 'id' => 'department')) !!}
                            </div>
                        </div>


                        <div class="clearfix"></div>
                        <div class="row">
                            <div class="append-parent-section clearfix">
                                <div class="separator margintop10 single-section clearfix">
                                    <div class="col-md-3">
                                        {!! Form::select('test[0]', $tests, null, array('class' => 'form-control select2 ajaxChange padding0', 'id' => 'test0', 'data-action' => 1, 'data-target' => 'test_rate0', 'data-route' => route('add-test.get-rate'))) !!}
                                    </div>
                                    <div class="col-md-2">
                                        {!! Form::text('test_rate[0]', null, array('class' => 'form-control', 'placeholder' => 'Test Rate', 'readonly' => true, 'id' => 'test_rate0')) !!}
                                    </div>
                                    <a href="javascript:void(0)" class="btn btn-danger pull-left btn-xs hidden add-hidden remove-this">X</a>
                                </div>
                            </div>
                            <div class="col-md-8 margintop20 clearfix">
                                <a href="javascript:void(0)" class="__add btn btn-success btn-sm"> <i class="fa fa-plus-circle"></i> {!! lang('common.add_more') !!}</a>
                            </div>
                        </div>

                        <div class="col-sm-6 margintop10 clearfix text-center">
                            <div class="form-group">
                                {!! Form::submit(lang('common.save'), array('class' => 'btn btn-primary btn-lg')) !!}
                            </div>
                        </div>

                    </div>
                </div>
            <!-- end: TEXT FIELDS PANEL -->
            </div>
            {!! Form::close() !!}
        </div>    
    </div>
</div>
<!-- /#page-wrapper -->
@stop
@section('script')
    @include('admin.patient-test.jshelper')
@stop