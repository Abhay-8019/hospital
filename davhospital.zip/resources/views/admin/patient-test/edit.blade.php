@extends('layouts.admin')
@section('content_header')
    <section class="content-header">
        <h1>
            {!! lang('patient_test.patient_test') !!}
            <small>{!! lang('common.edit_heading', lang('patient_test.patient_test')) !!} #{{ $result->receipt_no }}</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> {!! lang('common.back') !!}</a></li>
            <li><a href="{!! route('patient-test.index') !!}">{!! lang('patient_test.patient_tests') !!}</a></li>
            <li class="active">{!! lang('common.edit_heading', lang('patient_test.patient_test')) !!} </li>
        </ol>
    </section>
@stop
@section('content')
<div id="page-wrapper">
    {{-- for message rendering --}}
    @include('layouts.messages')
    <div class="add-more-section hidden">
        <div class="separator margintop10 single-section clearfix">
            <div class="col-md-3">
                {!! Form::select('test[]', $tests, null, array('class' => 'form-control sselect2 ajaxChange padding0 test', 'data-action' => 1, 'data-target' => 'test_rate0', 'data-route' => route('add-test.get-rate'))) !!}
            </div>
            <div class="col-md-2">
                {!! Form::text('test_rate[]', null, array('class' => 'form-control test_rate', 'placeholder' => 'Test Rate', 'readonly' => true)) !!}
            </div>
            <a href="javascript:void(0)" class="btn btn-danger pull-left btn-xs hidden add-hidden remove-this">X</a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 padding0">
        {!! Form::model($result, array('route' => array('patient-test.update', $result->id), 'method' => 'PATCH', 'id' => 'ajaxSave', 'class' => 'form-horizontal')) !!}
         <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <i class="fa fa-external-link-square"></i> &nbsp;
                        {!! lang('patient_test.patient_test_detail') !!}
                    </div>
                    <div class="panel-body">

                        <div class="col-md-1">
                            <div class="form-group">
                                {!! Form::text('receipt_no', null, array('class' => 'form-control', 'placeholder' => lang('patient_test.receipt_no'), 'readonly' => true)) !!}
                            </div>
                        </div>

                        <div class="col-md-2 marginleft15">
                            <div class="form-group">
                                {!! Form::text('test_date', dateFormat('d-m-Y', $result->test_date), array('class' => 'form-control date-picker', 'placeholder' => lang('patient_test.test_date'))) !!}
                            </div>
                        </div>

                        <div class="col-md-2 marginleft15">
                            <div class="form-group">
                                {!! Form::select('patient', [$patient->id => $patient->patient_code . ' --> ' . $patient->first_name . '(' . $patient->age . ') Y'], $result->patient_id, array('class' => 'form-control select2-ajax padding0', 'data-select2-ajax' => route('patient-registration.get-patients'), 'id' => 'patient')) !!}
                            </div>
                        </div>

                        <div class="clearfix"></div>

                        <div class="col-md-2">
                            <div class="form-group">
                                {!! Form::select('doctor', $doctors, $result->doctor_id, array('class' => 'form-control select2 padding0', 'id' => 'doctor')) !!}
                            </div>
                        </div>

                        <div class="col-md-2 paddingleft20">
                            <div class="form-group">
                                {!! Form::select('department', $departments, $result->department_id, array('class' => 'form-control select2 padding0', 'id' => 'department')) !!}
                            </div>
                        </div>

                        <div class="clearfix"></div>
                        <div class="row">
                            <div class="append-parent-section clearfix">
                                @foreach($result->tests as $key => $detail)
                                    <div class="separator margintop10 single-section clearfix">
                                        {{--<div class="col-md-4 hide">
                                            {!! Form::text('test_code[]', $detail->diagnostics->diagnostic_code, array('class' => 'form-control t-code t-search', 'placeholder' => 'Test Code', 'data-type' => '2')) !!}
                                            {!! Form::hidden('test_id[]', $detail->diagnostic_id, array('class' => 't-id')) !!}
                                            {!! Form::hidden('patient_test_id[]', $detail->id) !!}
                                        </div>
                                        <div class="col-md-4">{!! Form::text('test_name[]', $detail->diagnostics->diagnostic_name, array('class' => 'form-control t-name t-search', 'placeholder' => 'Test Name', 'data-type' => '3')) !!}</div>
                                        <div class="col-md-3">{!! Form::text('test_rate[]', $detail->test_rate, array('class' => 'form-control t-rate', 'placeholder' => 'Test Rate', 'readonly' => true)) !!}</div>
                                        <div class="delete-button">
                                            {!! Form::button("X", array('class' => 'btn btn-danger btn-xs delete_test delete', 'data-id' => $detail->id)) !!}
                                        </div>--}}

                                        <div class="col-md-3">
                                            {!! Form::select('test['. $key .']', $tests, $detail->test_id, array('class' => 'form-control select2 ajaxChange padding0', 'id' => 'test' . $key, 'data-action' => 1, 'data-target' => 'test_rate' . $key, 'data-route' => route('add-test.get-rate'))) !!}
                                        </div>
                                        <div class="col-md-2">
                                            {!! Form::text('test_rate['. $key .']', $detail->test_rate, array('class' => 'form-control', 'placeholder' => 'Test Rate', 'readonly' => true, 'id' => 'test_rate' . $key)) !!}
                                        </div>
                                        {!! Form::hidden('patient_test_id['. $key .']', $detail->id) !!}
                                        <a href="javascript:void(0)" class="btn btn-danger pull-left btn-xs delete_test add-hidden remove-this" data-id="{!! $detail->id !!}">X</a>
                                    </div>
                                @endforeach
                            </div>
                            <div class="col-md-8 margintop20 clearfix">
                                <a href="javascript:void(0)" class="__add btn btn-success btn-sm"> <i class="fa fa-plus-circle"></i> {!! lang('common.add_more') !!}</a>
                            </div>
                            <div class="clearfix"></div>
                            {!! Form::hidden('delete_test_id', null, array('class' => 'delete-ids')) !!}
                        </div>

                        <div class="col-sm-6 margintop10 clearfix text-center">
                            <div class="form-group">
                                {!! Form::submit(lang('common.update'), array('class' => 'btn btn-primary btn-lg')) !!}
                            </div>
                        </div>

                    </div>
                </div>
                <!-- end: TEXT FIELDS PANEL -->
            </div>
            {!! Form::close() !!}
        </div>    
    </div>
</div>
<!-- /#page-wrapper -->
@stop

@section('script')
    @include('admin.patient-test.jshelper', ['count' => ++$key])
@stop