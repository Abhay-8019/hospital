<script>
    /*$('body').off('focus', '.single-section:last input');
    $( "body").on('focus', '.single-section:last input', function() {
        $('.delete').removeClass('hidden');
        $('.append-parent-section').append($('.add-more-section').html());
    });*/

    var count = '{!! isset($count) ? $count : 1 !!}';
    $('.__add').on('click', function(event)
    {
        var dimension = $('.add-more-section').html();

        $('.append-parent-section').append(dimension);

        var target = $('.append-parent-section').find('.single-section:last');

        target.find(".test").attr({
            'name': 'test['+count + ']',
            'data-target': 'test_rate'+count,
            'id': 'test' + count,
        });

        target.find(".test_rate").attr({
            'name': 'test_rate['+count + ']',
            'id': 'test_rate' + count,
        });

        target.find('.sselect2').select2({
            allowClear: true
        });
        $(".sselect2").trigger('select2:updated');

        $('.remove-this').removeClass('hidden');
        count++;
    });

    $('body').on('click', 'a.remove-this', function() {
        var length = $('a.remove-this').length;
        if(length > 1) {
            $(this).parent().remove();
        }
        var length = $('a.remove-this').length;
        if (length == 1) {
            $('.add-hidden').addClass('hidden');
        }
    });

    $('body').off('click', '.delete_test');
    $('body').on('click', '.delete_test', function(event) {
        var idToDelete = $(this).data('id');
        var del = $('.delete-ids').val();
        $('.delete-ids').val(del + ',' + idToDelete);
    });
</script>