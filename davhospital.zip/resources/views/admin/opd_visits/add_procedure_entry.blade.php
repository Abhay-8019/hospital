@extends('layouts.admin')
@section('content_header')
    <section class="content-header">
        <h1>
            RECORD PROCEDURES
        </h1>
    </section>
@stop

@section('content')
<div class="col-md-12">
    <div class="errorList">
    </div>
</div>
<div class="col-md-12 padding0">
    <div class="clearfix">
        @if(count($pMedicines) > 0)
            {!! Form::open(array('method' => 'POST', 'route' => array('patient.opd-procedure-visit', $result->id), 'id' => 'ajaxSaveForm', 'class' => 'form-horizontal')) !!}
            <b> ::Procedure Entry for OPD Patients::</b>
            <table class="table table-bordered">
                <tr>
                    <th>                     {!! Form::label('procedure_held_date', 'Date', array('class' => 'control-label')) !!} </th>

                    <th>
{!! Form::text('procedure_held_date', currentDate(), array('class' => 'form-control date-picker procedure_held_date', 'placeholder' => 'Select Date')) !!}

</th>
                    <th colspan="5">&nbsp;</th>                   

                </tr>

                <tr>
                    <th><b>&nbsp;</b></th>
                    <th><b>{!! lang('opd_master.procedure') !!}</b></th>
                    <th><b>{!! lang('opd_master.medicine') !!}</b></th>
                    <th><b>{!! lang('opd_master.dose') !!}</b></th>
                    <th><b>{!! lang('opd_master.timing') !!}</b></th>
                    <th><b>{!! lang('opd_master.remarks') !!}</b></th>
                    <th ><b>{!! lang('opd_master.instruction') !!}</b></th>
                </tr>
                <?php $pId = 0; ?>
                @if(count($procedure) > 0)
                    @foreach($pMedicines as $detail)
                        @if($procedure->procedure_id ==  $detail->procedure_id)
                            <tr>
                                <td>
                                    <div >{!! Form::checkbox('add_procedure[' . $detail->procedure_id . '##' . $detail->procedure_medicine_id.']', 1, true) !!}</div>
                                </td>
                                <td>{!! $detail->procedure_date !!} {!! $detail->procedure !!}</td>
                                <td>{!! $detail->medicine !!}</td>
                                <td>{!! $detail->dose !!} {!! $detail->dose_unit !!}</td>
                                <td>{!! $detail->timing !!}</td>
                                <td>{!! $detail->remarks !!}</td>
                                <td>
                                    <?php
                                        $remarks = ""; $pId = 0;
                                        if($procedure->procedure_id ==  $detail->procedure_id) 
                                            { 
                                                $remarks =  $procedure->remarks; 
                                                $pId = $procedure->id;
                                            }
                                    ?>
                                    {!! Form::textarea('procedure_remark['. $detail->procedure_id . '##' . $detail->procedure_medicine_id.']', $remarks, ['class' => 'form-control', 'size' => '40x2']) !!}
                                </td>
                            </tr>
                        @endif
                    @endforeach
                @else
                    @foreach($pMedicines as $detail)
                            <tr>
                                <td>
                                    {!! Form::checkbox('add_procedure[' . $detail->procedure_id . '##' . $detail->procedure_medicine_id .']', 1) !!}
                                </td>
                                <td>{!! $detail->procedure !!}</td>
                                <td>{!! $detail->medicine !!}</td>
                                <td>{!! $detail->dose !!} {!! $detail->dose_unit !!}</td>
                                <td>{!! $detail->timing !!}</td>
                                <td>{!! $detail->remarks !!}</td>
                                <td>
                                    {!! Form::textarea('procedure_remark['. $detail->procedure_id . '##' . $detail->procedure_medicine_id  .']', null, ['class' => 'form-control', 'size' => '40x2']) !!}
                                </td>
                            </tr>
                    @endforeach

                @endif
            </table>

            <div class="col-sm-11 text-center">
                <div class="form-group">
                    {!! Form::hidden('pid', $pId) !!}
                    {!! Form::hidden('patient_id', $result->patient_id) !!}
                    {!! Form::hidden('department_id', $result->department_id) !!}
                    {!! Form::hidden('doctor_id', $result->doctor_id) !!}


                    {!! Form::submit(lang('common.save'), array('class' => 'btn btn-primary btn-lg')) !!}
                </div>
            </div>
            {!! Form::close() !!}
        @else
            <h2 class="text-center"> No procedure advised for Patient! </h2>
        @endif
    </div>
</div>
<script>
    // Submit modal form with ajax
    $('#ajaxSaveForm').submit(function(e){
        e.preventDefault();
        ajaxSaveModalForm("#ajaxSaveForm");
        return false;
    });
</script>
@stop