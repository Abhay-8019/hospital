<thead>
<tr>
    <th width="1%">#</th>
    <th width="5%">{!! lang('patient.patient_code') !!}</th>
    <th width="10%">{!! lang('common.name') !!}</th>
    <th width="5%">{!! lang('common.age') !!} / {!! lang('common.gender') !!}</th>
    <th width="5%">{!! lang('common.mobile') !!}</th>
    <th class="text-center" colspan="3" width="20%">{!! lang('common.action') !!}</th>
</tr>
</thead>
<tbody>
<?php
    $index = 1;
    $genderArr = lang('common.genderArrayShort');
?>
@if(count($data) > 0)
    @foreach($data as $key => $detail)
        <tr>
            <td> {!! $index++ !!} </td>
            <td> <a href="{!! route('patient.opd-re-visit', [$detail->patient_code]) !!}"> {!! $detail->patient_code !!} </a></td>
            <td>
                {!! $detail->first_name !!}
            </td>
            <td>{!! $detail->age !!} @if($detail->age) Y @endif / @if($detail->gender != '') {!! $genderArr[$detail->gender] !!} @endif</td>
           
            <td>{!! $detail->mobile !!}</td>
            <td class="text-center col-md-1">
                @if(count($data) == 1)
                    {!! Form::select('department', $departments, null, array('class' => 'form-control select2d padding0')) !!}
                @endif
            </td>
            <td class="text-center col-md-1">
                @if(count($data) == 1)
                    {!! Form::select('doctor', $doctors, null, array('class' => 'form-control select2d padding0')) !!}
                @endif
                {!! Form::hidden('p_id', $detail->patient_id) !!}
            </td>
            <td class="text-center col-md-1">
                @if(count($data) == 1)
                    {!! Form::text('opdremarks', null, array('class' => 'form-control', 'placeholder' => 'Remarks')) !!}
                @endif
            </td>

        </tr>
    @endforeach
    <tr>
        <td colspan="5">&nbsp;</td>
        <td colspan="3" class="text-center">
            {!! Form::submit(lang('common.save'), array('class' => 'btn btn-primary btn-lg')) !!}
        </td>
    </tr>
@endif
@if (count($data) < 1)
    <tr>
        <td class="text-center" colspan="6"> {!! lang('messages.no_data_found') !!} </td>
    </tr>
@endif
</tbody>