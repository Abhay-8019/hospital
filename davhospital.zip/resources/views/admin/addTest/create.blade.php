@extends('layouts.admin')
@section('content_header')
    <section class="content-header">
        <h1>
            {!! lang('test.test') !!}
            <small>{!! lang('common.add_record') !!}</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> {!! lang('common.back') !!}</a></li>
            <li><a href="{!! route('add-test.index') !!}">{!! lang('test.test') !!}</a></li>
            <li class="active">{!! lang('common.create_heading', lang('test.test')) !!}</li>
        </ol>
    </section>
@stop
@section('content')
    <div id="page-wrapper">
        <!-- start: PAGE CONTENT -->

        {{-- for message rendering --}}

        @include('layouts.messages')
        <div class="row">
            <div class="col-md-12 padding0">
                {!! Form::open(array('method' => 'POST', 'route' => array('add-test.store'), 'id' => 'ajaxSave', 'class' => 'form-horizontal')) !!}

                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-external-link-square"></i> &nbsp;
                            {!! lang('test.test_detail') !!}
                        </div>
                        <div class="panel-body">
                            <div class="row">

                                <div class="col-md-6">

                                    <div class="form-group required">
                                        {!! Form::label('name', lang('test_category.test_category'), array('class' => 'col-sm-3 control-label')) !!}
                                        <div class="col-sm-8">
                                            {!! Form::select('test_category', $category, null, array('class' => 'form-control select2 padding0', 'id' => 'test_category')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        {!! Form::label('name', lang('common.name'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::text('name', null, array('class' => 'form-control')) !!}
                                        </div>

                                    </div>

                                    <div class="form-group required">
                                        {!! Form::label('cost', lang('test.test_cost'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::text('cost', null, array('class' => 'form-control')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        {!! Form::label('detail', lang('test.description'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::textarea('description', null, array('class' => 'form-control', 'rows'=>'4')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        {!! Form::label('status', lang('common.active') . '&nbsp;', array('class' => 'col-sm-3 control-label')) !!}
                                        <div class="col-sm-5 margintop8">
                                            {!! Form::checkbox('status', '1', true) !!}
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">

                                    <div class="form-group">
                                        {!! Form::label('testrange', lang('test.testrange'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::text('testrange', null, array('class' => 'form-control')) !!}
                                        </div>

                                    </div>
                                    <div class="form-group">
                                        {!! Form::label('minVal', lang('test.min_value'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::text('minval', null, array('class' => 'form-control')) !!}
                                        </div>

                                    </div>

                                    <div class="form-group">
                                        {!! Form::label('maxVal', lang('test.max_value'), array('class' => 'col-sm-3 control-label')) !!}

                                        <div class="col-sm-8">
                                            {!! Form::text('maxval', null, array('class' => 'form-control')) !!}
                                        </div>
                                    </div>

                                    <div class="form-group required">
                                        {!! Form::label('name', lang('test_category.sub_tests'), array('class' => 'col-sm-3 control-label')) !!}
                                        <div class="col-sm-8">
                                            {!! Form::select('sub_tests[]', $tests, null, array('class' => 'form-control fSelect padding0', 'multiple' => true, 'id' => 'sub_tests')) !!}
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-11 margintop20 clearfix text-center">
                                <div class="form-group">
                                    {!! Form::submit(lang('common.save'), array('class' => 'btn btn-primary btn-lg')) !!}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end: TEXT FIELDS PANEL -->
            </div>
            {!! Form::close() !!}
        </div>
    </div>
    </div>
    <!-- /#page-wrapper -->
@stop

