<thead>
<tr>
    <th width="1%" class="text-center">{!! lang('common.id') !!}</th>
    <th>{!! lang('common.name') !!}</th>
    <th>{!! lang('test.test_cost') !!}</th>
    <th>{!! lang('test.testrange') !!}</th>
    <th>{!! lang('test.min_value') !!}</th>
    <th>{!! lang('test.max_value') !!}</th>
    @if(hasMenuRoute('add-test.edit'))
        <th class="text-center"> {!! lang('common.status') !!} </th>
        <th class="text-center">{!! lang('common.action') !!}</th>
        @if(isAdmin())
            <th>&nbsp;</th>
        @endif
    @endif
</tr>
</thead>
<tbody>
<?php $index = 1; ?>
@if (isset($data) && count($data) > 0)
    @foreach($data as $detail)
        <tr id="order_{{ $detail->id }}">
            <td class="text-center">{!! pageIndex($index++, $page, $perPage) !!}</td>
            <td>
                @if(hasMenuRoute('add-test.edit'))
                    <a href="{!! route('add-test.edit', [$detail->id]) !!}">
                        {!! $detail->name !!}
                    </a>
                @else
                    {!! $detail->name !!}
                @endif
            </td>
            <td> {!! $detail->cost !!} </td>
            <td> {!! $detail->testrange !!} </td>
            <td> {!! $detail->minval !!} </td>
            <td> {!! $detail->maxval !!} </td>
            @if(hasMenuRoute('add-test.edit'))
                <td class="text-center">
                    <a href="javascript:void(0);" class="toggle-status" data-message="{!! lang('messages.change_status') !!}" data-route="{!! route('add-test.toggle', $detail->id) !!}">
                        {!! Html::image('assets/images/' . $detail->status . '.gif') !!}
                    </a>
                </td>
                <td class="text-center col-md-1">
                    <a class="btn btn-xs btn-primary" href="{{ route('add-test.edit', [$detail->id]) }}"><i class="fa fa-edit"></i></a>
                </td>
                @if(isAdmin())
                    <td class="text-center col-md-1">
                        <a class="btn btn-xs btn-danger __drop" data-route="{!! route('add-test.drop', [$detail->id]) !!}" data-message="{!! lang('messages.sure_delete', string_manip(lang('test.test'))) !!}" href="javascript:void(0)"><i class="fa fa-times"></i></a>
                    </td>
                @endif                
            @endif
            
        </tr>
    @endforeach

    <tr class="margintop10">
        <td colspan="7">
            {!! paginationControls($page, $total, $perPage) !!}
        </td>
    </tr>
@else
    <tr>
        <td class="text-center" colspan="7"> {!! lang('messages.no_data_found') !!} </td>
    </tr>
@endif
</tbody>