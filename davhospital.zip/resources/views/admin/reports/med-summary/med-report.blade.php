@extends('layouts.admin')
@section('content_header')
	<section class="content-header">
		<h1>
			<?php $route = \Route::currentRouteName(); ?>
			@if($route == "report.opd-medsummary")
				Medicine Summary
			@endif
		</h1>
	</section>
@stop

@section('content')
	<div id="page-wrapper">
		{{-- for message rendering --}}
		@include('layouts.messages')

		<div class="col-md-12 padding0">
			{!! Form::open(array('method' => 'POST', 'route' => array($route), 'id' => 'ajaxForm')) !!}
			<div class="row">
				@if(!isDoctor())
					@if($route == "report.opd-medsummary")
						<div class="col-sm-2">
							<div class="form-group">
								{!! Form::label('doctor', lang('doctor.doctor'), array('class' => 'control-label')) !!}
								{!! Form::select('doctor', $doctors, null, array('class' => 'form-control padding0 select2')) !!}
							</div>
						</div>
						<div class="col-sm-2 paddingleft0">
							<div class="form-group">
								{!! Form::label('department', lang('department.department'), array('class' => 'control-label')) !!}
								{!! Form::select('department', $departments, null, array('class' => 'form-control padding0 select2')) !!}
							</div>
						</div>
						<div class="col-md-2 paddingleft0">
							<div class="form-group">
								{!! Form::label('patient_name', lang('patient.first_name'), array('class' => 'control-label')) !!}
								{!! Form::text('patient_name', null, array('class' => 'form-control', 'placeholder' => lang('patient.first_name'))) !!}
							</div>
						</div>
					@endif
				@endif

				<div class="col-md-2 width125 date paddingleft0">
					<div class="form-group">
						{!! Form::label('from_date', lang('reports.from_date'), array('class' => 'control-label')) !!}
						{!! Form::text('from_date', null, array('class' => 'form-control date-picker from_date', 'placeholder' => lang('reports.from_date'))) !!}
					</div>
				</div>


				<div class="col-md-2 width125 date paddingleft0">
					<div class="form-group">
						{!! Form::label('to_date', lang('reports.to_date'), array('class' => 'control-label')) !!}
						{!! Form::text('to_date', null, array('class' => 'form-control date-picker to_date', 'placeholder' =>  lang('reports.to_date'))) !!}
					</div>
				</div>

				<div class="col-md-2 margintop20 paddingleft0">
					<div class="form-group">
						{!! Form::hidden('form-search', 1) !!}
						{!! Form::hidden('report_type', 1) !!}
						{!! Form::submit(lang('reports.filter'), array('class' => 'btn btn-primary', 'title' => lang('reports.filter'))) !!}
						<a href="{!! route($route) !!}" class="btn btn-primary" title="{!! lang('reports.reset_filter') !!}"> {!! lang('reports.reset_filter') !!}</a>
					</div>
				</div>
			</div>
			{!! Form::close() !!}
		</div>

		<div class="row">
			<div class="col-md-12">
				<!-- start: BASIC TABLE PANEL -->
				<div class="panel panel-default" style="position: static;">
					<div class="panel-heading">
						<i class="fa fa-external-link-square"></i> &nbsp;
						{!! lang('opd_master.opd_visits') !!}
					</div>
					<div class="panel-body padding0">
						<div class="col-md-6 hidden marginbottom10">
							{!! Form::hidden('page', '1') !!}
						</div>
						<div id="p-report">
							<?php $json = ''; $route = \Route::currentRouteName(); ?>
							<table id="paginate-load" data-route="{{ route($route) }}" class="table table-bordered margin0 col-md-12 padding0 font-14">
							</table>

							


						</div>
					</div>
				</div>
				<!-- end: BASIC TABLE PANEL -->
			</div>
		</div>
	</div>
	<!-- /#page-wrapper -->
@stop

@section('script')
	<script type="text/javascript">
		$(document).ready(function(){
			$(".report_type").change(function()
			{
				var report_type = $(this).val();

				if(report_type == '1')
				{
					$(".month, .year").addClass("hidden");
					$(".date").removeClass("hidden");
					//$(".from_date").attr("required", "required");
					//$(".to_date").attr("required", "required");
				}
				else if(report_type == '2')
				{
					$(".date, .year").addClass("hidden");
					$(".month").removeClass("hidden");
					//$(".from_date").removeAttr("required");
					//$(".to_date").removeAttr("required");
				}
				else if(report_type == '3')
				{
					$(".month, .date").addClass("hidden");
					$(".year").removeClass("hidden");
					$(".from_date").removeAttr("required");
					$(".to_date").removeAttr("required");
				}
			});

			$('body').on('click', 'a.__switcher', function(event)
			{
				$(".backDrop").fadeIn( 100, "linear" );
				$(".loader").fadeIn( 100, "linear" );

				$(".__switcher").removeClass('hidden');
				$(this).addClass('hidden');
				var targetShow = $(this).data("show");
				var targetHide = $(this).data("hide");

				//alert(targetShow + ' ' + targetHide); return false;
				$(targetShow).removeClass('hidden');
				$(targetHide).addClass('hidden');
				$(targetShow).removeClass('print_hide');
				$(targetHide).addClass('print_hide');

				setTimeout(function (){
					$(".backDrop").fadeOut( 100, "linear" );
					$(".loader").fadeOut( 100, "linear" );
				}, 80);
			});
		});
	</script>
@stop