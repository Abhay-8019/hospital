<thead>
<?php $summary = json_decode($summary); ?>
@if (count($summary) > 0) 
    <tr class="no-hover">
        <td colspan="10">
        <div style="text-align: center;margin: 0;">
            <p style="font-size: 1.5em;margin:0;">
                    <b> <span style="text-decoration: underline;"> Medicine Prescriptions </span> </b>
            </p>
            @if(!isset($inputs['staff-search']))
                <p style="font-size: 1.2em;margin:0;">
                <span style="font-weight: bold;">

                    @if($doctorName != "")
                        Doctor Wise: "{!! $doctorName !!}"
                    @endif

                    @if($departmentName != "")
                        Department Wise: "{!! $departmentName !!}"
                    @endif
                    <br/>
                    @if($inputs['report_type'] == 1 && isset($inputs['from_date']) && isset($inputs['to_date']))
                        (Dated: {!! dateFormat('d.m.Y', $inputs['from_date']) !!} - {!! dateFormat('d.m.Y', $inputs['to_date']) !!})
                    @endif
                </span>
            </p>
            @endif
        </div>
    </td>
    </tr>
@endif
</thead>

<tbody>
<?php $index = 1; $genderArr = lang('common.genderArray'); ?>

@if(count($summary) > 0)
    @foreach($summary as $key => $detail)
        <tr>
            <td>{!! $index++ !!} </td>
            <td> <a href="{!! route('patient.opd-visit-print', $detail->opd_id) !!}" target="_blank"> 
                {!! $detail->patient . ' (' . $detail->age . '/' . $genderArr[$detail->gender] . ')' !!} </a><b>Department:</b> {!! $detail->department !!} &nbsp;&nbsp;&nbsp; <b> Diagnose: </b>
                {!! trim($detail->diagnose,"-->") !!}<br/>
                @if(count($detail->procedure_medicines) > 0)
                    <h4>Procedures:</h4>
                    @foreach ($detail->procedure_medicines as $proc => $procmed)
                        <b>{!! $procmed->procedure !!} :</b> {!! $procmed->medicine !!} ({!! $procmed->dose !!} {!! $procmed->dose_unit !!}, {!! $procmed->timing !!}, {!! $procmed->procedure_days !!} days ) {!! $procmed->remarks !!} <br/>
                    @endforeach
                @endif

                @if(count($detail->medicines) > 0)
                    <h4>Medicines:</h4>
                    @foreach ($detail->medicines as $medicine)
                        <b>{!! $medicine->medicine !!}</b> ({!! $medicine->dose !!} {!! $medicine->dose_unit !!}, {!! $medicine->timing !!} , {!! $medicine->medicine_days !!} days ) {!! $medicine->remarks !!}<br/>
                    @endforeach
                @endif                
            </td>

        </tr>
    @endforeach
@endif
@if (count($summary) < 1)
    <tr>
        <td class="text-center" colspan="8"> {!! lang('messages.no_data_found') !!} </td>
    </tr>
@endif
</tbody>