<table width="100%">
    <tr class="no-hover">
        <td align="center">
            <div class="col-md-2">
                <img src='/assets/images/logo.png' style="max-height: 100px;float: left;margin-right:50px;">
            </div>
            <div class="col-md-10">
                <h3>M.C. D.A.V. Hospital</h3>
                <h5>Mahatama Hans Raj Marg, ,Jalandhar-144008</h5>
                <h5>Phone:0181-2253572,08559067185</h5>
            </div>

        </td>
    </tr>
</table>