<ul class="nav" id="side-menu">
    
    <li>
        <a href="{!! route('customer-purchase-order.create') !!}">{!! lang('customer_purchase_order.create') !!} </a>
    </li>

    <li>
        <a href="{!! route('customer-purchase-order.index') !!}">{!! lang('customer_purchase_order.list') !!} </a>
    </li>

    <li>
        <a href="{!! route('sale-invoice.index') !!}">{!! lang('sale_invoice.list_invoice') !!} </a>
    </li>
</ul>
