<?php 
/**
 * :: Procedure Language File :: 
 * To manage procedure related language phrases.
 *
 **/

return [

	'procedure_detail'	=> 'Procedure Detail',
	'procedure'			=> 'Procedure',
	'procedures'		=> 'Procedures',
	'procedure_status'	=> 'Procedure Status',
	'procedures_list'	=> 'Procedures List',
    'procedure_in_use'  => 'Procedure already in use',
	'add_procedure'		=> 'Add Procedure',
	'is_sub_procedure'	=> 'Sub Procedure?',
	'main_procedure'	=> 'Main Procedure',
	'procedure_type'	=> 'Procedure Type',
	'procedure_uploaded'=> 'Procedure Uploaded',
	'file'				=> 'File',
];