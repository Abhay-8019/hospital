<?php 
/**
 * :: Unit Language File :: 
 * To manage unit related language phrases.
 *
 **/

return [

	'unit_detail'		=> 'Unit Detail',
	'unit'				=> 'Unit',
	'units'				=> 'Units',
	'unit_status'		=> 'Unit Status',
	'units_list'		=> 'Units List',
	'quantity'			=> 'Quantity',
	'alternate_quantity'=> 'Alt. Quantity',
    'unit_in_use'       => 'Unit already in use',
	'add_unit'			=>	'Add Unit'
];