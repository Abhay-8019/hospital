<?php
/**
 * :: Floor Language File ::
 * To manage roles related language phrases.
 *
 **/

return [

    'floor_detail'          => 'Floor Detail',
    'floor'				    => 'Floor',
    'floors'				=> 'Floors',
    'building_name'         => 'Building Name',
    'floor_status'			=> 'Floor Status',
    'floor_list'			=> 'Floor List',
    'floor_code'			=> 'Floor Code',
    'total_rooms'           => 'No of Rooms',
    'add_heading'           => 'Add Rooms'

];