<?php 
/**
 * :: User Language File :: 
 * To manage users related language phrases.
 *
 **/

return [

	'user_detail'	    => 'User Detail',
	'user_permissions'	=> 'User Permissions',
	'user'			    => 'User',
	'users'			    => 'Users',
	'user_status'	    => 'User Status',
	'users_list'	    => 'Users List',
	'username'		    => 'Username',
	'email'			    => 'Email',
	'password'		    => 'Password',
	'role'			    => 'Role',
	'hospital'		    => 'Hospital',
	'name'			    => 'Name',

];