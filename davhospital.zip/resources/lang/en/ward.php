<?php 
/**
 * :: Ward Language File :: 
 * To manage ward related language phrases.
 *
 **/

return [

	'ward_detail'	=> 'Ward Detail',
	'ward'			=> 'Ward',
	'wards'			=> 'Wards',
	'ward_status'	=> 'Ward Status',
	'wards_list'	=> 'Wards List',
    'ward_in_use'   => 'Ward already in use',
	'add_ward'		=> 'Add Ward'
];