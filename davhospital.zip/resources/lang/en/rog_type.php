<?php 
/**
 * :: Rog Type Language File :: 
 * To manage rog_type related language phrases.
 *
 **/

return [

	'rog_type_detail'	=> 'Rog Type Detail',
	'rog_type'			=> 'Rog Type',
	'rog_types'			=> 'Rog Types',
	'rog_type_status'	=> 'Rog Type Status',
	'rog_types_list'	=> 'Rog Types List',
    'rog_type_in_use'   => 'Rog Type already in use',
	'add_rog_type'		=> 'Add Rog Type'
];