<?php
/**
 employee_type language File
 */
return [
    'employee_type'             => 'Employee Type',
    'employee_detail'           => 'Employee Detail',
    'employee_list'             => 'Employee List',
    'employees'                 => 'Employees',
    'employee'                  => 'Employee',
];