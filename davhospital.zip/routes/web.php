<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});*/

Auth::routes();

Route::get('/', 'HomeController@index')->name('dashboard');
Route::get('dashboard',   ['as' => 'home','uses' => 'HomeController@index']);
//Route::get('/dashboard', 'HomeController@index')->name('dashboard');
//Route::get('/', 'Auth\LoginController@showLoginForm')->name('dashboard');

Route::group(['middleware' => 'auth'], function ()
{
    // Change Password
    Route::any('password/change',   ['as' => 'password.change', 'uses' => 'CommonController@changePassword']);
    Route::any('password/update',   ['as' => 'password.update', 'uses' => 'CommonController@updatePassword']);

    Route::any('calculate-age',     ['as' => 'calculate-age', 'uses' => 'CommonController@calculateAge']);

    // User Routes
    Route::resource('user','UserController');

    Route::any('users/action',          ['as' => 'user.action',   'uses' => 'UserController@userAction']);
    Route::any('users/paginate',        ['as' => 'user.paginate', 'uses' => 'UserController@userPaginate']);
    Route::any('users/toggle/{id?}',    ['as' => 'user.toggle',   'uses' => 'UserController@userToggle']);
    Route::get('users/drop/{id?}',      ['as' => 'user.drop',     'uses' => 'UserController@drop']);


    // Role Routes
    Route::resource('role','RoleController');

    Route::any('role/edit-permission/{id?}',    ['as' => 'role.edit-permission',   'uses' => 'RoleController@editPermission']);
    Route::any('role/update-permission/{id?}',  ['as' => 'role.update-permission', 'uses' => 'RoleController@updatePermission']);
    Route::any('role/action',                   ['as' => 'role.action',            'uses' => 'RoleController@roleAction']);
    Route::any('role/paginate',                 ['as' => 'role.paginate',          'uses' => 'RoleController@rolePaginate']);
    Route::any('role/toggle/{id?}',             ['as' => 'role.toggle',            'uses' => 'RoleController@roleToggle']);
    Route::get('role/drop/{id?}',               ['as' => 'role.drop',              'uses' => 'RoleController@drop']);

    // Menu Routes
    Route::resource('menu','MenuController');

    Route::any('menu/action',       ['as' => 'menu.action',   'uses' => 'MenuController@menuAction']);
    Route::any('menu/paginate',     ['as' => 'menu.paginate', 'uses' => 'MenuController@menuPaginate']);
    Route::any('menu/toggle/{id?}', ['as' => 'menu.toggle',   'uses' => 'MenuController@menuToggle']);
    Route::get('menu/drop/{id?}',   ['as' => 'menu.drop',     'uses' => 'MenuController@drop']);


    // Department Routes
    Route::resource('department','DepartmentController');

    Route::any('department/action',       ['as' => 'department.action',   'uses' => 'DepartmentController@departmentAction']);
    Route::any('department/paginate',     ['as' => 'department.paginate', 'uses' => 'DepartmentController@departmentPaginate']);
    Route::any('department/toggle/{id?}', ['as' => 'department.toggle',   'uses' => 'DepartmentController@departmentToggle']);
    Route::get('department/drop/{id?}',   ['as' => 'department.drop',     'uses' => 'DepartmentController@drop']);

    // Floor Routes
    Route::resource('floor','FloorController');

    Route::any('floor/action',              ['as' => 'floor.action',       'uses' => 'FloorController@floorAction']);
    Route::any('floor/paginate',            ['as' => 'floor.paginate',     'uses' => 'FloorController@floorPaginate']);
    Route::any('floor/toggle/{id?}',        ['as' => 'floor.toggle',       'uses' => 'FloorController@floorToggle']);
    Route::get('floor/drop/{id?}',          ['as' => 'floor.drop',         'uses' => 'FloorController@drop']);
    Route::get('floor/add-room/{id?}',      ['as' => 'floor.add',          'uses' => 'FloorController@addFloor']);
    Route::any('floor/save-room/{id?}',     ['as' => 'floor.saveroom',     'uses' => 'FloorController@storeRoom']);

    // Patient Registration Routes
    Route::resource('patient-registration','PatientRegistrationController');

    Route::any('patient-registration/action',       ['as' => 'patient-registration.action',    'uses' => 'PatientRegistrationController@patientRegistrationAction']);
    Route::any('patient-registration/paginate',     ['as' => 'patient-registration.paginate',  'uses' => 'PatientRegistrationController@patientRegistrationPaginate']);
    Route::any('patient-registration/toggle/{id?}', ['as' => 'patient-registration.toggle',    'uses' => 'PatientRegistrationController@patientRegistrationToggle']);
    Route::get('patient-registration/drop/{id?}',   ['as' => 'patient-registration.drop',      'uses' => 'PatientRegistrationController@drop']);
    Route::get('patient-registration/print/{id?}',   ['as' => 'patient-registration.print',    'uses' => 'PatientRegistrationController@printDetail']);

    Route::get('get-patient/{keyword?}',   ['as' => 'patient-registration.get-patients',    'uses' => 'PatientRegistrationController@getPatients']);
    Route::get('get-patient/{keyword?}',   ['as' => 'patient-registration.get-patients',    'uses' => 'PatientRegistrationController@getPatients']);


    // Doctor Registration Routes
    Route::resource('doctor-registration','DoctorRegistrationController');

    Route::any('doctor-registration/action',       ['as' => 'doctor-registration.action',   'uses' => 'DoctorRegistrationController@doctorRegistrationAction']);
    Route::any('doctor-registration/paginate',     ['as' => 'doctor-registration.paginate', 'uses' => 'DoctorRegistrationController@doctorRegistrationPaginate']);
    Route::any('doctor-registration/toggle/{id?}', ['as' => 'doctor-registration.toggle',   'uses' => 'DoctorRegistrationController@doctorRegistrationToggle']);
    Route::get('doctor-registration/drop/{id?}',   ['as' => 'doctor-registration.drop',     'uses' => 'DoctorRegistrationController@drop']);

    // Building Routes --> old Name = Branch
    Route::resource('building','BuildingController');

    Route::any('building/action',                       ['as' => 'building.action',         'uses' => 'BuildingController@buildingAction']);
    Route::any('building/paginate',                     ['as' => 'building.paginate',       'uses' => 'BuildingController@buildingPaginate']);
    Route::any('building/toggle/{id?}',                 ['as' => 'building.toggle',         'uses' => 'BuildingController@buildingToggle']);
    Route::get('building/drop/{id?}',                   ['as' => 'building.drop',           'uses' => 'BuildingController@drop']);
    Route::get('building/add-floor/{id?}',              ['as' => 'building.add',            'uses' => 'BuildingController@addFloor']);
    Route::any('building/save-floor/{id?}',             ['as' => 'building.savefloor',      'uses' => 'BuildingController@storeFloor']);

    // Designations Routes
    Route::resource('designation','DesignationController');

    Route::any('designation/action',       ['as' => 'designation.action',   'uses' => 'DesignationController@designationAction']);
    Route::any('designation/paginate',     ['as' => 'designation.paginate', 'uses' => 'DesignationController@designationPaginate']);
    Route::any('designation/toggle/{id?}', ['as' => 'designation.toggle',   'uses' => 'DesignationController@designationToggle']);
    Route::get('designation/drop/{id?}',   ['as' => 'designation.drop',     'uses' => 'DesignationController@drop']);


    // Staff Registrations Routes
    Route::resource('staff','StaffRegistrationController');

    Route::any('staff/action',       ['as' => 'staff.action',   'uses' => 'StaffRegistrationController@staffAction']);
    Route::any('staff/paginate',     ['as' => 'staff.paginate', 'uses' => 'StaffRegistrationController@staffPaginate']);
    Route::any('staff/toggle/{id?}', ['as' => 'staff.toggle',   'uses' => 'StaffRegistrationController@staffToggle']);
    Route::get('staff/drop/{id?}',   ['as' => 'staff.drop',     'uses' => 'StaffRegistrationController@drop']);

    // Room Routes
    Route::resource('room','RoomsController');

    Route::any('room/action',       ['as' => 'room.action',   'uses' => 'RoomsController@roomAction']);
    Route::any('room/paginate',     ['as' => 'room.paginate', 'uses' => 'RoomsController@roomPaginate']);
    Route::any('room/toggle/{id?}', ['as' => 'room.toggle',   'uses' => 'RoomsController@roomToggle']);
    Route::get('room/drop/{id?}',   ['as' => 'room.drop',     'uses' => 'RoomsController@drop']);

    // Employee_Type Registration Routes
    Route::resource('employee-type','EmployeeTypeController');

    Route::any('employee-type/action',       ['as' => 'employee-type.action',    'uses' => 'EmployeeTypeController@EmployeeTypeAction']);
    Route::any('employee-type/paginate',     ['as' => 'employee-type.paginate',  'uses' => 'EmployeeTypeController@EmployeeTypePaginate']);
    Route::any('employee-type/toggle/{id?}', ['as' => 'employee-type.toggle',    'uses' => 'EmployeeTypeController@EmployeeTypeToggle']);
    Route::get('employee-type/drop/{id?}',   ['as' => 'employee-type.drop',      'uses' => 'EmployeeTypeController@drop']);

    // AddTest Registration Routes
    Route::resource('add-test','AddTestController');

    Route::any('add-test/action',           ['as' => 'add-test.action',    'uses' => 'AddTestController@addTestAction']);
    Route::any('add-test/paginate',         ['as' => 'add-test.paginate',  'uses' =>'AddTestController@addTestPaginate']);
    Route::any('add-test/toggle/{id?}',     ['as' => 'add-test.toggle',    'uses' => 'AddTestController@addTestToggle']);
    Route::any('add-test/drop/{id?}',       ['as' => 'add-test.drop',      'uses' => 'AddTestController@drop']);
    Route::get('get-test-rate/{id?}',       ['as' => 'add-test.get-rate',      'uses' => 'AddTestController@getTestRate']);


    // Patient Test Routes
    Route::resource('patient-test', 'PatientTestsController',
        ['names' => [
            'index'     => 'patient-test.index',
            'create'    => 'patient-test.create',
            'store'     => 'patient-test.store',
            'edit'      => 'patient-test.edit',
            'update'    => 'patient-test.update',
            'show'      => 'patient-test.show'

        ],
            'except' => ['destroy']
        ]);
    Route::any('patient-test/drop/{id?}', ['as' => 'patient-test.drop',
        'uses' => 'PatientTestsController@drop']);

    Route::any('patient-test/paginate/{page?}', ['as' => 'patient-test.paginate',
        'uses' => 'PatientTestsController@patientTestsPaginate']);

    Route::any('patient-test/generate-report/{id?}', ['as' => 'patient-test.generate_report',
        'uses' => 'PatientTestsController@generateReport']);

    Route::any('patient-test/report/{id?}', ['as' => 'patient-test.report',
        'uses' => 'PatientTestsController@printReport']);

    // Specialization Registration Routes
    Route::resource('specialization','SpecializationController');

    Route::any('specialization/action',         ['as' => 'specialization.action',   'uses' => 'SpecializationController@specializationAction']);
    Route::any('specialization/paginate',       ['as' => 'specialization.paginate',  'uses' =>'SpecializationController@specializationPaginate']);
    Route::any('specialization/toggle/{id?}',   ['as' => 'specialization.toggle',   'uses' => 'SpecializationController@specializationToggle']);
    Route::get('specialization/drop/{id?}',     ['as' => 'specialization.drop',     'uses' => 'SpecializationController@drop']);

    // Doctor Registration Routes
    Route::resource('doctor','DoctorController');

    Route::any('doctor/action',         ['as' => 'doctor.action',      'uses' => 'DoctorController@DoctorAction']);
    Route::any('doctor/paginate',       ['as'=>'doctor.paginate',      'uses'=>'DoctorController@DoctorPaginate']);
    Route::any('doctor/toggle/{id?}',   ['as' => 'doctor.toggle',      'uses' => 'DoctorController@DoctorToggle']);
    Route::get('doctor/drop/{id?}',     ['as' => 'doctor.drop',        'uses' => 'DoctorController@drop']);

    // Event Type Routes
    Route::resource('event_type','EventTypeController');

    Route::any('event_type/action',         ['as' => 'event_type.action',   'uses' => 'EventTypeController@eventTypeAction']);
    Route::any('event_type/paginate',       ['as' => 'event_type.paginate', 'uses' => 'EventTypeController@eventTypePaginate']);
    Route::any('event_type/toggle/{id?}',   ['as' => 'event_type.toggle',   'uses' => 'EventTypeController@eventTypeToggle']);
    Route::get('event_type/drop/{id?}',     ['as' => 'event_type.drop',     'uses' => 'EventTypeController@drop']);

    // Add Event Routes
    Route::resource('add_events','AddEventController');

    Route::any('add_events/action',          ['as' => 'add_events.action',   'uses' => 'AddEventController@eventAction']);
    Route::any('add_events/paginate',        ['as' => 'add_events.paginate', 'uses' => 'AddEventController@eventPaginate']);
    Route::any('add_events/toggle/{id?}',    ['as' => 'add_events.toggle',   'uses' => 'AddEventController@eventToggle']);
    Route::get('add_events/drop/{id?}',      ['as' => 'add_events.drop',     'uses' => 'AddEventController@drop']);

    // Financial Year Routes
    Route::resource('financial-year','FinancialYearController');

    Route::any('financial-year/action',         ['as' => 'financial-year.action',   'uses' => 'FinancialYearController@financialYearAction']);
    Route::any('financial-year/paginate',       ['as' => 'financial-year.paginate', 'uses' => 'FinancialYearController@financialYearPaginate']);
    Route::any('financial-year/toggle/{id?}',   ['as' => 'financial-year.toggle',   'uses' => 'FinancialYearController@financialYearToggle']);
    Route::get('financial-year/drop/{id?}',     ['as' => 'financial-year.drop',     'uses' => 'FinancialYearController@drop']);

    // Vendor Routes
    Route::resource('vendor','VendorController');

    Route::any('vendor/action',         ['as' => 'vendor.action',   'uses' => 'VendorController@vendorAction']);
    Route::any('vendor/paginate',       ['as' => 'vendor.paginate', 'uses' => 'VendorController@vendorPaginate']);
    Route::any('vendor/toggle/{id?}',   ['as' => 'vendor.toggle',   'uses' => 'VendorController@vendorToggle']);
    Route::get('vendor/drop/{id?}',     ['as' => 'vendor.drop',     'uses' => 'VendorController@drop']);

    //Category Routes
    Route::resource('category','CategoryController');

    Route::any('category/action',           ['as' => 'category.action',    'uses' =>'CategoryController@categoryAction']);
    Route::any('category/paginate',         ['as' => 'category.paginate',  'uses' =>'CategoryController@categoryPaginate']);
    Route::any('category/toggle/{id?}',     ['as' => 'category.toggle',    'uses' =>'CategoryController@categoryToggle']);
    Route::any('category/drop/{id?}',       ['as' => 'category.drop',      'uses' =>'CategoryController@drop']);

     //Hospital Routes
    Route::resource('hospital','HospitalController');

    Route::any('hospital/action',           ['as' => 'hospital.action',    'uses' =>'HospitalController@hospital']);
    Route::any('hospital/paginate',         ['as' => 'hospital.paginate',  'uses' =>'HospitalController@hospitalPaginate']);
    Route::any('hospital/toggle/{id?}',     ['as' => 'hospital.toggle',    'uses' =>'HospitalController@hospitalToggle']);
    Route::any('hospital/drop/{id?}',       ['as' => 'hospital.drop',      'uses' =>'HospitalController@drop']);

    // HSN Code Routes
    Route::resource('hsn-code', 'HsnCodeController',
        ['names' => [
            'index'     => 'hsn-code.index',
            'create'    => 'hsn-code.create',
            'store'     => 'hsn-code.store',
            'edit'      => 'hsn-code.edit',
            'update'    => 'hsn-code.update',
            'drop'      => 'hsn-code.drop'
        ],
            'except' => ['show', 'destroy']
        ]);
    Route::any('hsn-code/paginate/{page?}', ['as' => 'hsn_code.paginate',
        'uses' => 'HsnCodeController@hsnCodePaginate']);

    Route::any('hsn-code/action', ['as' => 'hsn_code.action',
        'uses' => 'HsnCodeController@hsnCodeAction']);

    Route::any('hsn-code/toggle/{id?}', ['as' => 'hsn_code.toggle',
        'uses' => 'HsnCodeController@hsnCodeToggle']);

    Route::any('hsn-code/drop/{id?}', ['as' => 'hsn-code.drop',
        'uses' => 'HsnCodeController@drop']);

    Route::any('hsn-code/hsn-code-modal/', ['as' => 'hsn-code.hsn-modal',
        'uses' => 'HsnCodeController@hsnCodeModal']);

    Route::get('hsn-code/generate-excel', ['as' => 'hsn-code.generate-excel',
        'uses' => 'HsnCodeController@generateExcel']);

    Route::any('hsn-code/upload-excel', ['as' => 'hsn-code.upload-excel',
        'uses' => 'HsnCodeController@uploadExcel']);

    Route::any('hsn-code/download-sample-excel', ['as' => 'hsn-code.download-sample-excel',
        'uses' => 'HsnCodeController@downloadSampleExcel']);

    // Tax Routes
    Route::resource('tax-group', 'TaxController',
        ['names' => [
            'index'     => 'tax.index',
            'create'    => 'tax.create',
            'store'     => 'tax.store',
            'edit'      => 'tax.edit',
            'update'    => 'tax.update'
        ],
            'except' => ['show', 'destroy']
        ]);

    Route::any('tax-group/paginate/{page?}', ['as' => 'tax.paginate',
        'uses' => 'TaxController@taxPaginate']);

    Route::any('tax-group/action', ['as' => 'tax.action',
        'uses' => 'TaxController@taxAction']);

    Route::any('tax-group/toggle/{id?}', ['as' => 'tax.toggle',
        'uses' => 'TaxController@taxToggle']);

    Route::any('tax-group/drop/{id?}', ['as' => 'tax-group.drop',
        'uses' => 'TaxController@drop']);

    Route::any('tax-group/tax-modal', ['as' => 'tax.tax-modal',
        'uses' => 'TaxController@create']);

    // Product Routes
    Route::resource('medicines', 'ProductsController',
        ['names' => [
            'index'     => 'products.index',
            'create'    => 'products.create',
            'store'     => 'products.store',
            'edit'      => 'products.edit',
            'update'    => 'products.update'
        ],
            'except' => ['show', 'destroy']
        ]);
    Route::any('medicines/paginate/{page?}', ['as' => 'products.paginate',
        'uses' => 'ProductsController@productPaginate']);

    Route::any('medicines/action', ['as' => 'products.action',
        'uses' => 'ProductsController@productAction']);

    Route::any('medicines/toggle/{id?}', ['as' => 'products.toggle',
        'uses' => 'ProductsController@productToggle']);

    Route::get('medicines/drop/{id?}', ['as' => 'product.drop',
        'uses' => 'ProductsController@drop']);

    Route::get('medicines/get-price/{id?}/{list_id?}/{size_id?}', ['as' => 'products.get-price',
        'uses' => 'ProductsController@getPrice']);

    Route::get('medicines/get-sizes/{id?}', ['as' => 'products.get-sizes',
        'uses' => 'ProductsController@getProductSizes']);

    Route::get('medicines/get-cost/{id?}', ['as' => 'products.get-cost',
        'uses' => 'ProductsController@getProductCost']);

    Route::get('medicines/get-information/{id?}', ['as' => 'products.get-info',
        'uses' => 'ProductsController@getProductDetailForInvoice']);

    Route::get('medicines/generate-excel', ['as' => 'products.generate-excel',
        'uses' => 'ProductsController@generateExcel']);

    Route::any('medicines/upload-excel', ['as' => 'products.upload-excel',
        'uses' => 'ProductsController@uploadExcel']);

    Route::any('medicines/download-sample-excel', ['as' => 'products.download-sample-excel',
        'uses' => 'ProductsController@downloadSampleExcel']);

    // Product Group Routes
    Route::resource('medicine-group', 'ProductGroupController',
        ['names' => [
            'index'     => 'product-group.index',
            'create'    => 'product-group.create',
            'store'     => 'product-group.store',
            'edit'      => 'product-group.edit',
            'update'    => 'product-group.update'
        ],
            'except' => ['show', 'destroy']
        ]);
    Route::any('medicine-group/paginate/{page?}', ['as' => 'product-group.paginate',
        'uses' => 'ProductGroupController@productGroupPaginate']);

    Route::any('medicine-group/action', ['as' => 'product-group.action',
        'uses' => 'ProductGroupController@productGroupAction']);

    Route::any('medicine-group/toggle/{id?}', ['as' => 'product-group.toggle',
        'uses' => 'ProductGroupController@productGroupToggle']);

    Route::get('medicine-group/drop/{id?}', ['as' => 'product-group.drop',
        'uses' => 'ProductGroupController@drop']);

    Route::any('medicine-group/product-group-modal/', ['as' => 'product-group.product-group-modal',
        'uses' => 'ProductGroupController@productGroupModal']);

    Route::any('medicine-group/upload-excel', ['as' => 'product-group.upload-excel',
        'uses' => 'ProductGroupController@uploadExcel']);

    // Unit Routes
    Route::resource('unit', 'UnitController',
        ['names' => [
            'index'     => 'unit.index',
            'create'    => 'unit.create',
            'store'     => 'unit.store',
            'edit'      => 'unit.edit',
            'update'    => 'unit.update'
        ],
            'except' => ['show', 'destroy']
        ]);
    Route::any('unit/paginate/{page?}', ['as' => 'unit.paginate',
        'uses' => 'UnitController@unitPaginate']);

    Route::any('unit/action', ['as' => 'unit.action',
        'uses' => 'UnitController@unitAction']);

    Route::any('unit/toggle/{id?}', ['as' => 'unit.toggle',
        'uses' => 'UnitController@unitToggle']);

    Route::any('unit/drop/{id?}', ['as' => 'unit.drop',
        'uses' => 'UnitController@drop']);

    Route::any('unit/unit-modal/', ['as' => 'unit.unit-modal',
        'uses' => 'UnitController@unitModal']);

    // Financial Year Route
    Route::resource('financial-year','FinancialYearController', [
        'names' => [
            'index' => 'financial-year.index',
            'create' => 'financial-year.create',
            'store' => 'financial-year.store',
            'edit' => 'financial-year.edit',
            'update' => 'financial-year.update',
        ],
        'except' => ['show','destroy']
    ]);
    Route::any('financial-year/paginate/{page?}', ['as' => 'financial-year.paginate',
        'uses' => 'FinancialYearController@financialYearPaginate']);

    Route::any('financial-year/action', ['as' => 'financial-year.action',
        'uses' => 'FinancialYearController@action']);

    Route::any('financial-year/toggle/{id?}', ['as' => 'financial-year.toggle',
        'uses' => 'FinancialYearController@financialYearToggle']);

    Route::any('financial-year/drop/{id?}', ['as' => 'financial-year.drop',
        'uses' => 'FinancialYearController@drop']);

    // Bed Routes
    Route::resource('beds', 'BedMasterController',
        ['names' => [
            'index'     => 'beds.index',
            'create'    => 'beds.create',
            'store'     => 'beds.store',
            'edit'      => 'beds.edit',
            'update'    => 'beds.update'
        ],
            'except' => ['show', 'destroy']
        ]);
    Route::any('bed/paginate/{page?}', ['as' => 'beds.paginate',
        'uses' => 'BedMasterController@bedPaginate']);

    Route::any('bed/action', ['as' => 'beds.action',
        'uses' => 'BedMasterController@bedAction']);

    Route::any('bed/toggle/{id?}', ['as' => 'beds.toggle',
        'uses' => 'BedMasterController@bedToggle']);

    Route::any('bed/drop/{id?}', ['as' => 'beds.drop',
        'uses' => 'BedMasterController@drop']);

    Route::any('bed/bed-modal/', ['as' => 'beds.bed-modal',
        'uses' => 'BedMasterController@bedModal']);

    // Test Category Routes
    Route::resource('test-category', 'TestCategoryController',
        ['names' => [
            'index'     => 'test-category.index',
            'create'    => 'test-category.create',
            'store'     => 'test-category.store',
            'edit'      => 'test-category.edit',
            'update'    => 'test-category.update'
        ],
            'except' => ['show', 'destroy']
        ]);
    Route::any('test-category/paginate/{page?}', ['as' => 'test-category.paginate',
        'uses' => 'TestCategoryController@testCategoryPaginate']);

    Route::any('test-category/action', ['as' => 'test-category.action',
        'uses' => 'TestCategoryController@testCategoryAction']);

    Route::any('test-category/toggle/{id?}', ['as' => 'test-category.toggle',
        'uses' => 'TestCategoryController@testCategoryToggle']);

    Route::any('test-category/drop/{id?}', ['as' => 'test-category.drop',
        'uses' => 'TestCategoryController@drop']);

    Route::any('test-category/category-modal/', ['as' => 'test-category.category-modal',
        'uses' => 'TestCategoryController@testCategoryModal']);
    

    // Ward Routes
    Route::resource('wards', 'WardMasterController',
        ['names' => [
            'index'     => 'wards.index',
            'create'    => 'wards.create',
            'store'     => 'wards.store',
            'edit'      => 'wards.edit',
            'update'    => 'wards.update'
        ],
            'except' => ['show', 'destroy']
        ]);
    Route::any('ward/paginate/{page?}', ['as' => 'wards.paginate',
        'uses' => 'WardMasterController@wardPaginate']);

    Route::any('ward/action', ['as' => 'wards.action',
        'uses' => 'WardMasterController@wardAction']);

    Route::any('ward/toggle/{id?}', ['as' => 'wards.toggle',
        'uses' => 'WardMasterController@wardToggle']);

    Route::any('ward/drop/{id?}', ['as' => 'wards.drop',
        'uses' => 'WardMasterController@drop']);

    Route::any('ward/ward-modal/', ['as' => 'wards.ward-modal',
        'uses' => 'WardMasterController@wardModal']);

    // Rog Types Routes
    Route::resource('rog-types', 'RogTypeController',
        ['names' => [
            'index'     => 'rog-types.index',
            'create'    => 'rog-types.create',
            'store'     => 'rog-types.store',
            'edit'      => 'rog-types.edit',
            'update'    => 'rog-types.update'
        ],
            'except' => ['show', 'destroy']
        ]);
    Route::any('rog-type/paginate/{page?}', ['as' => 'rog-types.paginate',
        'uses' => 'RogTypeController@rogTypePaginate']);

    Route::any('rog-type/action', ['as' => 'rog-types.action',
        'uses' => 'RogTypeController@rogTypeAction']);

    Route::any('rog-type/toggle/{id?}', ['as' => 'rog-types.toggle',
        'uses' => 'RogTypeController@rogTypeToggle']);

    Route::any('rog-type/drop/{id?}', ['as' => 'rog-types.drop',
        'uses' => 'RogTypeController@drop']);

    Route::any('rog-type/rog-type-modal/', ['as' => 'rog-types.rog-type-modal',
        'uses' => 'RogTypeController@rogTypeModal']);

    // OT Types Routes
    Route::resource('ot-types', 'OTTypeController',
        ['names' => [
            'index'     => 'ot-types.index',
            'create'    => 'ot-types.create',
            'store'     => 'ot-types.store',
            'edit'      => 'ot-types.edit',
            'update'    => 'ot-types.update'
        ],
            'except' => ['show', 'destroy']
        ]);
    Route::any('ot-type/paginate/{page?}', ['as' => 'ot-types.paginate',
        'uses' => 'OTTypeController@otTypePaginate']);

    Route::any('ot-type/action', ['as' => 'ot-types.action',
        'uses' => 'OTTypeController@otTypeAction']);

    Route::any('ot-type/toggle/{id?}', ['as' => 'ot-types.toggle',
        'uses' => 'OTTypeController@otTypeToggle']);

    Route::any('ot-type/drop/{id?}', ['as' => 'ot-types.drop',
        'uses' => 'OTTypeController@drop']);

    Route::any('ot-type/ot-type-modal/', ['as' => 'ot-types.ot-type-modal',
        'uses' => 'OTTypeController@otTypeModal']);

    // Procedures Routes
    Route::resource('procedures', 'ProcedureController',
        ['names' => [
            'index'     => 'procedures.index',
            'create'    => 'procedures.create',
            'store'     => 'procedures.store',
            'edit'      => 'procedures.edit',
            'update'    => 'procedures.update'
        ],
            'except' => ['show', 'destroy']
        ]);
    Route::any('procedure/paginate/{page?}', ['as' => 'procedures.paginate',
        'uses' => 'ProcedureController@procedurePaginate']);

    Route::any('procedure/action', ['as' => 'procedures.action',
        'uses' => 'ProcedureController@procedureAction']);

    Route::any('procedure/toggle/{id?}', ['as' => 'procedures.toggle',
        'uses' => 'ProcedureController@procedureToggle']);

    Route::any('procedure/drop/{id?}', ['as' => 'procedures.drop',
        'uses' => 'ProcedureController@drop']);

    Route::any('procedure/procedure-modal/', ['as' => 'procedures.procedure-modal',
        'uses' => 'ProcedureController@procedureModal']);

    Route::any('procedure/upload-excel', ['as' => 'procedure.upload-excel',
        'uses' => 'ProcedureController@uploadExcel']);
    
// OPD Visits
    Route::any('opd-list/{id?}', ['as' => 'patient.opd-list',
        'uses' => 'OPDMasterController@listOPD']);

    Route::any('daily-opd-list/{id?}', ['as' => 'patient.daily-opd-list',
        'uses' => 'OPDMasterController@listDoctorOPD']);

    Route::any('opd-visit/{id?}', ['as' => 'patient.opd-visit',
        'uses' => 'OPDMasterController@index']);

    Route::any('opd-refer-patient/{id?}', ['as' => 'patient.opd-refer',
        'uses' => 'OPDMasterController@referPatient']);

    Route::any('opd-re-visit', ['as' => 'patient.opd-re-visit',
        'uses' => 'OPDMasterController@opdRevisit']);

    Route::any('opd-re-visit/{id?}', ['as' => 'patient.opd-re-visit',
        'uses' => 'OPDMasterController@opdRevisit']);

    Route::any('opd-visit-history/{id?}', ['as' => 'patient.opd-visit-history',
        'uses' => 'OPDMasterController@viewPatientOPDVisits']);

    Route::any('opd-visit-print/{id?}', ['as' => 'patient.opd-visit-print',
        'uses' => 'OPDMasterController@printVisit']);

    Route::any('opd-visit-store/{id?}', ['as' => 'patient.opd-visit-store',
        'uses' => 'OPDMasterController@saveOPDVisit']);

    Route::any('opd-visit-edit/{id?}', ['as' => 'patient.opd-visit-edit',
        'uses' => 'OPDMasterController@editVisit']);

    Route::any('opd-visit-update/{id?}', ['as' => 'patient.opd-visit-update',
        'uses' => 'OPDMasterController@updateOPDVisit']);

    Route::any('opd-visit/drop/{id?}', ['as' => 'patient.opd-visit-drop',
        'uses' => 'OPDMasterController@drop']);

    Route::any('opd-procedure-visit/{id?}/{pid?}', ['as' => 'patient.opd-procedure-visit',
        'uses' => 'OPDMasterController@addProcedureEntry']);

    Route::any('opd-procedure-list', ['as' => 'patient.opd-procedure-list',
        'uses' => 'OPDMasterController@listProcedureEntry']);

    Route::any('opd-procedure-drop/{id?}', ['as' => 'patient.opd-procedure-drop',
        'uses' => 'OPDMasterController@dropProcedureEntry']);

    // IPD Routes
    Route::any('ipd-patients/{id?}', ['as' => 'patient.ipd-list',
        'uses' => 'IPDMasterController@listIPD']);

    Route::any('ipd-entry/{id?}', ['as' => 'patient.ipd-entry',
        'uses' => 'IPDMasterController@index']);

    Route::any('ipd-store/{id?}', ['as' => 'patient.ipd-store',
        'uses' => 'IPDMasterController@saveIPDDetail']);

    Route::any('ipd-print/{id?}', ['as' => 'patient.ipd-print',
        'uses' => 'IPDMasterController@printIPDDetail']);

    Route::any('edit-ipd-entry/{id?}', ['as' => 'patient.edit-ipd-entry',
        'uses' => 'IPDMasterController@edit']);

    Route::any('ipd-update/{id?}', ['as' => 'patient.ipd-update',
        'uses' => 'IPDMasterController@updateIPDDetail']);

    Route::any('ipd-drop/{id?}', ['as' => 'patient.ipd-drop',
        'uses' => 'IPDMasterController@drop']);
    
    Route::any('ipd-procedure-visit/{id?}/{pid?}', ['as' => 'patient.ipd-procedure-visit',
        'uses' => 'IPDMasterController@addProcedureEntry']);

    Route::any('ipd-discharge/{id?}', ['as' => 'patient.ipd-discharge',
        'uses' => 'IPDMasterController@dischargeIPDPatient']);

    Route::any('discharge-summary/{id?}', ['as' => 'patient.ipd-discharge-summary',
        'uses' => 'IPDMasterController@printIPDDetail']);

    /*Route::any('opd-visit-edit/{id?}', ['as' => 'patient.opd-visit-edit',
        'uses' => 'OPDMasterController@editVisit']);

    Route::any('opd-visit-update/{id?}', ['as' => 'patient.opd-visit-update',
        'uses' => 'OPDMasterController@updateOPDVisit']);

    Route::any('opd-visit/drop/{id?}', ['as' => 'patient.opd-visit-drop',
        'uses' => 'OPDMasterController@drop']);*/

    //Reports Routes

    Route::any('opd-medsummary', ['as' => 'report.opd-medsummary',
        'uses' => 'ReportController@medSummary']);

    Route::any('report/opd-visits', ['as' => 'report.opd-visits',
        'uses' => 'ReportController@opdVisits']);

    Route::any('report/patient-wise-visits', ['as' => 'report.patient-wise-visits',
        'uses' => 'ReportController@opdVisits']);

    Route::any('report/doctor-wise-visits', ['as' => 'report.doctor-wise-visits',
        'uses' => 'ReportController@opdVisits']);

    Route::any('report/department-wise-visits', ['as' => 'report.department-wise-visits',
        'uses' => 'ReportController@opdVisits']);

    Route::any('report/ipd-patients', ['as' => 'report.ipd-patients',
        'uses' => 'ReportController@ipdPatients']);

    Route::any('report/bed-occupancy', ['as' => 'report.bed-occupancy',
        'uses' => 'ReportController@bedOccupancy']);

    Route::any('report/patient-tests', ['as' => 'report.patient-tests',
        'uses' => 'ReportController@patientTestSummary']);
});
