<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PatientTest extends Model
{

    /**
     * The database table used by the model.
     * @var string
     */
    protected $table = 'patient_test';

    /**
     * The attributes that are mass assignable.
     * @var array
     */
    protected $fillable = [
        'receipt_no',
        'hospital_id',
        'patient_id',
        'doctor_id',
        'department_id',
        'test_date',
        'deliver_date',
        'report_generate_date',
        'deliver_to',
        'created_by',
        'updated_by'
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function tests()
    {
        return $this->hasMany('App\PatientTestsDetail', 'patient_test_id');
    }

    /**
     * @param array $inputs
     * @param int $id
     *
     * @return \Illuminate\Validation\Validator
     */
    public function validatePatientTest($inputs, $id = null)
    {
        $rules['patient'] = 'required';
        $rules['doctor'] = 'required';
        $rules['department'] = 'required';
        $rules['test_date'] = 'required|date';
        //$rules['deliver_date'] = 'required|date';
        return \Validator::make($inputs, $rules);
    }

    /**
     * @param array $inputs
     * @param int $id
     *
     * @return mixed
     */
    public function store($inputs, $id = null)
    {
        if ($id) {
            $this->find($id)->update($inputs);
            return $id;
        } else {
            return $this->create($inputs)->id;
        }
    }

    /**
     * get last receipt no
     *
     * @return mixed
     */
    public function getLastReceiptNo()
    {
        return $this->count();
    }

    /**
     * Method is used to search laboratory & get detail.
     *
     * @param array $search
     * @param int $skip
     * @param int $perPage
     *
     * @return mixed
     */
    public function getPatientTest($search = null, $skip, $perPage)
    {
        $take = ((int)$perPage > 0) ? $perPage : 20;
        // default filter if no search
        $filter = 1;

        if (is_array($search) && count($search) > 0)
        {
            $filter .= (array_key_exists('keyword', $search) && $search['keyword'] != "") ? " AND (first_name LIKE '%" .
                //addslashes($search['keyword']) . "%' OR last_name LIKE '%" .
                addslashes($search['keyword']) . "%' OR mobile LIKE '%" .
                //addslashes($search['keyword']) . "%' OR first_name LIKE '%" .
                //addslashes($search['keyword']) . "%' OR diagnostic_code LIKE '%" .
                //addslashes($search['keyword']) . "%' OR diagnostic_name LIKE '%" .
                addslashes($search['keyword']) . "%') " : "";
        }
        return $this
            ->leftJoin('patient_tests_detail', 'patient_tests_detail.patient_test_id', '=', 'patient_test.id')
            //->leftJoin('diagnostics', 'diagnostics.id', '=', 'patient_tests_detail.diagnostic_id')
            ->leftJoin('patient_registration', 'patient_registration.id', '=', 'patient_test.patient_id')
            ->whereRaw($filter)->orderBy('patient_test.id', 'DESC')
            ->skip($skip)->take($take)
            ->groupBy('patient_test.id')
            ->get(
                [
                    'patient_test.*',
                    \DB::raw('SUM(patient_tests_detail.test_rate) as total'),
                    'patient_registration.first_name',
                    'patient_registration.age',
                    'patient_registration.blood_group',
                    'patient_registration.mobile',

                    //'diagnostics.diagnostic_code',
                    //'diagnostics.diagnostic_name'
                ]
            );
    }

    /**
     * Method is used to get total laboratory wise.
     *
     * @param array $search
     *
     * @return mixed
     */
    public function totalPatientTest($search = null)
    {
        // if no search add where
        $filter = 1;

        // when search news
        if (is_array($search) && count($search) > 0) {
            $filter .= (array_key_exists('keyword', $search) && $search['keyword'] != "") ? " AND (first_name LIKE '%" .
                //addslashes($search['keyword']) . "%' OR last_name LIKE '%" .
                //addslashes($search['keyword']) . "%' OR first_name LIKE '%" .
                addslashes($search['keyword']) . "%' OR mobile LIKE '%" .
                //addslashes($search['keyword']) . "%' OR diagnostic_code LIKE '%" .
               // addslashes($search['keyword']) . "%' OR diagnostic_name LIKE '%" .
                addslashes($search['keyword']) . "%') " : "";
        }
        return $this
            ->leftJoin('patient_tests_detail', 'patient_tests_detail.patient_test_id', '=', 'patient_test.id')
            //->leftJoin('diagnostics', 'diagnostics.id', '=', 'patient_tests_detail.diagnostic_id')
            ->leftJoin('patient_registration', 'patient_registration.id', '=', 'patient_test.patient_id')
            ->whereRaw($filter)->get([\DB::raw('count(DISTINCT patient_test.id) as total')])->first();
    }

    public function drop($id)
    {
        $this->find($id)->delete();
    }
    
    
}
