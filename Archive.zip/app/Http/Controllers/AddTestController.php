<?php

namespace App\Http\Controllers;

use App\AddTest;
use App\TestCategory;
use Illuminate\Http\Request;

class AddTestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admin.addTest.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $category = (new TestCategory)->getTestCategoryService();
        $tests = (new AddTest)->getAddTestService();
        return view('admin.addTest.create', compact('category', 'tests'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $inputs = $request->all();
        $validator = (new AddTest)->validateAddTest($inputs);
        if($validator->fails()){
            return validationResponse(false, 206, "", "", $validator->messages());
        }
        try{
            \DB::beginTransaction();
            unset($inputs['_token']);

            $subIds = null;
            if(count($inputs['sub_tests']) > 0) {
                $subIds = implode(',', $inputs['sub_tests']);
            }

            $inputs = $inputs + [
                'test_category_id' => $inputs['test_category'],
                'sub_test_ids' => $subIds,
                'created_by' => authUserId(),
                'hospital_id' => loggedInHospitalId()
            ];

            (new AddTest)->store($inputs);
            \DB::commit();
            $route = route('add-test.index');
            return validationResponse(true, 201, lang('messages.created', lang('test.test')), $route);
        }catch(\Exception $exception){
            \DB::rollBack();
            return validationResponse(false, 207, lang('messages.server_error'));
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param AddTest $addTest
     * @return \Illuminate\Http\Response
     */
    public function edit(AddTest $addTest)
    {
        $result = $addTest;
        if(!$result){
            abort(404);
        }
        $category = (new TestCategory)->getTestCategoryService();
        $tests = (new AddTest)->getAddTestService();
        unset($tests[$result->id]);
        return view('admin.addTest.edit', compact('result', 'category', 'tests'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param AddTest $addTest
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AddTest $addTest)
    {
        $result = $addTest;
        if(!$result){
            return validationResponse(false, 206, lang('messages.invalid_id',
                string_manip(lang('test.test'))));
        }

        $id = $result->id;

        $inputs = $request->all();

        $validator = (new AddTest)-> validateAddTest($inputs, $id);
        if($validator->fails()){
            return validationResponse(false, 206, "", "", $validator->messages());
        }
        try{
            \DB::beginTransaction();

            $subIds = null;
            if(isset($inputs['sub_tests']) && count($inputs['sub_tests']) > 0) {
                $subIds = implode(',', $inputs['sub_tests']);
            }

            $inputs = $inputs + [
                'test_category_id' => $inputs['test_category'],
                'sub_test_ids' => $subIds,
                'status' => isset($inputs['status']) ? 1 : 0,
                'updated_by' => authUserId()
            ];

            (new AddTest)->store($inputs, $id);
            \DB::commit();
            $route = route('add-test.index');
            return validationResponse(true, 201, lang('messages.updated', lang('test.test')), $route);
        }catch(\Exception $exception){
            \DB::rollBack();
            return validationResponse(false, 207, $exception->getMessage() . lang('messages.server_error'));
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(AddTest $addTest)
    {
        return "In Progress";
    }

    public function addTestToggle($id = null)
    {
        if(!\Request::ajax()){
            return lang('messages.server_error');
        }
        $result = AddTest::find($id);
        try{

            $result->update(['status'=>!$result->status]);
            $response=['status'=>1, 'data'=>(int)$result->status . '.gif'];
            return json_encode($response);
        }catch(\Exception $exception){
            return lang('messages.invalid_id',string_manip(lang('test.test')));
        }
    }

    public function addTestPaginate(Request $request, $pageNumber = null)
    {
        if (!\Request::isMethod('post') && !\Request::ajax()) { //
            return lang('messages.server_error');
        }

        $inputs = $request->all();
        $page = 1;
        if (isset($inputs['page']) && (int)$inputs['page'] > 0) {
            $page = $inputs['page'];
        }

        $perPage = 20;
        if (isset($inputs['perpage']) && (int)$inputs['perpage'] > 0) {
            $perPage = $inputs['perpage'];
        }

        $start = ($page - 1) * $perPage;
        if (isset($inputs['form-search']) && $inputs['form-search'] != '') {
            $inputs = array_filter($inputs);
            unset($inputs['_token']);

            $data = (new AddTest)->getAddTest($inputs, $start, $perPage);
            $totalAddTest = (new AddTest)->totalAddTest($inputs);
            $total = $totalAddTest->total;
        } else {

            $data = (new AddTest)->getAddTest($inputs, $start, $perPage);
            $totalAddTest = (new AddTest)->totalAddTest($inputs);
            $total = $totalAddTest->total;
        }

        return view('admin.addTest.load_data', compact('data', 'total', 'page', 'perPage'));
    }

    /**
     * @param null $id
     * @return string
     */
    public function getTestRate($id = null)
    {
        if (!\Request::ajax()) {
            return lang('messages.server_error');
        }
        $result = AddTest::find($id);
        try {
            echo $result->cost; exit(0);
        } catch(\Exception $exception)
        {
            return lang('messages.invalid_id', string_manip(lang('test.test')));
        }
    }

    public function drop($id)
    {
        

        if (!\Request::ajax()) {
            return lang('messages.server_error');
        }

        
        if (isAdmin()) {
            try
            {
                $update = ['deleted_by' => authUserId()];
                (new AddTest)->store($update, $id);
                (new AddTest)->drop($id);
                $response = ['status' => 1, 'message' => lang('messages.deleted', lang('test.test'))];
            } catch (\Exception $exception) {
                $response = ['status' => 0, 'message' => lang('messages.server_error')];
            }
        }

        return json_encode($response);
    }






}
