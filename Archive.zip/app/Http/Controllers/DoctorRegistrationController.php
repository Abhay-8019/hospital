<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\DoctorRegistration;
use App\User;

class DoctorRegistrationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admin.doctor_registration.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $doctorCode = (new DoctorRegistration)->getDoctorCode();
        $genderArr = lang('common.genderArray');

        return view('admin.doctor_registration.create', compact('doctorCode', 'genderArr'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\DoctorRegistration  $doctorRegistration
     * @return \Illuminate\Http\Response
     */
    public function edit(DoctorRegistration $doctorRegistration)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\DoctorRegistration  $doctorRegistration
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DoctorRegistration $doctorRegistration)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\DoctorRegistration  $doctorRegistration
     * @return \Illuminate\Http\Response
     */
    public function destroy(DoctorRegistration $doctorRegistration)
    {
        //
    }
    /**
     * Used to load more records and render to view.
     *
     * @param int $pageNumber
     *
     * @return Response
     */
    public function doctorRegistrationPaginate(Request $request, $pageNumber = null)
    {
        if (!\Request::isMethod('post') && !\Request::ajax()) { //
            return lang('messages.server_error');
        }

        $inputs = $request->all();
        $page = 1;
        if (isset($inputs['page']) && (int)$inputs['page'] > 0) {
            $page = $inputs['page'];
        }

        $perPage = 20;
        if (isset($inputs['perpage']) && (int)$inputs['perpage'] > 0) {
            $perPage = $inputs['perpage'];
        }

        $start = ($page - 1) * $perPage;
        if (isset($inputs['form-search']) && $inputs['form-search'] != '') {
            $inputs = array_filter($inputs);
            unset($inputs['_token']);

            $data = (new DoctorRegistration)->getDoctors($inputs, $start, $perPage);
            $totalDepartment = (new DoctorRegistration)->totalDoctors($inputs);
            $total = $totalDepartment->total;
        } else {

            $data = (new DoctorRegistration)->getDoctors($inputs, $start, $perPage);
            $totalDepartment = (new DoctorRegistration)->totalDoctors($inputs);
            $total = $totalDepartment->total;
        }

        return view('admin.doctor_registration.load_data', compact('data', 'total', 'page', 'perPage'));
    }

    /**
     * @param null $id
     * @return string
     */
    public function doctorRegistrationToggle($id = null)
    {
        if (!\Request::isMethod('post') && !\Request::ajax()) {
            return lang('messages.server_error');
        }
        // get the User w.r.t id
        $results = DoctorRegistration::find($id);

        try {

            $results->update(['status' => !$results->status]);
            $response = ['status' => 1, 'data' => (int)$results->status . '.gif'];
            // return json response
            return json_encode($response);

        } catch (\Exception $exception) {
            return lang('messages.invalid_id', string_manip(lang('doctor.doctor')));
        }
    }
}
