<?php

namespace App\Http\Controllers;

use App\AddTest;
use App\DailyProcedureVisits;
use App\Department;
use App\Doctor;
use App\DoctorFee;
use App\Hospital;
use App\OPDMaster;
use App\OralMedicationMaster;
use App\Procedures;
use App\ProcedureTreatmentMaster;
use App\Product;
use App\RogType;
use Illuminate\Http\Request;
use App\PatientRegistration;
use App\User;

class OPDMasterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param null $id
     * @return \Illuminate\Http\Response
     */
    public function index($id = null)
    {
        $result = OPDMaster::find($id);
        if(!$result) {
            return redirect()->back()->with('error', 'Error: Invalid OPD.');
        }

        $patient = (new PatientRegistration)->getPatientDetail($result->patient_id);

        $rogTypes = (new RogType)->getRogTypeService();
        $tests = (new AddTest)->getAddTestService(false); 
        $procedures = (new Procedures)->getProcedureService(['main_only' => 1]);
        $medicines = (new Product)->getProductsService();
        
        return view('admin.opd_visits.create', compact('result', 'rogTypes', 'tests',
            'procedures', 'medicines', 'patient'));
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function opdRevisit($id=null)
    {
        $inputs = \Input::all();
        if($id != null)
        {
            $inputs['patient_code'] = $id;
            $inputs['form-search'] = 1;
        }

        if (count($inputs) > 0)
        {
            $doctors = (new Doctor)->getDoctorList();
            $departments = (new Department)->getDepartmentService();
            if (isset($inputs['form-save']))
            {
                if (!isset($inputs['doctor'])) {
                    return validationResponse(false, 207, "Please select doctor & save visit.");
                }

                if (!isset($inputs['department'])) {
                    return validationResponse(false, 207, "Please select department & save visit.");
                }

                $lastOPDId = (new OPDMaster)->getLastOPDNumber();
                $opdSave = [
                    //'opd_number'  => date('ym') . $lastOPDId,
                    'opd_number'  => date('ym') . $lastOPDId,
                    'department_id'  => $inputs['department'],
                    'doctor_id'  => $inputs['doctor'],
                    'patient_id'  => $inputs['p_id'],
                    'opdremarks'     => $inputs['opdremarks'],
                    //'visit_date'  => currentDate(true),
                    'visit_date'  => currentDate(),
                    'created_by'  => authUserId(),
                    'is_completed'  => 0,
                    'flag' => 'old',
                ];
                (new OPDMaster)->store($opdSave);
                $route   = route('patient.opd-re-visit');
                $message = lang('messages.created', lang('opd_master.opd_revisit'));
                return validationResponse(true, 201, $message, $route);
            }
            

            $data = (new OPDMaster)->filterOPDVisits($inputs);
            //dd($data);
            if($id == null)            
                return view('admin.opd_visits.opd_revisit_load', compact('data', 'doctors', 'departments'));
            else
                return view('admin.opd_visits.opd-re-visit-single', compact('data', 'doctors', 'departments','inputs'));                
        }
        return view('admin.opd_visits.opd-re-visit');
    }
    /**
     * @param null $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function saveOPDVisit($id = null)
    {
        $inputs = \Input::all();
        $validator = (new OPDMaster)->validateOPDVisit($inputs);
        if ($validator->fails()) {
            return validationResponse(false, 206, "", "", $validator->messages());
        }

        try
        {
            \DB::beginTransaction();

            $testIds = (isset($inputs['test_ids'])) ? implode(',', $inputs['test_ids']) : "";
            $inputs['investigation_test_ids'] = $testIds;
            $inputs['is_completed'] = 1;
            $inputs['doctor_id'] = $inputs['d_id'];
            $inputs['patient_id'] = $inputs['p_id'];
            $inputs['rog_type_text'] = $inputs['rog_type'];
            unset($inputs['rog_type']);

            //dd($inputs);
            (new OPDMaster)->store($inputs, $id);

            $savePTreatment = [];

            if($inputs['addpro'] == 1)
            {
                $procedureMedicines = (is_array($inputs['procedure_medicine']) && count($inputs['procedure_medicine']) > 0)
                    ? $inputs['procedure_medicine'] : [];

                foreach($procedureMedicines as $key => $value)
                {
                    $procedure = $inputs['procedure'][$key];
                    $pMedicine = $inputs['procedure_medicine'][$key];
                    $pDose = $inputs['procedure_dose'][$key];
                    $procedure_dose_unit = $inputs['procedure_dose_unit'][$key];
                    $pTiming = $inputs['timing'][$key];
                    $procedure_days = $inputs['procedure_days'][$key];                    
                    $pRemarks = $inputs['remarks'][$key];

                    $savePTreatment[] = [
                        'opd_master_id'  => $id,
                        'procedure_id'  => $procedure,
                        'procedure_date'  => currentDate(true),
                        'procedure_medicine_id'  => $pMedicine,
                        'dose'  => $pDose,
                        'dose_unit' => $procedure_dose_unit,
                        'timing'  => $pTiming,
                        'procedure_days'  => $procedure_days,
                        'remarks'  => $pRemarks,
                    ];
                }

                if(count($savePTreatment) > 0) {
                    (new ProcedureTreatmentMaster)->store($savePTreatment, null, true);
                }
            }

            if($inputs['addmedi'] == 1)
            {
                $saveMedicines = [];
                $procedureMedicines = (is_array($inputs['medicine']) && count($inputs['medicine']) > 0)
                    ? $inputs['medicine'] : [];
                foreach($procedureMedicines as $key => $value)
                {
                    $mMedicine = $inputs['medicine'][$key];
                    $mDose = $inputs['medicine_dose'][$key];
                    $mUnit = $inputs['medicine_dose_unit'][$key];
                    $mTiming = $inputs['medicine_timing'][$key];
                    $medicine_days = $inputs['medicine_days'][$key];                    
                    $mRemarks = $inputs['medicine_remarks'][$key];

                    $saveMedicines[] = [
                        'opd_master_id'  => $id,
                        'medicine_id'  => $mMedicine,
                        'procedure_date'  => currentDate(true),
                        'medicine_days'  => $medicine_days,
                        'dose'  => $mDose,
                        'dose_unit'  => $mUnit,
                        'timing'  => $mTiming,
                        'remarks'  => $mRemarks,
                    ];
                }


                if(count($saveMedicines) > 0) {
                    (new OralMedicationMaster)->store($saveMedicines, null, true);
                }
            }

            \DB::commit();
            $route   = route('home');
            $message = lang('messages.created', lang('opd_master.opd_visit'));
            return validationResponse(true, 201, $message, $route);
        } catch (\Exception $e) {
            \DB::rollBack();
            return validationResponse(false, 207,  lang('messages.server_error'));
        }
    }

    /**
     * Display a listing of the resource.
     *
     * @param null $id
     * @return \Illuminate\Http\Response
     */
    public function printVisit($id = null)
    {
        $result = (new OPDMaster)->getOPDVisitDetail($id);
        if(!is_object($result)) {
            return abort(404);
        }

        if (isDoctor() && $result->doctor_id != authUser()->doctor_id) {
            return redirect()->back()->with("error", "Permission denied to access this visit.");
        }

        $pMedicines = (new ProcedureTreatmentMaster)->getOPDProcedureTreatments(['opd_id' => $id]);

        
        $mMedicines = (new OralMedicationMaster)->getOPDOralMedicines(['opd_id' => $id]); 
        return view('admin.opd_visits.visit_print', compact('result', 'pMedicines', 'mMedicines'));
    }



    /**
     * @param null $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\RedirectResponse|\Illuminate\View\View|void
     */
    public function editVisit($id = null)
    {
        $result = (new OPDMaster)->getOPDVisitDetail($id);
        if(!is_object($result)) {
            return abort(404);
        }

        if (isDoctor() && $result->doctor_id != authUser()->doctor_id) {
            return redirect()->back()->with("error", "Permission denied to access this visit.");
        }





        $pMedicines = (new ProcedureTreatmentMaster)->getOPDProcedureTreatments(['opd_id' => $id],'procedure_treatment_master.id','asc');
        $mMedicines = (new OralMedicationMaster)->getOPDOralMedicines(['opd_id' => $id]);

        $tests = (new AddTest)->getAddTestService(false);
        $procedures = (new Procedures)->getProcedureService(['main_only' => 1]);
        $medicines = (new Product)->getProductsService();

// If Procedures and Medicines are blank, then pick from last visit.
        $lastVisit = (new OPDMaster)->getLastOPDVisitDetail($result->patient_id,$result->visit_date,$result->department_id);
        if(count($lastVisit) > 0) { 
            if(count($pMedicines)==0)
                $pMedicines = (new ProcedureTreatmentMaster)->getOPDProcedureTreatments(['opd_id' => $lastVisit->id]);
            if(count($mMedicines)==0)
                $mMedicines = (new OralMedicationMaster)->getOPDOralMedicines(['opd_id' => $lastVisit->id]);
            
            if(empty($result->rog_type_text) && !empty($lastVisit->rog_type_text))
                $result->rog_type_text = '-->' . $lastVisit->rog_type_text;



            if(empty($result->blood_pressure) && !empty($lastVisit->blood_pressure))
                $result->blood_pressure = '-->' . $lastVisit->blood_pressure;
            
            if(empty($result->pulse_rate) && !empty($lastVisit->pulse_rate))
                $result->pulse_rate = '-->' . $lastVisit->pulse_rate;
            
            if(empty($result->temperature) && !empty($lastVisit->temperature))
                $result->temperature = '-->' . $lastVisit->temperature;

        }

        //dd($result);
        return view('admin.opd_visits.edit', compact('result', 'procedures', 'medicines', 'tests',
            'pMedicines', 'mMedicines','lastVisit'));
    }

    /**
     * @param null $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function updateOPDVisit($id = null)
    {
        $inputs = \Input::all();
        $validator = (new OPDMaster)->validateOPDVisit($inputs);
        if ($validator->fails()) {
            return validationResponse(false, 206, "", "", $validator->messages());
        }
        
        try
        {
            \DB::beginTransaction();

            $testIds = (isset($inputs['test_ids'])) ? implode(',', $inputs['test_ids']) : "";
            $inputs['investigation_test_ids'] = $testIds;
            $inputs['is_completed'] = 1;
            $inputs['doctor_id'] = $inputs['d_id'];
            $inputs['patient_id'] = $inputs['p_id'];
            $inputs['rog_type_text'] = $inputs['rog_type'];
            unset($inputs['rog_type']);
            (new OPDMaster)->store($inputs, $id);

            $savePTreatment = [];

            //dd($inputs);

            if($inputs['addpro'] == 1)
            {
                $procedureMedicines = (is_array($inputs['procedure_medicine']) && count($inputs['procedure_medicine']) > 0)
                    ? $inputs['procedure_medicine'] : [];

                foreach($procedureMedicines as $key => $value)
                {
                    $procedure = $inputs['procedure'][$key];
                    $pMedicine = $inputs['procedure_medicine'][$key];
                    $pDose = $inputs['procedure_dose'][$key];
                    $procedure_dose_unit = $inputs['procedure_dose_unit'][$key];

                    $pTiming = $inputs['timing'][$key];
                    $procedure_days = $inputs['procedure_days'][$key];                    

                    $pRemarks = $inputs['remarks'][$key];
                    
                    $procedureId = isset($inputs['pro_id'][$key]) ? $inputs['pro_id'][$key] : 0;

                    if ($procedureId > 0)
                    {
                        $updatePTreatment = [
                            'opd_master_id'  => $id,
                            'procedure_id'  => $procedure,
                            //'procedure_date'  => currentDate(true),
                            'procedure_medicine_id'  => $pMedicine,
                            'dose'  => $pDose,
                            'dose_unit' => $procedure_dose_unit,
                            'timing'  => $pTiming,
                            'procedure_days'  => $procedure_days,
                            'remarks'  => $pRemarks,
                        ];
                        (new ProcedureTreatmentMaster)->store($updatePTreatment, $procedureId);

                    } else {

                        $savePTreatment[] = [
                            'opd_master_id'  => $id,
                            'procedure_id'  => $procedure,
                            'procedure_date'  => currentDate(true),
                            'procedure_medicine_id'  => $pMedicine,
                            'dose'  => $pDose,
                            'dose_unit' => $procedure_dose_unit,
                            'timing'  => $pTiming,
                            'procedure_days'  => $procedure_days,
                            'remarks'  => $pRemarks,
                        ];

                    }
                }

                $oldProcedures = [];
                $pMedicines = (new ProcedureTreatmentMaster)->getOPDProcedureTreatments(['opd_id' => $id]);
                if (is_object($pMedicines)) {
                    $oldProcedures = array_column($pMedicines->toArray(), 'id');
                }

                if(count($savePTreatment) > 0) {
                    (new ProcedureTreatmentMaster)->store($savePTreatment, null, true);
                }

                $newProcedures = (isset($inputs['pro_id']) && count($inputs['pro_id']) > 0) ? $inputs['pro_id'] : [];

                $deletedProcedures = array_diff($oldProcedures, $newProcedures);
                if (count($deletedProcedures) > 0) {
                    (new ProcedureTreatmentMaster)->dropProcedures($deletedProcedures);
                }
            }
            else
            {
                $oldProcedures = [];
                $pMedicines = (new ProcedureTreatmentMaster)->getOPDProcedureTreatments(['opd_id' => $id]);
                if (is_object($pMedicines)) {
                    $oldProcedures = array_column($pMedicines->toArray(), 'id');
                }
                if (count($oldProcedures) > 0) {
                    (new ProcedureTreatmentMaster)->dropProcedures($oldProcedures);
                }
                
            }

            if($inputs['addmedi'] == 1)
            {
                $saveMedicines = [];
                $procedureMedicines = (is_array($inputs['medicine']) && count($inputs['medicine']) > 0)
                    ? $inputs['medicine'] : [];
                foreach($procedureMedicines as $key => $value)
                {
                    $mMedicine = $inputs['medicine'][$key];
                    $mDose = $inputs['medicine_dose'][$key];
                    $mUnit = $inputs['medicine_dose_unit'][$key];
                    $mTiming = $inputs['medicine_timing'][$key];
                    $medicine_days = $inputs['medicine_days'][$key];                    

                    $mRemarks = $inputs['medicine_remarks'][$key];

                    $medicineId = isset($inputs['med_id'][$key]) ? $inputs['med_id'][$key] : 0;

                    if ($medicineId > 0) {

                        $updateMedicine = [
                            'opd_master_id'  => $id,
                            'medicine_id'  => $mMedicine,
                            //'procedure_date'  => currentDate(true),
                            'medicine_days'  => $medicine_days,
                            'dose'  => $mDose,
                            'dose_unit'  => $mUnit,
                            'timing'  => $mTiming,
                            'remarks'  => $mRemarks,
                        ];

                        (new OralMedicationMaster)->store($updateMedicine, $medicineId);


                    } else {

                        $saveMedicines[] = [
                            'opd_master_id'  => $id,
                            'medicine_id'  => $mMedicine,
                            'procedure_date'  => currentDate(true),
                            'medicine_days'  => $medicine_days,
                            'dose'  => $mDose,
                            'dose_unit'  => $mUnit,
                            'timing'  => $mTiming,
                            'remarks'  => $mRemarks,
                        ];

                    }
                }

                $oldMedicines = [];
                $mMedicines = (new OralMedicationMaster)->getOPDOralMedicines(['opd_id' => $id]);
                if (is_object($mMedicines)) {
                    $oldMedicines = array_column($mMedicines->toArray(), 'id');
                }

                if(count($saveMedicines) > 0) {
                    (new OralMedicationMaster)->store($saveMedicines, null, true);
                }
                
                $newMedicines = (isset($inputs['med_id']) && count($inputs['med_id']) > 0) ? $inputs['med_id'] : [];

                $deletedMedicines = array_diff($oldMedicines, $newMedicines);
                if (count($deletedMedicines) > 0) {
                    (new OralMedicationMaster)->dropMedicines($deletedMedicines);
                }
            }
            else
            {

                $oldMedicines = [];
                $mMedicines = (new OralMedicationMaster)->getOPDOralMedicines(['opd_id' => $id]);
                if (is_object($mMedicines)) {
                    $oldMedicines = array_column($mMedicines->toArray(), 'id');
                }
                if (count($oldMedicines) > 0) {
                    (new OralMedicationMaster)->dropMedicines($oldMedicines);
                }

            }

            \DB::commit();
            if(isDoctor())
                $route = route('home');
            else
                $route   = route('patient.opd-list');
            
            $message = lang('messages.updated', lang('opd_master.opd_visit'));
            return validationResponse(true, 201, $message, $route);
        } catch (\Exception $e) {
            \DB::rollBack();
            return validationResponse(false, 207, lang('messages.server_error'));
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function drop($id)
    {
        if (!\Request::ajax()) {
            return lang('messages.server_error');
        }

        $result = (new OPDMaster)->getOPDVisitDetail($id);
        if(!is_object($result)) {
            return abort(404);
        }

        if (isDoctor() && $result->doctor_id != authUser()->doctor_id) {
            return redirect()->back()->with("error", "Permission denied to access this visit.");
        }

        try
        {
            (new OPDMaster)->drop($id);
            $response = ['status' => 1, 'message' => lang('messages.deleted', lang('opd_master.opd_visit'))];

        } catch (\Exception $exception) {
            $response = ['status' => 0, 'message' => lang('messages.server_error')];
        }
        return json_encode($response);
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function listOPD()
    {
        if (\Request::isMethod('post') && \Request::ajax())
        {
            $inputs = \Input::all();
            $page = 1;
            if(isDoctor())
            {
                $inputs['doctor_id'] = authUser()->doctor_id;
            }
            if (isset($inputs['page']) && (int)$inputs['page'] > 0) {
                $page = $inputs['page'];
            }

            $perPage = 20;
            if (isset($inputs['perpage']) && (int)$inputs['perpage'] > 0) {
                $perPage = $inputs['perpage'];
            }

            $start = ($page - 1) * $perPage;

            if (isset($inputs['form-search']) && $inputs['form-search'] != '') {
                $inputs = array_filter($inputs);
                unset($inputs['_token']);

                $data = (new OPDMaster)->getVisits($inputs, $start, $perPage);
                $totalRst = (new OPDMaster)->totalOPDVisits($inputs);
                $total = $totalRst->total;
            } else {

                $data = (new OPDMaster)->getVisits($inputs, $start, $perPage);
                $totalRst = (new OPDMaster)->totalOPDVisits($inputs);
                $total = $totalRst->total;
            }
            return view('admin.opd_visits.load_data', compact('data', 'total', 'page', 'perPage'));
        }
        return view('admin.opd_visits.index');
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function listDoctorOPD()
    {
        if (\Request::isMethod('post') && \Request::ajax())
        {
            $inputs = \Input::all();
            $page = 1;
            if (isset($inputs['page']) && (int)$inputs['page'] > 0) {
                $page = $inputs['page'];
            }

            $perPage = 20;
            if (isset($inputs['perpage']) && (int)$inputs['perpage'] > 0) {
                $perPage = $inputs['perpage'];
            }

            $inputs['doctor_id'] = authUser()->doctor_id;

            $start = ($page - 1) * $perPage;
            if (isset($inputs['form-search']) && $inputs['form-search'] != '') {
                $inputs = array_filter($inputs);
                unset($inputs['_token']);

                $data = (new OPDMaster)->getVisits($inputs, $start, $perPage);
                $totalRst = (new OPDMaster)->totalOPDVisits($inputs);
                $total = $totalRst->total;
            } else {

                $data = (new OPDMaster)->getVisits($inputs, $start, $perPage);
                $totalRst = (new OPDMaster)->totalOPDVisits($inputs);
                $total = $totalRst->total;
            }
            return view('admin.opd_visits.load_data', compact('data', 'total', 'page', 'perPage'));
        }
        return view('admin.opd_visits.index');
    }

    /**
     * @param null $opdId
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|string
     */
    public function referPatient($opdId = null)
    {
        $result = (new OPDMaster)->getOPDVisitDetail($opdId);
        if(!is_object($result)) {
            return "Error: Invalid visit.";
        }

        $inputs = \Input::all();
        if(count($inputs) > 0)
        {

            $patientId = $result->patient_id;
            $doctorId = $result->doctor_id;
            $newDocId = $inputs['doctor'];
            $deptId = $inputs['department'];

            $lastOPDId = (new OPDMaster)->getLastOPDNumber();

            $save = [
                'opd_number'  => date('Ym') . $lastOPDId,
                'patient_id' => $patientId,
                'doctor_id' => $newDocId,
                'department_id' => $deptId,
                'referred_by' => $doctorId,
                'is_referred' => 1,
                'visit_date' => currentDate(true),
                'created_by'  => authUserId(),
                'is_completed'  => 0,
                'flag' => $result->flag
            ];

            (new OPDMaster)->store($save);
            (new OPDMaster)->store(['is_completed' => 1], $result->id);

            if(isDoctor()) {
                return redirect()->route('dashboard');
            } else {
                return redirect()->route('patient.opd-list');
            }
        }

        $doctors = (new Doctor)->getDoctorList();
        $departments = (new Department)->getDepartmentService();
        return view('admin.opd_visits.refer_patient', compact('result', 'doctors', 'departments'));
    }

    /**
     * @param null $pId
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function viewPatientOPDVisits($pId = null)
    {
        $previousVisits = (new OPDMaster)->getPatientVisits($pId);
        return view('admin.opd_visits.patient_visits', compact('previousVisits'));
    }

    /**
     * Display a listing of the resource.
     *
     * @param null $id
     * @param null $pid
     * @return \Illuminate\Http\Response
     */
    public function addProcedureEntry($id = null, $pid = null)
    {
        $result = (new OPDMaster)->getOPDVisitDetail($id);
        if(!is_object($result)) {
            return abort(404);
        }
        $inputs = \Input::all();

        if(count($inputs) > 0)
        {   
            if (!isset($inputs['add_procedure'])) {
                return validationResponse(false, 207, "Please select atleast one procedure to add.");
            }
            $validator = (new DailyProcedureVisits)->validateAddProcedureVisit($inputs);
            if ($validator->fails()) {
                return validationResponse(false, 206, "", "", $validator->messages());
            }

            $procedureId = $inputs['pid'];
            $patient_id = $inputs['patient_id'];
            $department_id = $inputs['department_id'];
            $doctor_id = $inputs['doctor_id'];
            $procedure_held_date = dateFormat("Y-m-d", $inputs['procedure_held_date']);

            
            $save = [];
            foreach ($inputs['add_procedure'] as $key => $value)
            {
                $pm = explode("##", $key);
                $procedure_id = $pm[0];
                $procedure_medicine_id = $pm[1];
                $procedureRemark = $inputs['procedure_remark'][$key];

                if ($procedureId < 1)
                {
                    $save[] = [
                        'type' => 1,
                        'opd_master_id' => $id,
                        'patient_id'    => $patient_id,
                        'doctor_id' => $doctor_id, 
                        'department_id' => $department_id,
                        'procedure_id' => $procedure_id,
                        'procedure_medicine_id' => $procedure_medicine_id,
                        'procedure_held_date' => $procedure_held_date,
                        'remarks' => $procedureRemark,
                        'created_at' => currentDate(true),
                        'updated_at' => currentDate(true),
                        'created_by' => authUserId(),
                        'updated_by' => authUserId(),
                    ];
                    
                } else {

                    $update = [
                        'remarks' => $procedureRemark,
                    ];
                    (new DailyProcedureVisits)->store($update, $procedureId);
                }

            }
            //dd($save);
            if (count($save) > 0) {
                (new DailyProcedureVisits)->store($save, '', true);
            }

            $htmlcode = "<!DOCTYPE html><html><head><title></title></head><body onload='window.close()'></body></html>";
            return $htmlcode;
            //return validationResponse(true, 201, "Procedure entry successfully saved.",route('patient.opd-procedure-list'));
        }
        $procedure = (new DailyProcedureVisits)->where('id', $pid)->first();
        $pMedicines = (new ProcedureTreatmentMaster)->getOPDProcedureTreatments(['opd_id' => $id]);
        return view('admin.opd_visits.add_procedure_entry', compact('result', 'procedure', 'pMedicines'));
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function listProcedureEntry()
    {

        if (\Request::isMethod('post') && \Request::ajax())
        {
            $inputs = \Input::all();
            $page = 1;
            if(isset($inputs['summaryonly']))
               $summaryonly = 1;
           else
                $summaryonly = 0;
            if (isset($inputs['page']) && (int)$inputs['page'] > 0) {
                $page = $inputs['page'];
            }

            $perPage = 20;
            if (isset($inputs['perpage']) && (int)$inputs['perpage'] > 0) {
                $perPage = $inputs['perpage'];
            }
            if(isset($inputs['p_type']) && !empty($inputs['p_type']))
                $p_type = $inputs['p_type'];
            $start = ($page - 1) * $perPage;
            if (isset($inputs['form-search']) && $inputs['form-search'] != '') {
                $inputs = array_filter($inputs);
                unset($inputs['_token']);

                
                $data = (new DailyProcedureVisits)->getProcedureVisits($inputs, $start, $perPage);
                
                $summary = (new DailyProcedureVisits)->getProcedureVisitsByDepartment($inputs, $start, $perPage);
                $psummary = (new DailyProcedureVisits)->getProcedureVisitsByProcedure($inputs, $start, $perPage);
                $totalRst = (new DailyProcedureVisits)->totalProcedureVisits($inputs);
                $total = $totalRst->total;
            } else {

                // $data = (new DailyProcedureVisits)->getProcedureVisits($inputs, $start, $perPage);
                // $summary = (new DailyProcedureVisits)->getProcedureVisitsByDepartment($inputs, $start, $perPage);
                // $psummary = (new DailyProcedureVisits)->getProcedureVisitsByProcedure($inputs, $start, $perPage);
                // $totalRst = (new DailyProcedureVisits)->totalProcedureVisits($inputs);
                // $total = $totalRst->total;
                $data = $summary = $psummary = $totalRst = $total = array();                
            }
            return view('admin.opd_visits.procedure_entry_load_data', compact('data','summary', 'psummary','total', 'page', 'perPage','p_type','summaryonly'));
        }

        $departments = (new Department)->getDepartmentService();
        return view('admin.opd_visits.list_procedure_entry',compact('departments'));
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function dropProcedureEntry($id)
    {
        if (!\Request::ajax()) {
            return lang('messages.server_error');
        }

        $result = (new DailyProcedureVisits)->where('id', $id)->first();
        if(!is_object($result)) {
            return abort(404);
        }
        
        try
        {
            (new DailyProcedureVisits)->drop($id);
            $response = ['status' => 1, 'message' => lang('messages.deleted', lang('opd_master.patient_procedures'))];

        } catch (\Exception $exception) {
            $response = ['status' => 0, 'message' => lang('messages.server_error')];
        }
        return json_encode($response);
    }





}
