<?php
namespace App;
/**
 * :: IPD Procedure Treatment Model ::
 * To manage IPD Procedure Treatment CRUD operations
 *
 **/

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Response;

class IPDProcedureTreatments extends Model
{
    use SoftDeletes;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'ipd_procedure_treatments';

    /**
     * The attributes that are mass assignable.
     * @var array
     */
    protected $fillable = [
        'ipd_master_id',
        'procedure_id',
        'procedure_date',
        'procedure_medicine_id',
        'dose',
        'dose_unit',
        'timing',
        'procedure_days',        
        'remarks',
        'is_active',
        'deleted_by',
    ];

    public $timestamps = false;

    /**
     * Method is used to save/update resource.
     *
     * @param   array $input
     * @param   int $id
     * @param bool $multiple
     * @return Response
     */
    public function store($input, $id = null, $multiple = false)
    {
        if ($id) {
            return $this->find($id)->update($input);
        } else {
            if($multiple) {
                return $this->insert($input);
            }
            return $this->create($input)->id;
        }
    }

    /**
     * Method is used to search news detail.
     *
     * @param array $search
     * @return mixed
     */
    public function getIPDProcedureTreatments($search = [])
    {
        $filter = 1; // default filter if no search

        $fields = [
            'ipd_procedure_treatments.*',
            'procedure_master.name as procedure',
            'product.product_name as medicine',
        ];

        //$orderEntity = 'ipd_procedure_treatments.id';
        $orderEntity = 'ipd_procedure_treatments.procedure_date';
        $orderAction = 'desc';

        if (is_array($search) && count($search) > 0)
        {
            
            $filter .= (array_key_exists('ipd_id', $search) && $search['ipd_id'] != "") ?
                " AND (ipd_procedure_treatments.ipd_master_id = " . addslashes(trim($search['ipd_id'])) . ")" : "";
        }
        return $this->leftJoin('procedure_master', 'procedure_master.id', 'ipd_procedure_treatments.procedure_id')
            ->leftJoin('product', 'product.id', 'ipd_procedure_treatments.procedure_medicine_id')
            ->whereRaw($filter)
            ->orderBy($orderEntity, $orderAction)
            ->get($fields);
    }

    public function getLastIPDProcedureTreatments($search = [])
    {
        $filter = 1; // default filter if no search

        $fields = [
            'ipd_procedure_treatments.*',
            'procedure_master.name as procedure',
            'product.product_name as medicine',
        ];

        //$orderEntity = 'ipd_procedure_treatments.id';
        $orderEntity = 'ipd_procedure_treatments.procedure_date';
        $orderAction = 'desc';


        if (is_array($search) && count($search) > 0)
        {
            $filter .= (array_key_exists('ipd_id', $search) && $search['ipd_id'] != "") ?
                " AND (ipd_procedure_treatments.ipd_master_id = " . addslashes(trim($search['ipd_id'])) . ")" : "";
        }

        $lastVisitDate =    $this->select('procedure_date')
                                ->whereRaw($filter)
                                ->orderBy('procedure_date','desc')
                                ->first();
        if(count($lastVisitDate)>0) {
        
        $start = dateFormat('Y-m-d',$lastVisitDate->procedure_date) . ' 00:00';
        $end = dateFormat('Y-m-d',$lastVisitDate->procedure_date) . ' 23:59';

        $filter .= " AND (procedure_date between '$start' and '$end')";


        }

        // dd($this->leftJoin('procedure_master', 'procedure_master.id', 'ipd_procedure_treatments.procedure_id')
        //     ->leftJoin('product', 'product.id', 'ipd_procedure_treatments.procedure_medicine_id')
        //     ->whereRaw($filter)
        //     ->orderBy($orderEntity, $orderAction)
        //     ->toSql());

        return $this->leftJoin('procedure_master', 'procedure_master.id', 'ipd_procedure_treatments.procedure_id')
            ->leftJoin('product', 'product.id', 'ipd_procedure_treatments.procedure_medicine_id')
            ->whereRaw($filter)
            ->orderBy($orderEntity, $orderAction)
            ->get($fields);
    }


    /**
     * @param $pIds
     * @return bool
     */
    public function dropProcedures($pIds)
    {
        return $this->whereIn('id', $pIds)->update(['deleted_by' => authUserId(), 'deleted_at' => currentDate(true)]);
    }
}