<?php
namespace App;
/**
 * :: OT Type Model ::
 * To manage OT Type CRUD operations
 *
 **/

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Procedures extends Model
{
    use SoftDeletes;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'procedure_master';

    /**
     * The attributes that are mass assignable.
     * @var array
     */
    protected $fillable = [
        'name',
        'code',
        'is_sub_procedure',
        'procedure_type',
        'main_procedure_id',
        'description',
        'company_id',
        'status',
        'deleted_at',
        'deleted_by',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    /**
     * Scope a query to only include active users.
     *
     * @param $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query)
    {
        return $query->where('status', 1);
    }

    /**
     * @param type $query
     * @return type
     */
    public function scopeCompany($query)
    {
        return $query->where('company_id', loggedInHospitalId());
    }

    /**
     * Method is used to validate roles
     * @param $inputs
     * @param int $id
     * @return Response
     */
    public function validateProcedure($inputs, $id = null)
    {
        // validation rule
        if ($id) {
            $rules['name'] = 'required|unique:procedure_master,name,' . $id .',id,deleted_at,NULL,company_id,'.loggedInHospitalId();
            $rules['code'] = 'required|unique:procedure_master,code,' . $id .',id,deleted_at,NULL,company_id,'.loggedInHospitalId();
        } else {
            $rules['name'] = 'required|unique:procedure_master,name,NULL,id,deleted_at,NULL,company_id,'.loggedInHospitalId();
            $rules['code'] = 'required|unique:procedure_master,code,NULL,id,deleted_at,NULL,company_id,'.loggedInHospitalId();
        }

        if($inputs['is_sub_procedure'] == 1) {
            $rules['main_procedure'] = 'required';
        }

        return \Validator::make($inputs, $rules);
    }

    /**
     * @param $inputs
     * @return \Illuminate\Validation\Validator
     */
    public function validateProcedureExcel($inputs)
    {
        $rules = [
            'file' => 'required',
        ];
        return \Validator::make($inputs, $rules);
    }
    
    /**
     * Method is used to save/update resource.
     *
     * @param   array $input
     * @param   int $id
     * @return  Response
     */
    public function store($input, $id = null)
    {
        if ($id) {
            return $this->find($id)->update($input);
        } else {
            return $this->create($input)->id;
        }
    }

    /**
     * Method is used to search news detail.
     *
     * @param array $search
     * @param int $skip
     * @param int $perPage
     * @return mixed
     */
    public function getProcedures($search = null, $skip, $perPage)
    {
        $take = ((int)$perPage > 0) ? $perPage : 20;
        $filter = 1; // default filter if no search

        $fields = [
            'id',
            'name',
            'code',
            'description',
            'status',
        ];

        $orderEntity = 'id';
        $orderAction = 'desc';

        if (is_array($search) && count($search) > 0)
        {
            $filter .= (array_key_exists('keyword', $search))?
                " AND (name LIKE '%".addslashes(trim($search['keyword'])).
                "%' OR code LIKE '%".addslashes(trim($search['keyword']))."%')"
                : "";
        }

        return $this->whereRaw($filter)->company()
            ->orderBy($orderEntity, $orderAction)
            ->skip($skip)->take($take)->get($fields);
    }

    /**
     * Method is used to get total results.
     * @param array $search
     * @return mixed
     */
    public function totalProcedures($search = null)
    {
        $filter = 1; // if no search add where

        // when search
        if (is_array($search) && count($search) > 0)
        {
            $filter .= (array_key_exists('keyword', $search)) ? " AND name LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' " : "";
        }
        return $this->select(\DB::raw('count(*) as total'))
            ->whereRaw($filter)
            ->company()
            ->first();
    }

    /**
     * @param array $search
     * @return mixed
     */
    public function getProcedureService($search = [])
    {
        $filter = 1;
        if (is_array($search) && count($search) > 0)
        {
            $filter .= (array_key_exists('main_only', $search)) ? " AND is_sub_procedure = 0 " : "";

            $filter .= (array_key_exists('sub_only', $search)) ? " AND is_sub_procedure = 1 " : "";
        }
        $data = $this->active()->whereRaw($filter)->company()
            ->orderBy('name','ASC')
            ->get([\DB::raw("concat(name, ' (', IFNULL(code,'-')) as name"), 'id']);
        $result = [];
        foreach($data as $detail) {
            $result[$detail->id] = $detail->name . ')';

        }
        return ['' =>'-Select Procedure-'] + $result;
    }

    /**
     * @param $id
     */
    public function drop($id)
    {
        $this->find($id)->update([ 'deleted_by' => authUserId(), 'deleted_at' =>convertToUtc() ]);
    }

    /**
     * @param $id
     * @return bool
     */
    public function procedureExists($id)
    {
        $unitExistsInProduct = (new Product)->company()->where('unit_id', $id)->first();
        if(count($unitExistsInProduct) > 0) {
            return true;
        }
    }

    /**
     * Method is used to find Unit ID.
     * @param string $search
     * @return id
     */
    public function findProcedureID($search = '')
    {
        if ($search != '') {
            $filter = "code = '" . $search . "' ";
            return $this->select('procedure_master.id as procedure_master_id')
                ->whereRaw($filter)
                ->company()
                ->first();
        }
        return null;
    }
}