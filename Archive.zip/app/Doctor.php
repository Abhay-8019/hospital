<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Doctor extends Model
{
    use SoftDeletes;

    /**
     * database table use in phpmyadmin
     */

    protected $table = 'doctor';

    /**
     * fields of doctor table
     */

    protected $fillable=[
        'specialization_id',
        'hospital_id',
        'department_id',
        'designation_id',
        'room_id',
        'name',
        'registration_no',
        'association',
        'specifyassociation',
        'email',
        'gender',
        'date_of_birth',
        'blood_group',
        'marital_status',
        'city',
        'state',
        'country',
        'zipcode',
        'qualification',
        'joining_date',
        'address',
        'contact',
        'duty_type',
        'image',
        'in_time',
        'eve_in_time',
        'out_time',
        'eve_out_time',
        'days',
        'status',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    public function scopeDoctorHospital($query)
    {
        return (!isSuperAdmin())?
            $query->where('doctor.hospital_id', loggedInHospitalId()) : null;
    }

    public function scopeActive($query)
    {
        return $query->where(['status' => '1']);
    }
    /**
     * @param $input
     * @param null $id
     * @return bool|mixed
     */
    public function store($input, $id = null)
    {
        if ($id) {
            return $this->find($id)->update($input);
        } else {
            return $this->create($input)->id;
        }
    }

    public function validateDoctor($inputs, $id=null)
    {
        $inputs = array_filter($inputs);
        $rules = [
            'name'          => 'required',
            'association'   => 'required',
            'consultation_fee' => 'required|numeric',
        ];

        if ($id) {
            $rules += [
                'registration_no'       =>  'required|unique:doctor,registration_no,' . $id .',id,deleted_at,NULL,hospital_id,'.loggedInHospitalId(),
                'email'                 =>  'unique:doctor,email,' . $id .',id,deleted_at,NULL,hospital_id,'.loggedInHospitalId(),
            ];

        } else {
            $rules += [
                'registration_no'       =>  'required|unique:doctor,registration_no,NULL,id,deleted_at,NULL,hospital_id,'.loggedInHospitalId(),
                'email'                 =>  'required|email|unique:doctor,email,NULL,id,deleted_at,NULL,hospital_id,'.loggedInHospitalId(),
                'status'                =>  'required',
            ];
        }

       /* if(isset($inputs['image'])&&($inputs['image'])!= ''){
            $rules['image'] = 'image|mime:jpeg,png,gif,jpg|max:1000';
        }*/

        $rules +=  [
            //'date_of_birth'          => 'required|date|before:18 years ago',
            'address'                => 'required',
            'designation_id'         => 'required',
            'specialization_id'      => 'required',
            'department_id'          => 'required',
            'gender'                 => 'required',
            //'joining_date'           => 'required|date',
            'contact'                => 'required|numeric|digits_between:10,10',
        ];

        $messages = [
            'designation_id.required' => 'The designation field is required.',
            'specialization_id.required' => 'The specialization field is required.',
            'department_id.required' => 'The department field is required.',
            'contact.digits_between' => 'The contact must be 10 digits.'
        ];

        return \Validator::make($inputs, $rules, $messages);
    }

    public function getDoctor($search = null, $skip, $perPage)
    {
        $take = ((int)$perPage > 0) ? $perPage : 20;
        // default filter if no search
        $filter = 1;

        $fields = [
            'doctor.id',
            'doctor.name',
            'doctor.specialization_id',
            'doctor.contact',
            'doctor.duty_type',
            'doctor.department_id',
            'doctor.image',
            'doctor.status',
            'specialization.name as specialization_name',
            'department.name as department_name',
            'doctor_fee.consultation_fee'
        ];

        if (is_array($search) && count($search) > 0) {
            $partyName = (array_key_exists('keyword', $search)) ? " AND doctor.name LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' " : "";
            $filter .= $partyName;
        }

        return $this->leftJoin('doctor_fee','doctor_fee.doctor_id', '=', \DB::Raw('doctor.id and is_active = 1'))
            ->leftJoin('specialization','specialization.id', '=','doctor.specialization_id')
            ->leftJoin('department','department.id', '=','doctor.department_id')
            ->whereRaw($filter)
            ->where('doctor.hospital_id', loggedInHospitalId())
            ->orderBy('id','ASC')
            ->skip($skip)->take($take)->get($fields);
    }

    /**
     * @param null $search
     * @return Model|null|static
     */
    public function totalDoctor($search = null)
    {
        $filter = 1; // if no search add where

        // when search
        if (is_array($search) && count($search) > 0) {
            $partyName = (array_key_exists('name', $search)) ? " AND doctor.name LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' " : "";
            $filter .= $partyName;
        }
        return $this->select(\DB::raw('count(*) as total'))
            ->whereRaw($filter)->first();
    }
    /**
     * @return array
     */
    public function getDoctorList()
    {
        $result = $this->active()
            ->doctorHospital()
            ->pluck('name', 'id')->toArray();
        return ['' => '-Select Doctor-'] + $result;
    }

    /**
     * @param null $code
     * @return mixed|string
     */
    public function getDoctorCode($code = null)
    {
        $result =  $this->active()->doctorHospital()->where('registration_no', $code)->first();
        if ($result) {
            $data =  $this->active()->doctorHospital()->orderBy('id', 'desc')->take(1)->first(['registration_no']);
        } else {
            $data =  $this->active()->doctorHospital()->orderBy('id', 'desc')->take(1)->first(['registration_no']);
        }

        if (count($data) == 0) {
            $number = 'D-01';
        } else {
            $number = number_inc($data->registration_no); // new code increment by 1
        }
        return $number;
    }
}
