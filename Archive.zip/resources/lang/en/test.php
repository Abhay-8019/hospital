<?php

return [
    'test'                  => 'Test',
    'test_detail'           => 'Test Detail',
    'tests'                 => 'Tests',
    'test_list'             => 'Test List',
    'testrange'             => 'Test Range',
    'min_value'             => 'Minimum Value',
    'max_value'             => 'Maximum Value',
    'test_cost'             => 'Cost of Test',
    'description'           => 'Description',
    'test_result'           => 'Test Result',
    'test_result_detail'    => 'Result Test Detail',
    'test_result_list'      => 'Result Test List',
    'patient'               => 'Patient Name',
    'test_name'             => 'Test Name',
    'add_test'              => 'Add Test',
    'add_tests'              => 'Add Tests',

];