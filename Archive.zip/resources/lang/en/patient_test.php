<?php 
/**
 * :: Patient Test Language File ::
 * To manage patient related language phrases.
 *
 * @package LabTech
 **/

return [

	'patient_test_detail'	=> 'Patient Test Detail',
	'patient_test'			=> 'Patient Test',
	'patient_tests'			=> 'Patient Tests',
	'patient_test_list'		=> 'Patient Tests List',
	'name'					=> 'Patient Name',
	'rcpt'					=> 'S-',
	'test_date'				=> 'Test Date',
	'deliver_date'			=> 'Test Deliver Date',
	'receipt_no'			=> 'Receipt No',
	'amount'				=> 'Amount',
	'patient_name'			=> 'Patient Name',
	'patient_age'			=> 'Patient Age',
	'test_action'			=> 'Patient Test Action',
	'generate_report'		=> 'Generate Test Report',
	'report_detail'			=> 'Report Detail',
	'report'				=> 'Report',
	'gen_report'			=> 'Generate Report',
	'patient_test_summary'	=> 'Patient Test Summary',

];