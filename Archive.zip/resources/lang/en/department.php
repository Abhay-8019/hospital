<?php 
/**
 * :: Department Language File :: 
 * To manage department related language phrases.
 *
 **/

return [

    'department_detail'     => 'Department Detail',
    'department'			=> 'Department',
    'departments'			=> 'Departments',
    'department_status'		=> 'Department Status',
    'departments_list'		=> 'Departments List',
    'floor_name'			=> 'Floor Name',
    'head_name'			    => 'Head Name',
    'address'			    => 'Address',
    'head_contact'			=> 'Contact Number',

];