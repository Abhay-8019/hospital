<?php 
/**
 * :: Test Category Language File :: 
 * To manage test_category related language phrases.
 *
 **/

return [

	'test_category_detail'		=> 'Test Category Detail',
	'test_category'				=> 'Test Category',
	'test_categories'			=> 'Test Categories',
	'test_category_status'		=> 'Test Category Status',
	'test_categories_list'		=> 'Test Categories List',
    'test_category_in_use'     	=> 'Test Category already in use',
	'add_test_category'			=> 'Add Test Category',
	'sub_tests'					=> 'Sub Tests'
];