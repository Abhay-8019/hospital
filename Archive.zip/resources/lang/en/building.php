<?php 
/**
 * :: building Language File ::
 * To manage roles related language phrases.
 *
 **/

return [

	'building_detail'         => 'Building Detail',
	'building'				  => 'Building',
	'buildinges'			  => 'Buildinges',
	'building_status'		  => 'Building Status',
	'building_list'			  => 'Building List',
	'building_code'			  => 'Building Code',
	'building_location'		  => 'Building Location',
	'no_of_floors'		      => 'Number Of Floors',
	'add_heading'			  => 'Add Floor',

];