<?php

return [

    'category_detail'           => 'Category Detail',
    'category'				    => 'Category',
    'categories'				=> 'Categories',
    'vendor_name'               => 'Vendor Name',
    'category_status'			=> 'Category Status',
    'category_list'			    => 'Category List',
    'category_code'			    => 'Category Code',

];