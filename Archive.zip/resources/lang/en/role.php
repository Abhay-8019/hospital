<?php 
/**
 * :: Role Language File :: 
 * To manage roles related language phrases.
 *
 **/

return [

	'role_detail'           => 'Role Detail',
	'role'					=> 'Role',
	'roles'					=> 'Roles',
	'role_status'			=> 'Role Status',
	'roles_list'			=> 'Roles List',
	'permission'			=> 'Permission',

];