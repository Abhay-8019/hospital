<?php

/**
 * :: Specialization Language File ::
 * To manage roles related language phrases.
 *
 **/

return [

    'specialization_detail'         => 'Specialization Detail',
    'specialization'				=> 'Specialization',
    'specializations'				=> 'Specializations',
    'specialization_list'			=> 'Specialization List',

];