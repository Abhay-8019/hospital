@extends('layouts.admin')

@section('content_header')
	<section class="content-header">
		<div class="pull-right">
			<a class="btn btn-danger btn-xs" href="{!! route('patient-registration.create') !!}">
				<i class="fa fa-plus-circle"></i> {!! lang('common.create_heading', lang('patient.opd_patient')) !!}
			</a>
		</div>
		<h1>
			{!! lang('patient.opd_patients') !!}
			<small>{!! lang('common.list_record') !!}</small>
		</h1>
	</section>
@stop

@section('content')
<div id="page-wrapper">

	{{-- for message rendering --}}
    @include('layouts.messages')

	<div class="col-md-12 padding0">
		{!! Form::open(array('method' => 'POST', 'route' => array('patient-registration.paginate'), 'id' => 'ajaxForm')) !!}
		<div class="row">

			<div class="col-md-2 width150">
				<div class="form-group">
					{!! Form::label('patient_code', lang('patient.patient_code'), array('class' => 'control-label')) !!}
					{!! Form::text('patient_code', null, array('class' => 'form-control', 'placeholder' => lang('patient.patient_code'))) !!}
				</div>
			</div>

			<div class="col-md-2 paddingleft0">
				<div class="form-group">
					{!! Form::label('patient_name', lang('patient.first_name'), array('class' => 'control-label')) !!}
					{!! Form::text('patient_name', null, array('class' => 'form-control', 'placeholder' => lang('patient.first_name'))) !!}
				</div>
			</div>

			<div class="col-md-2 width150 paddingleft0">
				<div class="form-group">
					{!! Form::label('mobile', lang('patient.mobile'), array('class' => 'control-label')) !!}
					{!! Form::text('mobile', null, array('class' => 'form-control', 'placeholder' =>  lang('patient.mobile'))) !!}
				</div>
			</div>

			<div class="col-md-3 paddingleft0">
				<div class="form-group">
					{!! Form::label('address', lang('patient.address'), array('class' => 'control-label')) !!}
					{!! Form::text('address', null, array('class' => 'form-control', 'placeholder' =>  lang('patient.address'))) !!}
				</div>
			</div>

			<div class="col-sm-3 margintop20">
				<div class="form-group">
					{!! Form::hidden('form-search', 1) !!}
					{!! Form::submit(lang('reports.filter'), array('class' => 'btn btn-primary', 'title' => lang('reports.filter'))) !!}
					<a href="{!! route('patient-registration.index') !!}" class="btn btn-primary" title="{!! lang('reports.reset_filter') !!}"> {!! lang('reports.reset_filter') !!}</a>
				</div>
			</div>
		</div>
		{!! Form::close() !!}
	</div>

    <div class="row">
      <div class="col-md-12">
		<!-- start: BASIC TABLE PANEL -->
		<div class="panel panel-default" style="position: static;">
			<div class="panel-heading">
				<i class="fa fa-external-link-square"></i> &nbsp;
				{!! lang('patient.patients_list') !!}
			</div>
			<div class="panel-body">
				<div class="col-md-3 text-right pull-right padding0 marginbottom10">
					{!! lang('common.per_page') !!}: {!! Form::select('name', ['20' => '20', '40' => '40', '100' => '100', '200' => '200', '300' => '300'], '20', ['id' => 'per-page']) !!}
				</div>
				<div class="col-md-3 padding0 marginbottom10">
					{!! Form::hidden('page', 'search') !!}
					{!! Form::hidden('_token', csrf_token()) !!}
					{!! Form::text('name', null, array('class' => 'form-control live-search', 'placeholder' => 'Search Patient')) !!}
				</div>
				<table id="paginate-load" data-route="{{ route('patient-registration.paginate') }}" class="table table-hover clearfix margin0 col-md-12 padding0">
				</table>
			</div>
		</div>
		<!-- end: BASIC TABLE PANEL -->
	   </div>	
	</div>	
</div>
<!-- /#page-wrapper -->
@stop
