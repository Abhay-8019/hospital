@extends('layouts.admin')
@section('content')
<div id="page-wrapper">
	{{-- for message rendering --}}
    @include('layouts.messages')

    <div class="row">
      <div class="col-md-12">
		<!-- start: BASIC TABLE PANEL -->
		<div class="panel panel-default" style="position: static;">
			<div class="panel-heading">
				<i class="fa fa-external-link-square"></i> &nbsp;
				{!! lang('patient.ipd_slip') !!}
			</div>
			<div class="panel-body text-center">
				<h1>
					Coming Soon
				</h1>
			</div>
		</div>
		<!-- end: BASIC TABLE PANEL -->
	   </div>	
	</div>	
</div>
<!-- /#page-wrapper -->
@stop
