@extends('layouts.admin')
@section('content_header')
<section class="content-header">
    <h1>
        {!! lang('ipd_master.ipd_visit') !!}
        <small>{!! lang('common.view_heading', " Discharge Detail") !!}</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> {!! lang('common.back') !!}</a></li>
        <li class="active">{!! lang('ipd_master.ipd_visit') !!}</li>
    </ol>
</section>
@stop
@section('content')
<div id="page-wrapper">
    <!-- start: PAGE CONTENT -->
    
    {{-- for message rendering --}}
    @include('layouts.messages')
    <div class="row">
        <div class="col-md-12 padding0">
            <!-- previous patient form id => patient-form -->
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading padding0">
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active">
                                <a href="#personal_tab" aria-controls="personal_tab" role="tab" data-toggle="tab">

                                    <i class="fa fa-external-link-square"></i>
                                    {!! lang('ipd_master.ipd_visit_detail') !!}
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <div class="row">

                            <div class="tab-content" id="p-report">
                                {!! Form::open(array('method' => 'POST', 'route' => array('patient.ipd-discharge', $result->id), 'id' => 'ajaxSave', 'class' => 'form-horizontal')) !!}
                                    <div id="personal_tab" class="tab-pane fade in active">
                                        <?php
                                            $genderArr = lang('common.genderArray');
                                            $bloodGroupArr = lang('common.bloodGroupArr');
                                        ?>
                                        <div class="col-md-12">
                                            <h1 class="h-size">
                                                Patient Detail
                                            </h1>
                                            <hr/>
                                            <table class="table table-bordered">
                                                <tr>
                                                    <td width="15%"><b>{!! lang('patient.first_name') !!}</b></td>
                                                    <td width="18%">{!! $patient->first_name !!}</td>
                                                    <td width="15%">
                                                        <b>
                                                            {!! lang('doctor.doctor') !!}
                                                        </b>
                                                    </td>
                                                    <td width="20%">
                                                        {!! $result->doctor !!}
                                                    </td>
                                                    <td width="15%"><b>{!! lang('ipd_master.ipd_number') !!}</b></td>
                                                    <td>
                                                        {!! "IP".$result->ipd_number !!}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><b>{!! lang('patient.gender') !!}</b></td>
                                                    <td>@if($patient->gender != '') {!! $genderArr[$patient->gender] !!} @endif</td>
                                                    <td><b>{!! lang('department.department') !!}</b></td>
                                                    <td>
                                                        {!! $result->department !!}
                                                    </td>
                                                    <td><b>{!! lang('ipd_master.visit_date') !!}</b></td>
                                                    <td>
                                                        {!! dateFormat('d.m.Y', $result->admission_date) !!}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><b>{!! lang('patient.age') !!}</b></td>
                                                    <td>{!! $patient->age !!} @if($patient->age) Years @endif </td>
                                                    <td><b>{!! lang('ward.ward') !!}</b></td>
                                                    <td>
                                                        {!! $result->ward !!}
                                                    </td>
                                                    <td>
                                                        <div class="required">
                                                            {!! Form::label('doctor', lang('ipd_master.discharge_date'), array('class' => 'control-label')) !!}
                                                        </div>
                                                    </td>
                                                    <td>{!! Form::text('discharge_date', date('d-m-Y'), array('class' => 'form-control date-future')) !!}</td>
                                                </tr>
                                                <tr>
                                                    <td><b>{!! lang('patient.blood_group') !!}</b></td>
                                                    <td>{!! $patient->blood_group !!}</td>
                                                    <td><b>{!! lang('bed_master.bed_master') !!} No</b></td>
                                                    <td>
                                                        {!! $result->bed !!}
                                                    </td>
                                                    <td>
                                                        <div class="required">
                                                            {!! Form::label('doctor', lang('ipd_master.discharge_type'), array('class' => 'control-label')) !!}
                                                        </div>
                                                    </td>
                                                    <td>{!! Form::select('discharge_type', dischargeType(), null, array('class' => 'form-control select2 padding0', 'id' => 'discharge_type')) !!}</td>
                                                </tr>
                                                <tr>
                                                    <td><b>{!! lang('patient.mobile') !!}</b></td>
                                                    <td>{!! $patient->mobile !!}</td>
                                                    <td>&nbsp;</td>
                                                    <td> &nbsp;</td>
                                                    <td>
                                                        <div class="required">
                                                            {!! Form::label('doctor', lang('ipd_master.discharged_doctor'), array('class' => 'control-label')) !!}
                                                        </div>
                                                        <b></b>
                                                    </td>
                                                    <td width="20%">{!! Form::select('doctor', $doctors, null, array('class' => 'form-control select2 padding0', 'id' => 'doctor')) !!} </td>
                                                </tr>
                                            </table>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group clearfix">
                                                {!! Form::label('discharge_summary', lang('ipd_master.discharge_summary'), array('class' => 'col-sm-2 control-label')) !!}
                                                <div class="col-sm-8">
                                                    {!! Form::textarea('discharge_summary', $result->present_illness, array('class' => 'form-control', 'placeholder' => lang('ipd_master.discharge_summary'), 'size' => '4x6')) !!}
                                                </div>
                                            </div>

                                            <div class="form-group clearfix">
                                                {!! Form::label('treatment_given', lang('ipd_master.treatment_given'), array('class' => 'col-sm-2 control-label')) !!}
                                                <div class="col-sm-8">
                                                    {!! Form::textarea('treatment_given', null, array('class' => 'form-control', 'placeholder' => lang('ipd_master.treatment_given'), 'size' => '4x6')) !!}
                                                </div>
                                            </div>

                                            <div class="form-group clearfix">
                                                {!! Form::label('treatment_advised', lang('ipd_master.treatment_advised'), array('class' => 'col-sm-2 control-label')) !!}
                                                <div class="col-sm-8">
                                                    {!! Form::textarea('treatment_advised', null, array('class' => 'form-control', 'placeholder' => lang('ipd_master.treatment_advised'), 'size' => '4x6')) !!}
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-11 text-center">
                                            <div class="form-group">
                                                {!! Form::submit(lang('common.save'), array('class' => 'btn btn-primary btn-lg')) !!}
                                            </div>
                                        </div>
                                    </div>
                                {!! Form::close() !!}
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end: TEXT FIELDS PANEL -->
            </div>
        </div>    
    </div>
</div>
<!-- /#page-wrapper -->
@stop
