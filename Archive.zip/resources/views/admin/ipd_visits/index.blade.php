@extends('layouts.admin')
@section('content_header')
	<section class="content-header">
		<h1><?php $route = \Route::currentRouteName(); ?>
			{!! lang('ipd_master.ipd_visits') !!}
			<small>{!! lang('common.list_record') !!}</small>
		</h1>
	</section>
@stop

@section('content')
<div id="page-wrapper">

	{{-- for message rendering --}}
    @include('layouts.messages')
    <div class="col-md-12">
			{!! Form::open(array('method' => 'POST', 'route' => array($route), 'id' => 'ajaxForm')) !!}
			<div class="row">
				<div class="col-md-5 paddingleft0">
					<div class="form-group">
						{!! Form::label('keywords', lang('patient.name'), array('class' => 'control-label')) !!}
						{!! Form::text('keywords', null, array('class' => 'form-control','placeholder' => 'Name or Code')) !!}
					</div>
				</div>
				<div class="col-sm-3 margintop20 paddingleft0">
					<div class="form-group">
						{!! Form::hidden('form-search', 1) !!}
						{!! Form::hidden('report_type', 1) !!}
						{!! Form::submit(lang('reports.filter'), array('class' => 'btn btn-primary', 'title' => lang('reports.filter'))) !!}
						<a href="{!! route($route) !!}" class="btn btn-primary" title="{!! lang('reports.reset_filter') !!}"> {!! lang('reports.reset_filter') !!}</a>
					</div>
				</div>
			</div>
			{!! Form::close() !!}
		</div>
	<div class="row">
      <div class="col-md-12">
		<!-- start: BASIC TABLE PANEL -->
		<div class="panel panel-default" style="position: static;">
			<div class="panel-heading">
				<i class="fa fa-external-link-square"></i> &nbsp;
				{!! lang('ipd_master.list_ipd_visits') !!}
			</div>
			<div class="panel-body">
				<div class="col-md-3 text-right pull-right padding0 marginbottom10">
					{!! lang('common.per_page') !!}: {!! Form::select('name', ['20' => '20', '40' => '40', '100' => '100', '200' => '200', '300' => '300'], '20', ['id' => 'per-page']) !!}
				</div>
				<div class="col-md-3 padding0 marginbottom10">
					{!! Form::hidden('page', 'search') !!}
					{!! Form::hidden('_token', csrf_token()) !!}
					<!-- {!! Form::text('name', null, array('class' => 'form-control live-search', 'placeholder' => 'Search Patient')) !!} -->
				</div>
				<?php $route = \Route::currentRouteName(); ?>
				<table id="paginate-load" data-route="{{ route($route) }}" class="table table-hover margin0 col-md-12 padding0">
				</table>
			</div>
		</div>
		<!-- end: BASIC TABLE PANEL -->
	   </div>	
	</div>	
</div>
<!-- /#page-wrapper -->
@stop
