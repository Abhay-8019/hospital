<div class="row">
    <div class="col-md-12 padding0">
        {!! Form::open(array('method' => 'POST', 'route' => array('patient.opd-refer', $result->id), 'id' => 'ajaxSave', 'class' => 'form-horizontal')) !!}
        <div class="col-md-12">
            <h1 class="margin0">
                Refer Patient
            </h1>
            <hr/>

            <div class="form-group clearfix">
                {!! Form::label('doctor', lang('opd_master.doctor'), array('class' => 'col-sm-2 control-label')) !!}
                <div class="col-sm-6">
                    {!! Form::select('doctor', $doctors, null, array('class' => 'form-control select2 padding0')) !!}
                </div>
            </div>

            <div class="form-group clearfix">
                {!! Form::label('remarks', lang('opd_master.remarks'), array('class' => 'col-sm-2 control-label')) !!}
                <div class="col-sm-8">
                    {!! Form::textarea('refer_remarks', null, array('class' => 'form-control', 'placeholder' => lang('opd_master.remarks'), 'size' => '4x3')) !!}
                </div>
            </div>

            <div class="col-sm-11 text-center">
                <div class="form-group">
                    {!! Form::submit(lang('common.save'), array('class' => 'btn btn-primary btn-lg')) !!}
                </div>
            </div>
        </div>
        {!! Form::close() !!}
    </div>
</div>