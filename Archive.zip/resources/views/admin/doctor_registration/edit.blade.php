@extends('layouts.admin')
@section('content_header')
    <section class="content-header">
        <h1>
            {!! lang('common.edit_heading', lang('patient.patient')) !!} #{!! $result->fisrt_name !!}
            <small>{!! lang('common.record_update') !!}</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> {!! lang('common.back') !!}</a></li>
            <li><a href="{!! route('dashboard') !!}"><i class="fa fa-dashboard"></i>{!! lang('common.dashboard') !!}</a></li>
            <li><a href="{!! route('patient-registration.index') !!}">{!! lang('patient.patient') !!}</a></li>
            <li class="active">{!! lang('common.edit_heading', lang('patient.patient')) !!}</li>
        </ol>
    </section>
@stop
@section('content')
<div id="page-wrapper">
    <!-- start: PAGE CONTENT -->
    
    {{-- for message rendering --}}
    @include('layouts.messages')
    <div class="row">
        <div class="col-md-12 padding0">
            <!-- previous role form id => role-form -->
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading padding0">
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active">
                                <a href="#personal_tab" aria-controls="personal_tab" role="tab" data-toggle="tab">
                                    <i class="fa fa-external-link-square"></i>
                                    {!! lang('patient.personal_detail') !!}
                                </a>
                            </li>

                            {{--<li role="presentation" class="">
                                <a href="#additional_tab" aria-controls="additional_tab" role="tab" data-toggle="tab">
                                    <i class="fa fa-external-link-square"></i>
                                    {!! lang('patient.additional_detail') !!}
                                </a>
                            </li>--}}
                        </ul>
                    </div>
                    <div class="panel-body">
                        <div class="row">

                            <div class="tab-content">
                                <div id="personal_tab" class="tab-pane fade in active">
                                    {!! Form::model($result, array('route' => array('patient-registration.update', $result->id), 'method' => 'PATCH', 'id' => 'ajaxSave', 'class' => 'form-horizontal')) !!}

                                    <div class="col-md-4 margintop20">
                                        <div class="form-group required">
                                            {!! Form::label('patient_type', lang('patient.patient_type'), array('class' => 'col-sm-4 control-label')) !!}
                                            <div class="col-sm-8">
                                                {!! Form::select('patient_type', $patientTypeArray, null, array('class' => 'form-control select2 padding0')) !!}
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-4 clearfix">

                                        <div class="form-group required">
                                            {!! Form::label('first_name', lang('patient.first_name'), array('class' => 'col-sm-4 control-label')) !!}
                                            <div class="col-sm-8">
                                                {!! Form::text('first_name', null, array('class' => 'form-control', 'placeholder' => 'First Name')) !!}
                                            </div>
                                        </div>

                                        <div class="form-group ">
                                            {!! Form::label('email', lang('common.email'), array('class' => 'col-sm-4 control-label')) !!}
                                            <div class="col-sm-8">
                                                {!! Form::text('email', null, array('class' => 'form-control', 'placeholder' => 'Email : example@mail.com')) !!}
                                            </div>
                                        </div>

                                        <div class="form-group required">
                                            {!! Form::label('mobile', lang('common.mobile'), array('class' => 'col-sm-4 control-label')) !!}
                                            <div class="col-sm-8">
                                                <div class="input-group">
                                                    <span class="input-group-addon">{!! lang('common.isd_code_india') !!}</span>
                                                    {!! Form::text('mobile', null, array('class' => 'form-control', 'maxlength' => 10, 'placeholder' => 'Mobile Number')) !!}
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group required">
                                            {!! Form::label('date_of_birth', lang('patient.date_of_birth'), array('class' => 'col-sm-4 control-label')) !!}
                                            <div class="col-sm-8">
                                                {!! Form::text('date_of_birth', ($result->date_of_birth)? convertToLocal($result->date_of_birth, 'd-m-Y') : null, array('id' => 'dob', 'class' => 'form-control date-picker', 'placeholder' => 'Date Of Birth', 'data-input' => 'age')) !!}
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            {!! Form::label('gender', lang('patient.gender'), array('class' => 'col-sm-4 control-label')) !!}
                                            <div class="col-sm-8">
                                                {!! Form::select('gender', $genderArr, null, array('class' => 'form-control select2 padding0')) !!}
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            {!! Form::label('address', lang('patient.address'), array('class' => 'col-sm-4 control-label')) !!}
                                            <div class="col-sm-8">
                                                {!! Form::textarea('address', null, array('class' => 'form-control address', 'placeholder' => 'Address', 'rows' => 4, 'cols' => 50)) !!}
                                            </div>
                                        </div>

                                        <div class="form-group required">
                                            {!! Form::label('status', lang('common.active') . '&nbsp;', array('class' => 'col-sm-4 control-label')) !!}
                                            <div class="col-sm-8">
                                                <label class="checkbox col-sm-3">
                                                    {!! Form::checkbox('status', '1', true) !!}
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="form-group">
                                            {!! Form::label('last_name', lang('patient.last_name'), array('class' => 'col-sm-4 control-label')) !!}
                                            <div class="col-sm-8">
                                                {!! Form::text('last_name', null, array('class' => 'form-control', 'placeholder' => 'Last Name')) !!}
                                            </div>
                                        </div>

                                        <div class="form-group ">
                                            {!! Form::label('user_name', lang('patient.user_name'), array('class' => 'col-sm-4 control-label')) !!}
                                            <div class="col-sm-8">
                                                {!! Form::text('user_name', (is_object($user)) ? $user->username : null, array('class' => 'form-control', 'placeholder' => 'User Name')) !!}
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            {!! Form::label('alternate_contact_no', lang('patient.alternate_no'), array('class' => 'col-sm-4 control-label')) !!}
                                            <div class="col-sm-8">
                                                <div class="col-sm-4 padding0">
                                                    {!! Form::text('std_code', $stdCode, array('class' => 'form-control', 'min' => 1, 'maxlength' => 4, 'placeholder' => 'STD CODE')) !!}
                                                </div>
                                                <div class="col-sm-8 paddingright0">
                                                    {!! Form::text('alternate_contact_no', $alternateNo, array('class' => 'form-control', 'placeholder' => 'Phone Number', 'min' => 1, 'maxlength' => 7)) !!}
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group required">
                                            {!! Form::label('age', lang('patient.age'), array('class' => 'col-sm-4 control-label')) !!}
                                            <div class="col-sm-8">
                                                {!! Form::text('age', null, array('id' => 'age', 'class' => 'form-control', 'placeholder' => 'Age In Years')) !!}
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            {!! Form::label('blood_group', lang('patient.blood_group'), array('class' => 'col-sm-4 control-label')) !!}
                                            <div class="col-sm-8">
                                                {!! Form::select('blood_group', $bloodGroupArr, null, array('class' => 'form-control select2 padding0')) !!}
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            {!! Form::label('city', lang('patient.city'), array('class' => 'col-sm-4 control-label')) !!}
                                            <div class="col-sm-8">
                                                {!! Form::text('city', null, array('class' => 'form-control', 'placeholder' => 'City')) !!}
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            {!! Form::label('country', lang('patient.country'), array('class' => 'col-sm-4 control-label')) !!}
                                            <div class="col-sm-8">
                                                {!! Form::text('country', null, array('class' => 'form-control', 'placeholder' => 'Country')) !!}
                                            </div>
                                        </div>

                                    </div>

                                    <div class="col-md-4">

                                        <div class="form-group">
                                            {!! Form::label('patient_code', lang('patient.patient_code'), array('class' => 'col-sm-4 control-label')) !!}
                                            <div class="col-sm-8">
                                                {!! Form::text('patient_code', $result->patient_code, array('class' => 'form-control', 'readonly' => 'readonly')) !!}
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            {!! Form::label('password', lang('registration.password'), array('class' => 'col-sm-4 control-label')) !!}
                                            <div class="col-sm-8">
                                                {!! Form::password('password', ['class' => 'form-control', 'placeholder' => 'Password']) !!}
                                            </div>
                                        </div>

                                        <div class="form-group required">
                                            {!! Form::label('registration_date', lang('patient.registration_date'), array('class' => 'col-sm-4 control-label paddingright5')) !!}
                                            <div class="col-sm-8">
                                                {!! Form::text('registration_date', ($result->registration_date)? convertToLocal($result->registration_date, 'd-m-Y') : null, array('class' => 'form-control date-picker', 'placeholder' => 'Registration Date')) !!}
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            {!! Form::label('marital_status', lang('patient.marital_status'), array('class' => 'col-sm-4 control-label')) !!}
                                            <div class="col-sm-8">
                                                {!! Form::select('marital_status', $maritalStatusArr, ($result->marital_status)? $result->marital_status : null, array('class' => 'form-control select2 padding0')) !!}
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            {!! Form::label('relationship', lang('patient.relationship'), array('class' => 'col-sm-4 control-label')) !!}
                                            <div class="col-sm-8">
                                                {!! Form::text('relationship', null, array('class' => 'form-control', 'placeholder' => 'Relationship eg: S/o, M/o')) !!}
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            {!! Form::label('state', lang('patient.state'), array('class' => 'col-sm-4 control-label')) !!}
                                            <div class="col-sm-8">
                                                {!! Form::text('state', null, array('class' => 'form-control', 'placeholder' => 'State')) !!}
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            {!! Form::label('zip_code', lang('patient.zip_code'), array('class' => 'col-sm-4 control-label')) !!}
                                            <div class="col-sm-8">
                                                {!! Form::text('zip_code', null, array('class' => 'form-control', 'placeholder' => 'Area Zip Code', 'maxlength' => 6)) !!}
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-11 text-center">
                                        <div class="form-group">
                                            {!! Form::submit(lang('common.update'), array('class' => 'btn btn-primary')) !!}
                                        </div>
                                    </div>
                                    {!! Form::close() !!}
                                </div>
                                <div id="additional_tab" class="tab-pane fade">
                                    {{--{!! Form::open(array('method' => 'POST', 'route' => array('patient-registration.store'), 'id' => 'ajaxSave', 'class' => 'form-horizontal')) !!}--}}

                                    {{--{!! Form::close() !!}--}}
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- end: TEXT FIELDS PANEL -->
            </div>
        </div>    
    </div>
</div>
<!-- /#page-wrapper -->
@stop
@section('script')
    <script type="text/javascript">
        $(document).ready(function() {
            var datePicker = $('#dob').datepicker({
                showButtonPanel: false,
                dateFormat: "dd-mm-yy",
                dayNamesMin: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
                changeYear: true,
                changeMonth: true,
                yearRange: '1960:' + new Date().getFullYear(),
                defaultDate: new Date()
            });

            $(datePicker).on('change', function(){
                var thisVal = $(this).val();
                var target = $(this).data('input');
                if(thisVal != '')
                {
                    var route = "{!! route('calculate-age') !!}";
                    calculateAge(thisVal, route, target);
                }
            });
        });
    </script>
@stop