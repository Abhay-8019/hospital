@if (count($mergedOrders) > 0)
    <tr class="co_merged hidden">
        <th width="5%" class="text-center">{!! lang('common.id') !!}</th>
        <th width="40%">{!! lang('customer_purchase_order.product') !!}</th>
        <th width="6%">{!! lang('customer_purchase_order.size') !!}</th>
        <th width="8%" class="text-center">{!! lang('customer_purchase_order.order_quantity') !!}</th>
        <th width="8%" class="text-center">{!! lang('customer_purchase_order.pending_quantity') !!}</th>
    </tr>
    <?php $index = 1; $totalOrderQty = $totalPendingQty = 0; $totalOrderProQty = $totalPendingProQty = 0; $oldProduct = ''; ?>
    @foreach($mergedOrders as $detail)
        @if($index > 1 && $oldProduct != $detail->product_id)
            <tr class="co_merged hidden" style="font-weight: bold;font-size: 14px;">
                <td colspan="3" style="text-align: right;"> By Product Total Qty(s) </td>
                <td style="text-align: center;">{!! $totalOrderProQty !!}</td>
                <td style="text-align: center;">{!! $totalPendingProQty !!}</td>
            </tr>
            <tr bgcolor="#ACACAC" class="co_merged hidden">
                <td colspan="5">&nbsp;</td>
            </tr>
            <?php $totalOrderProQty = $totalPendingProQty = 0; ?>
        @endif
        <?php

            $orderQty = $detail->ordered_qty;
            $dispatchedQty = $detail->dispatched_over;
            $canceledQty = (array_key_exists($detail->product_id .'.'. $detail->size_id, $canceledOrders)) ? $canceledOrders[$detail->product_id .'.'. $detail->size_id]['canceled_qty'] : 0;
            $addedQty = (array_key_exists($detail->product_id .'.'. $detail->size_id, $canceledOrders)) ? $canceledOrders[$detail->product_id .'.'. $detail->size_id]['added_qty'] : 0;

            $totalOrderQty += $orderQty;
            $totalPendingQty += ($orderQty - (($dispatchedQty + $canceledQty) - $addedQty));

            $totalOrderProQty += $orderQty;
            $totalPendingProQty += ($orderQty - (($dispatchedQty + $canceledQty) - $addedQty));
        ?>
        <tr class="co_merged hidden">
            @if($oldProduct != $detail->product_id)
                <td class="text-center">{!! $index++ !!}</td>
                <td> {!! $detail->product_name !!} ({!! $detail->product_code !!}) </td>
            @else
                <td colspan="2">&nbsp;</td>
            @endif
            <td>{!! $detail->size !!} </td>

            <td class="text-center">{!! $orderQty !!} </td>
            <td class="text-center"> {!! ($orderQty  - (($dispatchedQty + $canceledQty) - $addedQty)) !!} </td>
        </tr>
        <?php $oldProduct = $detail->product_id; ?>
    @endforeach
    <tr class="co_merged hidden" style="font-weight: bold;font-size: 14px;">
        <td colspan="3" style="text-align: right;"> By Product Total Qty(s) </td>
        <td style="text-align: center;">{!! $totalOrderProQty !!}</td>
        <td style="text-align: center;">{!! $totalPendingProQty !!}</td>
    </tr>
    <tr style="@if(!isset($download)) font-size: 18px; @else font-size: 12px; @endif font-weight: bold" class="co_merged hidden">
        <td colspan="3" style="text-align: right;">Total Qty(s)</td>
        <td style="text-align: center;">{!! $totalOrderQty !!} </td>
        <td style="text-align: center;"> {!! $totalPendingQty !!}  </td>
    </tr>
@else
    <tr class="co_merged hidden">
        <td colspan="5" class="text-center"> {!! lang('messages.no_data_found') !!}  </td>
    </tr>
@endif