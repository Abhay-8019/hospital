@if(isset($pdf))
    <table border="1" cellpadding="0" cellspacing="0" width="100%">
@endif
<thead>
@if (count($orders) > 0)
    @if(!isset($download))
        <tr class="no-hover">
            <td colspan="9">
                <div class="hide" style="position: absolute;bottom: 10px; width: 100%;text-align: center;">
                    {!! lang('report.powered_by_cyber') !!}
                </div>
                <h3 style="text-align:center;margin-bottom: 0px; margin-top: 0px;margin-bottom:0;  font-family: times new roman; text-transform: uppercase; font-size: 2.6em; font-weight: 900;"> {!! $company->company_name !!} </h3>
                <div style="text-align: center; font-size: 1.0em;margin: 0;">
                    {!! $company->permanent_address !!},
                    {!! $company->city . ' - ' . $company->pincode !!}<br>
                    <div>
                        @if((!empty($company->email1))) Email: {!! $company->email1 !!} @endif
                        @if((!empty($company->mobile1))) <br/> Mobile: {!! $company->mobile1 !!}, @endif
                        @if((!empty($company->phone))) Phone: {!! $company->phone !!} @endif
                    </div>
                </div>
            </td>
        </tr>
        <tr class="no-hover">
            <td colspan="9">
            <div style="text-align: center;margin: 0;">
                <p style="font-size: 1.5em;margin:0;">
                    <b> <span style="text-decoration: underline;"> Customer Order's </span> <br/> {!! $customerInfo !!} <br/> </b>
                </p>
                <p style="font-size: 1.2em;margin:0;">
                    <span style="font-weight: bold;">
                    @if($inputs['report_type'] == 1 && isset($inputs['from_date']) && isset($inputs['to_date']))
                        (Dated: {!! dateFormat('d.m.Y', $inputs['from_date']) !!} - {!! dateFormat('d.m.Y', $inputs['to_date']) !!})
                    @elseif($inputs['report_type'] == 2)
                        (for the month of {!! getMonths($inputs['month']) !!})
                    @elseif($inputs['report_type'] == 3)
                        (for the year of {!! getYear("", "", true, $inputs['year']) !!})
                    @endif
                    </span>
                </p>
            </div>
        </td>
        </tr>
    @endif
@endif
</thead>
<tr>
    <th width="5%" style="text-align: center;">{!! lang('common.id') !!}</th>
    <th width=8%" style="text-align: center;">{!! lang('customer_purchase_order.po_number') !!}</th>
    <th width="8%" style="text-align: center;">{!! lang('customer_purchase_order.po_date') !!}</th>
    <th>{!! lang('customer_purchase_order.product') !!}</th>
    <th width="6%">{!! lang('customer_purchase_order.size') !!}</th>
    <th width="8%" style="text-align: center;">{!! lang('customer_purchase_order.order_quantity') !!}</th>
    <th width="8%" style="text-align: center;">{!! lang('customer_purchase_order.pending_quantity') !!}</th>
    <th width="8%" style="text-align: right;">{!! lang('customer_purchase_order.price') !!}</th>
    <th width="8%" style="text-align: right;">{!! lang('customer_purchase_order.total') !!}</th>
</tr>
<?php $index = 1; $showGenerate = true; $oldOrderId = $oldBillQty = '';
$totalOrderQty = $totalPendingQty = $totalPendingAmount = $totalGross = $totalPrice = 0; ?>
@foreach($orders as $detail)
    <?php
        $pending = "#69BCDF";
        $partially = "#E3B061";
        $complete = "#58B063";
        $overDispatched = "#ec7f98";
        $overDispatch = true;

        $color = $pending;
        if (($detail->quantity - $detail->dispatched_qty) == 0) {
            $color = $complete;
        } elseif($detail->quantity > ($detail->quantity - $detail->dispatched_qty)) {
            $color = $partially;
        }

        if (($detail->quantity - $detail->dispatched_qty) < 0) {
            $overDispatch = isset($inputs['order_status']) ? ($inputs['order_status'] == 2) ? true : false : true;
            $color = $overDispatched;
        }
        $totalPrice += $detail->total_price;
    ?>
    @if($overDispatch)
    <tr class="text-whited" id="order_{{ $detail->id }}" bgcolor="{!! $color !!}">
        <td style="text-align: center;">{!! $index++ !!}</td>
        <td style="text-align: center;">{!! $detail->po_number !!}</td>
        <td style="text-align: center;">{!! dateFormat('d.m.Y', $detail->po_date) !!} </td>
        <td>{!! $detail->product_name !!} ({!! $detail->product_code !!})</td>
        <td>{!! $detail->size !!}</td>
        <?php
            $totalOrderQty += $detail->quantity;
            $totalPendingQty += ($detail->quantity - $detail->dispatched_qty);
        ?>
        <td style="text-align: center;">{!! $detail->quantity !!} </td>
        <?php
        $totalPending = ($detail->quantity - $detail->dispatched_qty);
        $totalPending = ($totalPending < 0) ? $detail->quantity : $totalPending;
        $totalPendingP = (($detail->quantity - $detail->dispatched_qty) < 0) ? 0 : $totalPending;
        $totalPendingAmount += $totalPendingP * $detail->price;
        ?>
        <td style="text-align: center;">{!! $totalPendingP !!}</td>
        <td style="text-align: right;">{!! $detail->price !!} </td>
        <td style="text-align: right;">
            {!! numberFormat($totalPending * $detail->price, false) !!}
        </td>
    </tr>
    @endif
    <?php $oldOrderId = $detail->cpo_id; ?>
@endforeach
@if (count($orders) > 0)
@if($totalOrderQty != 0)
<tr style="@if(!isset($download)) font-size: 18px; @else font-size: 12px; @endif font-weight: bold">
    <td colspan="5" style="text-align: right;">Total Qty(s)</td>
    <td style="text-align: center;">{!! $totalOrderQty !!} </td>
    <td style="text-align: center;"> {!! $totalPendingQty !!}  </td>
    <td style="text-align: center;"> &nbsp; </td>
    <td style="text-align: right;">{!! numberFormat($totalPendingAmount, false) !!}</td>
</tr>
@endif
@endif
@if (count($orders) < 1)
    <tr>
        <td colspan="9" class="text-center"> {!! lang('messages.no_data_found') !!}  </td>
    </tr>
@endif
</tbody>
@if(isset($pdf))
    </table>
@endif