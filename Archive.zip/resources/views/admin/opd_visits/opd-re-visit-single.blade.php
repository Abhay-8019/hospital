@extends('layouts.admin')

@section('content_header')
	<section class="content-header">
		<h1>
			{!! lang('opd_master.opd_revisit') !!}
		</h1>
	</section>
@stop

@section('content')
<div id="page-wrapper">
	{{-- for message rendering --}}
    @include('layouts.messages')
    <div class="row">

		<div class="col-md-12">
			<!-- start: BASIC TABLE PANEL -->
			<div class="panel panel-default" style="position: static;">
				<div class="panel-heading">
					<i class="fa fa-external-link-square"></i> &nbsp;
					{!! lang('opd_master.opd_revisit') !!}
				</div>
				<div class="panel-body padding0">
					<div class="col-md-6 hidden marginbottom10">
						{!! Form::hidden('page', '1') !!}
					</div>
					<div id="p-report">
					{!! Form::open(array('method' => 'POST', 'route' => array('patient.opd-re-visit'), 'id' => 'ajaxSave')) !!}
						<?php $json = ""; ?>
						<table class="table table-bordered clearfix margin0 col-md-12 padding0 font-14">
							<thead>
<tr>
    <th width="1%">#</th>
    <th width="5%">{!! lang('patient.patient_code') !!}</th>
    <th width="10%">{!! lang('common.name') !!}</th>
    <th width="5%">{!! lang('common.age') !!} / {!! lang('common.gender') !!}</th>
    <th width="5%">{!! lang('common.mobile') !!}</th>
    <th class="text-center" colspan="3" width="20%">{!! lang('common.action') !!}</th>
</tr>
</thead>
<tbody>
<?php
    $index = 1;
    $genderArr = lang('common.genderArrayShort');
?>
@if(count($data) > 0)
    @foreach($data as $key => $detail)
        <tr>
            <td> {!! $index++ !!} </td>
            <td> {!! $detail->patient_code !!} </td>
            <td>
                {!! $detail->first_name !!}
            </td>
            <td>{!! $detail->age !!} @if($detail->age) Y @endif / @if($detail->gender != '') {!! $genderArr[$detail->gender] !!} @endif</td>
           
            <td>{!! $detail->mobile !!}</td>
            <td class="text-center col-md-1">
                @if(count($data) == 1)
                    {!! Form::select('department', $departments, $detail->department_id, array('class' => 'form-control select2d padding0')) !!}
                @endif
            </td>
            <td class="text-center col-md-1">
                @if(count($data) == 1)
                    {!! Form::select('doctor', $doctors, $detail->doctor_id, array('class' => 'form-control select2d padding0')) !!}
                @endif
                {!! Form::hidden('p_id', $detail->patient_id) !!}
            </td>
            <td class="text-center col-md-1">
                @if(count($data) == 1)
                    {!! Form::text('remarks', null, array('class' => 'form-control', 'placeholder' => 'Remarks')) !!}
                @endif
            </td>

        </tr>
    @endforeach
    <tr>
        <td colspan="5">&nbsp;</td>
        <td colspan="3" class="text-center">
            {!! Form::submit(lang('common.save'), array('class' => 'btn btn-primary btn-lg')) !!}
        </td>
    </tr>
@endif
@if (count($data) < 1)
    <tr>
        <td class="text-center" colspan="6"> {!! lang('messages.no_data_found') !!} </td>
    </tr>
@endif
</tbody>
						</table>
						{!! Form::hidden('form-save', 1) !!}
					</div>
					{!! Form::close() !!}
				</div>
			</div>
			<!-- end: BASIC TABLE PANEL -->
		</div>

	</div>	
</div>
<!-- /#page-wrapper -->
@stop
