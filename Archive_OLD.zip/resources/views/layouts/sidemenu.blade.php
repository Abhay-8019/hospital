<li class="treeview">
    <a href="{!! route('dashboard') !!}">
        <i class="fa fa-dashboard"></i> <span> {!! lang('master.dashboard') !!} </span>
    </a>
</li>
<li class="treeview">
    <a href="javascript:void(0)">
        <i class="fa fa-book"></i>
        <span class="title"> Masters </span>
    </a>
    <ul class="treeview-menu">
        <li>
            <a href="{!! route('financial-year.index') !!}">
                <span class="title"> {!! lang('financial_year.financial_years') !!} </span>
            </a>
        </li>
        <li>
            <a href="{!! route('tax.index') !!}">
                <span class="title"> {!! lang('tax.tax') !!} </span>
            </a>
        </li>

        <li>
            <a href="{!! route('hsn-code.index') !!}">
                <span class="title"> {!! lang('hsn_code.hsn_code') !!} </span>
            </a>
        </li>

        <li>
            <a href="{!! route('unit.index') !!}">
                <span class="title"> {!! lang('unit.unit') !!} </span>
            </a>
        </li>

        <li>
            <a href="{!! route('product-group.index') !!}">
                <span class="title"> {!! lang('product_group.product_groups') !!} </span>
            </a>
        </li>

        <li>
            <a href="{!! route('products.index') !!}">
                <span class="title"> {!! lang('products.products') !!} </span>
            </a>
        </li>
        <li>
            <a href="{!! route('role.index') !!}">
                <span class="title"> {!! lang('role.role') !!} </span>
            </a>
        </li>
        <li>
            <a href="{!! route('user.index') !!}">
                <span class="title"> {!! lang('user.users') !!} </span>
            </a>
        </li>
    </ul>
</li>
<li class="treeview">
    <a href="#">
        <i class="fa fa-hospital-o"></i> <span> {!! lang('hospital.hospital') !!} </span>
    </a>
    <ul class="treeview-menu">
        <li>
            <a href="{!! route('department.index') !!}">
                <i class="fa fa-building-o"></i> <span> {!! lang('department.department') !!} </span>
            </a>
        </li>

        <li>
            <a href="{!! route('wards.index') !!}">
                <i class="fa fa-building-o"></i> <span> {!! lang('ward.wards') !!} </span>
            </a>
        </li>

        <li>
            <a href="{!! route('beds.index') !!}">
                <i class="fa fa-building-o"></i> <span> {!! lang('bed_master.bed_masters') !!} </span>
            </a>
        </li>

        <li>
            <a href="{!! route('rog-types.index') !!}">
                <i class="fa fa-building-o"></i> <span> {!! lang('rog_type.rog_types') !!} </span>
            </a>
        </li>

        <li>
            <a href="{!! route('ot-types.index') !!}">
                <i class="fa fa-building-o"></i> <span> {!! lang('ot_type.ot_types') !!} </span>
            </a>
        </li>

        <li>
            <a href="{!! route('procedures.index') !!}">
                <i class="fa fa-building-o"></i> <span> {!! lang('procedure.procedures') !!} </span>
            </a>
        </li>
    </ul>
</li>

<li class="treeview">
    <a href="#">
        <i class="fa fa-user-md"></i> <span> {!! lang('doctor.doctor') !!} </span>
    </a>
    <ul class="treeview-menu">
        <li>
            <a href="{!! route('designation.index') !!}">
                <i class="fa fa-building-o"></i> <span> {!! lang('designation.designation') !!} </span>
            </a>
            <a href="{!! route('specialization.index') !!}">
                <i class="fa fa-user-md"></i> <span> {!! lang('specialization.specialization') !!} </span>
            </a>
            <a href="{!! route('doctor.index') !!}">
                <i class="fa fa-user-md"></i> <span> {!! lang('doctor.doctor') !!} </span>
            </a>
        </li>
    </ul>
</li>

<li class="treeview hidef">
    <a href="#">
        <i class="fa fa-flask"></i> <span> {!! lang('test.tests') !!} </span>
    </a>
    <ul class="treeview-menu">
        <li>
            <a href="{!! route('test-category.index') !!}">
                <i class="fa fa-flask"></i> <span> {!! lang('test_category.test_categories') !!} </span>
            </a>
        </li>

        <li>
            <a href="{!! route('add-test.index') !!}">
                <i class="fa fa-flask"></i> <span> {!! lang('test.add_tests') !!} </span>
            </a>
        </li>

        <li>
            <a href="{!! route('patient-test.index') !!}">
                <i class="fa fa-flask"></i> <span> {!! lang('patient_test.patient_tests') !!} </span>
            </a>
        </li>
    </ul>
</li>


<li class="treeview">
    <a href="{!! route('patient-registration.index') !!}">
        <i class="fa fa-medkit"></i> <span> {!! lang('patient.opd_patients') !!} </span>
    </a>
    <ul class="treeview-menu">
        <li>
            <a href="{!! route('patient-registration.create') !!}">
                <i class="fa fa-circle-o"></i>
                {!! lang('patient.new_patient') !!}
            </a>
        </li>
        <li>
            <a href="{!! route('patient-registration.index') !!}">
                <i class="fa fa-circle-o"></i>
                {!! lang('patient.patients_list') !!}
            </a>
        </li>
        <li>
            <a href="{!! route('patient.opd-list') !!}">
                <i class="fa fa-circle-o"></i>
                {!! lang('opd_master.opd_visits') !!}
            </a>
        </li>

        <li>
            <a href="{!! route('patient.opd-re-visit') !!}">
                <i class="fa fa-circle-o"></i>
                {!! lang('opd_master.opd_revisit') !!}
            </a>
        </li>
    </ul>
</li>

<li class="treeview">
    <a href="{!! route('patient.ipd-list') !!}">
        <i class="fa fa-bed"></i> <span> {!! lang('ipd_master.ipd_visits') !!} </span>
    </a>
    <ul class="treeview-menu">
        <li>
            <a href="{!! route('patient.ipd-list') !!}">
                <i class="fa fa-circle-o"></i>
                {!! lang('ipd_master.ipd_visits') !!}
            </a>
        </li>
    </ul>
</li>

<li class="treeview">
    <a href="javascript:void(0)">
        <i class="fa fa-pie-chart"></i> <span> {!! lang('reports.reports') !!} </span>
    </a>
    <ul class="treeview-menu">
        <li>
            <a href="{!! route('report.patient-wise-visits') !!}">
                <i class="fa fa-circle-o"></i>
                {!! lang('opd_master.patient_wise_visits') !!}
            </a>
        </li>

        <li>
            <a href="{!! route('report.doctor-wise-visits') !!}">
                <i class="fa fa-circle-o"></i>
                {!! lang('opd_master.doctor_wise_visits') !!}
            </a>
        </li>

        <li>
            <a href="{!! route('report.department-wise-visits') !!}">
                <i class="fa fa-circle-o"></i>
                {!! lang('opd_master.department_wise_visits') !!}
            </a>
        </li>

        <li>
            <a href="{!! route('report.opd-visits') !!}">
                <i class="fa fa-circle-o"></i>
                {!! lang('opd_master.advanced_opd_search') !!}
            </a>
        </li>

        <li>
            <a href="{!! route('report.ipd-patients') !!}">
                <i class="fa fa-circle-o"></i>
                {!! lang('ipd_master.ipd_visits') !!}
            </a>
        </li>

        <li>
            <a href="{!! route('report.bed-occupancy') !!}">
                <i class="fa fa-circle-o"></i>
                {!! lang('ipd_master.bed_occupancy') !!}
            </a>
        </li>

        <li>
            <a href="{!! route('report.patient-tests') !!}">
                <i class="fa fa-circle-o"></i>
                {!! lang('patient_test.patient_tests') !!}
            </a>
        </li>
        <li class="treeview">
            <a href="{!! route('patient.opd-procedure-list') !!}">
                <i class="fa fa-circle-o"></i> <span> {!! lang('opd_master.procedures_done') !!} </span>
            </a>
        </li>        
    </ul>
</li>

<li class="treeview hide">
    <a href="{!! route('employee-type.index') !!}">
        <i class="fa fa-building-o"></i> <span> {!! lang('employee_type.employee_type') !!} </span>
    </a>
</li>

<li class="treeview hide">
    <a href="{!! route('staff.index') !!}">
        <i class="fa fa-building-o"></i> <span> {!! lang('staff.staff') !!} </span>
    </a>
</li>