<thead>
<tr>
    <th width="6%" class="text-center">{!! lang('common.id') !!}</th>
    <th width="10%">{!! lang('patient.patient_code') !!}</th>
    <th width="15%">{!! lang('patient.first_name') !!}</th>
    <th width="8%">{!! lang('common.age') !!}</th>
    <th width="6%">{!! lang('common.gender') !!}</th>
    <th width="10%">{!! lang('common.mobile') !!}</th>
    <th width="15%">{!! lang('common.registration_date') !!}</th>
    @if(hasMenuRoute('patient-registration.edit'))
     <th class="text-center">{!! lang('common.action') !!}</th>
    @endif
</tr>
</thead>
<tbody>
<?php
    $index = 1;
    $genderArr = lang('common.genderArray');
    $bloodGroupArr = lang('common.bloodGroupArr');
?>
@if (isset($data) && count($data) > 0)
    @foreach($data as $key => $detail)
        <tr id="patientId_{{ $detail->id }}">
            <td class="text-center">{!! pageIndex($index++, $page, $perPage) !!}</td>
            <td>
                <a href="{!! route('patient.opd-visit-history', $detail->id) !!}">
                    {!! $detail->patient_code !!}
                </a>

            </td>
            <td>
                {!! $detail->first_name !!}
            </td>
            <td>{!! $detail->age !!} @if($detail->age) Years @endif</td>
            <td>@if($detail->gender != '') {!! $genderArr[$detail->gender] !!} @endif </td>
            <td>{!! $detail->mobile !!}</td>
            <td>{!! convertToLocal($detail->registration_date, 'd-m-Y') !!}</td>
            @if(hasMenuRoute('patient-registration.edit'))
                <td class="text-center col-md-1">
                    <a class="btn btn-xs btn-primary" href="{{ route('patient-registration.edit', [$detail->id]) }}"><i class="fa fa-edit"></i></a>
                </td>
            @endif
        </tr>
    @endforeach
    <tr class="margintop10">
        <td colspan="9">
            {!! paginationControls($page, $total, $perPage) !!}
        </td>
    </tr>
@else
    <tr>
        <td class="text-center" colspan="9"> {!! lang('messages.no_data_found') !!} </td>
    </tr>
@endif
</tbody>