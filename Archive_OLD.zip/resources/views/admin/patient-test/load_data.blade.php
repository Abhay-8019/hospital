<thead>
<tr>
    <th width="5%" class="text-center">{!! lang('common.id') !!}</th>
    <th width="10%" >{!! lang('patient_test.receipt_no') !!}</th>
    <th>{!! lang('common.name') !!}</th>
    <th>{!! lang('patient_test.test_date') !!}</th>
    <th>{!! lang('patient_test.amount') !!}</th>
    <th>{!! lang('patient_test.report') !!}</th>
    <th width="10%" class="text-center">{!! lang('common.action') !!}</th>
</tr>
</thead>
<tbody>
<?php $index = 1; ?>
@foreach($data as $detail)
<tr id="order_{{ $detail->id }}">
    <td class="text-center">{!! pageIndex($index++, $page, $perPage) !!}</td>
    <td>
        {!!  lang('patient_test.rcpt') . $detail->receipt_no !!}
    </td>
    <td>{!! $detail->first_name !!} @if($detail->age != "") ({!! $detail->age !!} Y) @endif</td>
    <td>{!! dateFormat('d M, Y', $detail->test_date) !!}</td>
    <td>{!! numberFormat($detail->total) !!}</td>
    <td><a href="{{ route('patient-test.generate_report', [$detail->id]) }}"> {!! lang('patient_test.gen_report') !!}</a> </td>
    <td class="text-center">
        <a class="btn btn-xs btn-primary" href="{{ route('patient-test.edit', [$detail->id]) }}"><i class="fa fa-edit"></i></a>
        <a class="btn btn-xs btn-success" href="{{ route('patient-test.show', [$detail->id]) }}" target="_blank"><i class="fa fa-print"></i></a>
        <a class="btn btn-xs btn-danger" href="{{ route('patient-test.report', [$detail->id]) }}" target="_blank"><i class="fa fa-print"></i></a>
    </td>
</tr>
@endforeach
@if (count($data) < 1)
<tr>
    <td class="text-center" colspan="7"> {!! lang('messages.no_data_found') !!} </td>
</tr>
@else
<tr class="margintop10">
    <td colspan="7">
        {!! paginationControls($page, $total, $perPage) !!}
    </td>
</tr>
@endif
</tbody>