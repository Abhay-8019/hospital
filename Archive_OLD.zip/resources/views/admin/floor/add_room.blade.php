@extends('layouts.admin')
@section('content_header')
    <section class="content-header">
        <h1>
            {!! lang('floor.add_heading', lang('floor.floor')) !!}#{!! $result->name !!}
            <small>{!! lang('common.record_update') !!}</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> {!! lang('common.back') !!}</a></li>
            <li><a href="{!! route('dashboard') !!}"><i class="fa fa-dashboard"></i>{!! lang('common.dashboard') !!}</a></li>
            <li><a href="{!! route('floor.index') !!}">{!! lang('floor.floor') !!}</a></li>
            <li class="active">{!! lang('floor.add_heading', lang('floor.floor')) !!}</li>
        </ol>
    </section>
@stop
@section('content')
    <div id="page-wrapper">
        <!-- start: PAGE CONTENT -->

        {{-- for message rendering --}}

        @include('layouts.messages')
        <div class="row">
            <?php
            $room = $result->total_rooms;
            $floorId = $result->id;
            ?>
            <div class="col-md-12 padding0">
                <div id="hiddenDiv" class="hidden">
                    <div class="form-group">
                        {!! Form::label('room_code', lang('room.room_code'), array('class' => 'col-sm-1 control-label')) !!}

                        <div class="col-sm-1">
                            {!! Form::text('room_code[]', null, array('class' => 'form-control')) !!}
                        </div>

                        {!! Form::label('room_name', lang('room.room_name'), array('class' => 'col-sm-1 control-label')) !!}

                        <div class="col-sm-2">
                            {!! Form::text('room_name[]', null, array('class' => 'form-control')) !!}
                        </div>

                        {!! Form::label('room_charges', lang('room.room_charges'), array('class' => 'col-sm-1 control-label')) !!}

                        <div class="col-sm-1">
                            {!! Form::text('room_charges[]', null, array('class' => 'form-control')) !!}
                        </div>

                        {!! Form::label('room_type', lang('room.room_type'), array('class' => 'col-sm-1 control-label')) !!}
                        <div class="col-sm-2">
                            {!! Form::select('room_type[]', $roomType, null, array('class' => 'form-control padding0')) !!}
                        </div>

                        <a href="#" class="remove_field"> <b> X </b> </a>

                    </div>
                </div>
                {!! Form::open(array('method' => 'POST', 'route' => array('floor.saveroom', $result->id), 'id' => 'ajaxSave', 'class' => 'form-horizontal')) !!}
                        <!-- previous room form id => room-form -->
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-external-link-square"></i> &nbsp;
                            {!! lang('room.room_detail') !!}
                        </div>
                        <div class="panel-body">

                            <div class="row">
                                {{--{!! Form ::text('building_id',$result->building_id) !!}--}}
                                {!! Form::hidden('floor_id', $floorId) !!}
                                {!! Form::hidden('total_room', $room) !!}
                                {{--@for($i=1;$i<=$room;$i++)--}}

                                <div class="newDiv">
                                    <div class="form-group">
                                        {!! Form::label('room_code', lang('room.room_code'), array('class' => 'col-sm-1 control-label')) !!}

                                        <div class="col-sm-1">
                                            {!! Form::text('room_code[]', null, array('class' => 'form-control')) !!}
                                        </div>

                                        {!! Form::label('room_name', lang('room.room_name'), array('class' => 'col-sm-1 control-label')) !!}

                                        <div class="col-sm-2">
                                            {!! Form::text('room_name[]', null, array('class' => 'form-control')) !!}
                                        </div>

                                        {!! Form::label('room_charges', lang('room.room_charges'), array('class' => 'col-sm-1 control-label')) !!}

                                        <div class="col-sm-1">
                                            {!! Form::text('room_charges[]', null, array('class' => 'form-control')) !!}
                                        </div>

                                        {!! Form::label('room_type', lang('room.room_type'), array('class' => 'col-sm-1 control-label')) !!}
                                        <div class="col-sm-2">
                                            {!! Form::select('room_type[]', $roomType, null, array('class' => 'form-control padding0')) !!}
                                        </div>

                                        <div class="col-sm-2">
                                            {!! Form::button(lang('common.add'), array('class' => 'btn btn-primary col-sm-8 addBtn')) !!}
                                        </div>

                                    </div>
                                    <div id="hiddenDiv"> </div>

                                </div>
                                {{--@endfor--}}

                                <div class="col-sm-11 margintop20 clearfix text-center">
                                    <div class="form-group">
                                        {!! Form::submit(lang('common.save'), array('class' => 'btn btn-primary')) !!}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end: TEXT FIELDS PANEL -->
                </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
    <!-- /#page-wrapper -->
@stop
@section('script')
    <script>
        $(document).ready(function() {
            var max_fields      = 50; //maximum input boxes allowed
            var wrapper         = $(".newDiv"); //Fields wrapper
            var add_button      = $(".addBtn"); //Add button Class

            var x = 1; //initlal text box count
            $(add_button).click(function(e){ //on add input button click
                e.preventDefault();
                console.log();
                if(x < max_fields) { //max input box allowed
                    x++; //text box increment
                    $(wrapper).append($('#hiddenDiv').html()); //add input box
                }
            });

            $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
                e.preventDefault();
                $(this).parent('div').remove();
                x--;
            })

          /*  $("#dropDown").on(click, function(){
               $ajax({
                   type : "GET",
                   dataType : "html",
                   url : "floor/dropDownFetch",
                   beforeSend: function() {
                       $('.testdropDown').html('Please Wait...');
                   },success: function(){
                       console.log(htmldata);
                   }

               })
            })*/
        });
    </script>
@endsection