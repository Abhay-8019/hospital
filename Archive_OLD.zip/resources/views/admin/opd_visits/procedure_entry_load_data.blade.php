<thead>
<tr>
    <th width="10%">{!! lang('patient.patient_code') !!}/<br/>{!! lang('opd_master.opd_number') !!}</th>
    <th width="10%">{!! lang('opd_master.procedure_date') !!}</th>
    <th width="10%">{!! lang('patient.first_name') !!}</th>
    <th width="8%">{!! lang('common.age') !!}</th>
    <th width="6%">{!! lang('common.gender') !!}</th>
    <th width="10%">Doctor/Department</th>
    <th width="10%">{!! lang('procedure.procedure') !!}</th>
    <th class="text-center">{!! lang('common.action') !!}</th>
</tr>
</thead>
<tbody>
<?php
$index = 1;
$genderArr = lang('common.genderArray');
?>
@if(count($data) > 0)
    @foreach($data as $key => $detail)
        <tr>
            <td><b>{!! $detail->patient_code !!}</b>/{!! ($detail->opd_number != "") ? $detail->opd_number : "IP-".$detail->ipd_number !!} </td>
            <td>{!! dateFormat('d.m.Y', $detail->procedure_held_date) !!}</td>
            <td>{!! $detail->first_name !!}</td>
            <td>{!! $detail->age !!} @if($detail->age) Years @endif </td>
            <td>@if($detail->gender != '') {!! $genderArr[$detail->gender] !!} @endif </td>
            <td><b>{!! $detail->doctor_name !!}</b> ({!! $detail->department_name !!})</td>
            <td>{!! $detail->procedure_name !!}</td>
            <td class="text-center col-md-1">
                @if($detail->opd_master_id > 0)
                    <a class="btn btn-xs btn-primary" href="{!! route('patient.opd-procedure-visit', ['id' => $detail->opd_master_id, 'pid' => $detail->id]) !!}" target="_blank" data-title="Edit Procedure Visit"><i class="fa fa-edit"></i></a>
                @else
                    <a class="btn btn-xs btn-primary" href="{!! route('patient.ipd-procedure-visit', ['id' => $detail->ipd_master_id, 'pid' => $detail->id]) !!}" target="_blank" data-title="Edit Procedure Visit"><i class="fa fa-edit"></i></a>
                @endif
                <a class="btn btn-xs btn-danger __drop" data-route="{!! route('patient.opd-procedure-drop', $detail->id) !!}" data-message="{!! lang('messages.sure_delete', string_manip(lang('opd_master.procedure'))) !!}" href="javascript:void(0)"><i class="fa fa-times"></i></a>
            </td>
        </tr>
    @endforeach
@endif
@if(count($summary) > 0)
    <tr><td colspan="8">&nbsp;</td></tr>
    <tr>
        <th colspan="8">Department Summary</th>
    </tr>
    <tr>
        <th>Department</th>
        <th colspan="7">Procedures Done</th>
    </tr>
    @foreach($summary as $key=>$detail)
        <tr>
            <td>{!! $detail->department_name !!}</td>
            <td colspan="7">{!! $detail->total !!}</td>
        </tr>
    @endforeach
@endif

@if(count($psummary) > 0)
    <tr><td colspan="8">&nbsp;</td></tr>
    <tr>
        <th colspan="8">Procedure Summary</th>
    </tr>
    <tr>
        <th>Procedure</th>
        <th colspan="7">Count</th>
    </tr>
    @foreach($psummary as $key=>$detail)
        <tr>
            <td>{!! $detail->procedure_name !!}</td>
            <td colspan="7">{!! $detail->total !!}</td>
        </tr>
    @endforeach
@endif

@if (count($data) < 1)
    <tr>
        <td class="text-center" colspan="8"> {!! lang('messages.select_range') !!} </td>
    </tr>
@endif
</tbody>