<thead>
<tr>
    <th width="10%">{!! lang('opd_master.opd_number') !!}</th>
    <th width="10%">{!! lang('opd_master.visit_date') !!}</th>
    <th width="10%">{!! lang('patient.patient_code') !!}</th>
    <th width="10%">{!! lang('patient.first_name') !!}</th>
    <th width="8%">{!! lang('common.age') !!}</th>
    <th width="6%">{!! lang('common.gender') !!}</th>
    <th width="10%">{!! lang('common.mobile') !!}</th>
    <th class="text-center">{!! lang('common.action') !!}</th>
</tr>
</thead>
<tbody>
<?php
$index = 1;
$genderArr = lang('common.genderArray');
?>
@if(count($data) > 0)
    @foreach($data as $key => $detail)
        <tr>
            <td> {!! $detail->opd_number !!} </td>
            <td>
                {!! dateFormat('d.m.Y', $detail->visit_date) !!}
            </td>
            <td>
                {!! $detail->patient_code !!}
            </td>
            <td>
                {!! $detail->first_name !!}
            </td>
            <td>{!! $detail->age !!} @if($detail->age) Years @endif </td>
            <td>@if($detail->gender != '') {!! $genderArr[$detail->gender] !!} @endif </td>
            <td>{!! $detail->mobile !!}</td>
            <td class="text-center col-md-1">
                <a class="btn btn-xs btn-primary" href="{!! route('patient.opd-visit-edit', [$detail->id]) !!}"><i class="fa fa-edit"></i></a>
                <a href="{!! route('patient.opd-visit-print', $detail->id) !!}" class="btn btn-xs btn-success"> <i class="fa fa-eye"></i> </a>
                <a class="btn btn-xs btn-danger __drop" data-route="{!! route('patient.opd-visit-drop', [$detail->id]) !!}" data-message="{!! lang('messages.sure_delete', string_manip(lang('opd_master.opd_visit'))) !!}" href="javascript:void(0)"><i class="fa fa-times"></i></a>
            </td>
        </tr>
    @endforeach
@endif
@if (count($data) < 1)
    <tr>
        <td class="text-center" colspan="6"> {!! lang('messages.no_data_found') !!} </td>
    </tr>
@endif
</tbody>