@extends('layouts.admin')
@section('content_header')
<section class="content-header">
    <h1>
        {!! lang('opd_master.opd_visit') !!}
        <small>{!! lang('common.view_heading', " Visit Detail") !!}</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> {!! lang('common.back') !!}</a></li>
        <li class="active">{!! lang('opd_master.opd_visit') !!}</li>
    </ol>
</section>
@stop
@section('content')
<div id="page-wrapper">
    <!-- start: PAGE CONTENT -->
    <style>
        dose {
            color: blue;
            font-weight: bold;
            padding: 0 10px;
        }
        anu {
            color:red;
            font-weight: bold;
            padding: 0 10px;
        }
    </style>
    {{-- for message rendering --}}
    @include('layouts.messages')
    <div class="row">
        <div class="col-md-12 padding0">
            <!-- previous patient form id => patient-form -->
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading padding0">
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active">
                                <a href="#personal_tab" aria-controls="personal_tab" role="tab" data-toggle="tab">

                                    <i class="fa fa-external-link-square"></i>
                                    {!! lang('opd_master.opd_visit_detail') !!}
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <?php $linkCss = [asset('assets/css/bootstrap.min.css'),asset('assets/css/template.css')]; ?>
                            <a onclick="return reportPrint('p-report','{!! implode('|', $linkCss) !!}')" style="margin-right: 20px;" class="btn btn-success btn-sm pull-right marginbottom10">
                                &nbsp;<i class="fa fa-print"></i> {!! lang('common.print') !!} &nbsp;&nbsp;
                            </a>
                            <a class="btn btn-sm btn-danger pull-right marginright10" href="{!! route('patient.ipd-entry', $result->id) !!}">
                              <i class='fa fa-bed'></i>   Convert to IPD
                            </a>
                            <a class="btn btn-sm btn-danger pull-right marginright10" href="{!! route('patient.opd-visit-edit', $result->id) !!}">
                                <i class='fa fa-edit'></i> Edit
                            </a>
                            

                            <div class="tab-content" id="p-report">
                                <div id="personal_tab" class="tab-pane fade in active">
                                    <div class="col-md-12">
                                        <div class="col-md-2">
                                            <img src='/assets/images/logo.png' style="max-height: 100px;float: left;margin-right:50px;">
                                        </div>
                                        <div class="col-md-10">
                                            <h3>M.C. D.A.V. Hospital</h3>
                                            <h5>Mahatama Hans Raj Marg, ,Jalandhar-144008</h5>
                                            <h5>Phone:0181-2253572,08559067185</h5>
                                        </div>
                                    </div>                                    



                                    <div class="col-md-12">
                                        <h2>
                                            Patient Detail
                                        </h2>
                                        
                                        <table class="table table-bordered">
                                            <tr>
                                                <td width="15%"><b>{!! lang('patient.patient_code') !!}</b></td>
                                                <td>{!! $result->patient_id !!}</td>

                                                <td width="15%"><b>{!! lang('patient.first_name') !!}</b></td>
                                                <td>{!! $result->first_name !!}</td>

                                                <td width="15%"><b>{!! lang('patient.age') !!}</b></td>
                                                <td>{!! $result->age !!} / 
                                                    <?php $genderArr = lang('common.genderArray'); ?>
                                                {!! $genderArr[$result->gender] !!}</td>
                                            </tr>
                                            <tr>
                                                <td><b>{!! lang('opd_master.visit_date') !!}</b></td>
                                                <td>{!! dateFormat('d.m.Y', $result->visit_date) !!}</td>
                                                <td><b>{!! lang('department.department') !!}</b></td>
                                                <td> {!! $result->department !!} </td>
                                                <td> <b>{!! lang('doctor.doctor') !!}</b></td>
                                                <td> {!! $result->doctor !!}</td>
                                            </tr>
                                            <tr>
                                                <td><b>{!! lang('patient.address') !!}</b></td>
                                                <td colspan="5">{!! $result->address !!}</td>
                                            </tr>
                                        </table>
                                    </div>

                                    <div class="col-md-12">
                                        <h2>
                                            1. Examination
                                        </h2>
                                        

                                        <table class="table table-bordered">
                                            <tr>
                                                <td width="15%"><b>{!! lang('opd_master.complaints') !!}</b></td>
                                                <td colspan="5">{!! nl2br($result->complaints) !!}</td>
                                            </tr>
                                            <tr>
                                                <td><b>{!! lang('opd_master.pulse_rate') !!}</b></td>
                                                <td>{!! nl2br($result->pulse_rate) !!}</td>
                                                <td><b>{!! lang('opd_master.blood_pressure') !!}</b></td>
                                                <td>{!! nl2br($result->blood_pressure) !!}</td>
                                                <td><b>{!! lang('opd_master.temperature') !!}</b></td>
                                                <td>{!! nl2br($result->temperature) !!}</td>
                                            </tr>
                                            <tr>
                                                <td><b>{!! lang('opd_master.examination') !!}</b></td>
                                                <td colspan="5">{!! nl2br(str_replace("###","\n",$result->examination)) !!}</td>
                                            </tr>
                                            <tr>
                                                <td><b>{!! lang('rog_type.rog_type') !!}</b></td>
                                                <td colspan="5">{!! $result->rog_type_text !!}</td>
                                            </tr>
                                        </table>{{--
                                        <div class="form-group clearfix">
                                            {!! Form::label('complaints', lang('opd_master.complaints'), array('class' => 'col-sm-2 control-label')) !!}
                                            <div class="col-sm-8">
                                                {!! nl2br($result->complaints) !!}
                                            </div>
                                        </div>

                                        <div class="form-group required">
                                            {!! Form::label('pulse_rate', lang('opd_master.pulse_rate'), array('class' => 'col-sm-2 control-label')) !!}
                                            <div class="col-sm-2">
                                                {!! $result->pulse_rate !!}
                                            </div>

                                            {!! Form::label('blood_pressure', lang('opd_master.blood_pressure'), array('class' => 'col-sm-1 control-label')) !!}
                                            <div class="col-sm-2">
                                                {!! $result->blood_pressure !!}
                                            </div>

                                            {!! Form::label('temperature', lang('opd_master.temperature'), array('class' => 'col-sm-1 control-label')) !!}
                                            <div class="col-sm-2">
                                                {!! $result->temperature !!}
                                            </div>
                                        </div>

                                        <div class="form-group clearfix">
                                            {!! Form::label('examination', lang('opd_master.examination'), array('class' => 'col-sm-2 control-label')) !!}
                                            <div class="col-sm-8">
                                                {!! nl2br($result->examination) !!}
                                            </div>
                                        </div>--}}

                                        {{--<div class="form-group required">
                                            {!! Form::label('rog_type', lang('rog_type.rog_type'), array('class' => 'col-sm-2 control-label')) !!}
                                            <div class="col-sm-2">
                                                {!! $result->rog_type !!}
                                            </div>
                                        </div>--}}
                                    </div>


                                    <div class="col-md-12">
                                        
                                        <h2>
                                            2. Investigations
                                        </h2>
                                        
                                        <div class="form-group">
                                            {!! Form::label('test_ids', lang('test.tests'), array('class' => 'col-sm-2 control-label')) !!}
                                            <div class="col-sm-5">
                                                {!! $result->tests !!}
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        
                                        <h2>
                                            3. Procedures
                                        </h2>
                                        
                                        <div class="col-md-8 clearfix">
                                            <div class="clearfix place-template">
                                                <table class="table table-bordered">
                                                    <tr>
                                                        <th><b>{!! lang('opd_master.procedure_date') !!}</b></th>
                                                        <th><b>{!! lang('opd_master.procedure') !!}</b></th>
                                                        <th><b>{!! lang('opd_master.medicine') !!}</b></th>
                                                        <th><b>{!! lang('opd_master.dose') !!}</b></th>
                                                        <th><b>{!! lang('opd_master.timing') !!}</b></th>
                                                        <th><b>{!! lang('opd_master.remarks') !!}</b></th>
                                                    </tr>
                                                    @foreach($pMedicines as $detail)
                                                        <tr>
                                                            <td>{!! dateFormat('d.m.Y', $detail->procedure_date) !!}</td>
                                                            <td>{!! $detail->procedure !!}</td>
                                                            <td>{!! $detail->medicine !!}</td>
                                                            <td>{!! $detail->dose !!}</td>
                                                            <td>{!! $detail->timing !!}</td>
                                                            <td>{!! $detail->remarks !!}</td>
                                                        </tr>
                                                    @endforeach
                                                </table>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        
                                        <h2>
                                            4. Medications
                                        </h2>
                                        
                                        <div class="col-md-8 clearfix">

                                            <table class="table table-bordered">
                                                <tr>
                                                    <th><b>{!! lang('opd_master.medicine') !!}</b></th>
                                                    <th><b>{!! lang('opd_master.dose') !!}</b></th>
                                                    <th><b>{!! lang('opd_master.dose_unit') !!}</b></th>
                                                    <th><b>{!! lang('opd_master.timing') !!}</b></th>
                                                    <th><b>{!! lang('opd_master.remarks') !!}</b></th>
                                                </tr>
                                                @foreach($mMedicines as $detail)
                                                    <tr>
                                                        <td>{!! $detail->medicine !!}</td>
                                                        <td>{!! $detail->dose !!}</td>
                                                        <td>{!! $detail->dose_unit !!}</td>
                                                        <td>{!! $detail->timing !!}</td>
                                                        <td>{!! $detail->remarks !!}</td>
                                                    </tr>
                                                @endforeach
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end: TEXT FIELDS PANEL -->
            </div>
        </div>    
    </div>
</div>
<!-- /#page-wrapper -->
@stop
