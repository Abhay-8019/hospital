@extends('layouts.admin')

@section('content_header')
	<section class="content-header">
		<h1>
			{!! lang('opd_master.list_procedures') !!}
			<?php $route = \Route::currentRouteName(); ?>
			<small>{!! lang('common.list_record') !!}</small>
		</h1>
	</section>
@stop

@section('content')
<div id="page-wrapper">
	{{-- for message rendering --}}
    @include('layouts.messages')
		<div class="col-md-12 padding0">
			{!! Form::open(array('method' => 'POST', 'route' => array($route), 'id' => 'ajaxForm')) !!}
			<div class="row">

				<div class="col-md-2 width150">
					<div class="form-group">
						{!! Form::label('p_type', "Procedure For", array('class' => 'control-label')) !!}
						<div class="control-label">
							{!! Form::radio('p_type', 1, true, array('class' => 'p_type')) !!} OPD &nbsp; &nbsp; &nbsp;
							{!! Form::radio('p_type', 2, false, array('class' => 'p_type')) !!} IPD
						</div>
					</div>
				</div>

				<div class="col-md-2 width125 date">
					<div class="form-group">
						{!! Form::label('from_date', lang('reports.from_date'), array('class' => 'control-label')) !!}
						{!! Form::text('from_date', null, array('class' => 'form-control date-picker from_date', 'placeholder' => lang('reports.from_date'))) !!}
					</div>
				</div>


				<div class="col-md-2 width125 date paddingleft0">
					<div class="form-group">
						{!! Form::label('to_date', lang('reports.to_date'), array('class' => 'control-label')) !!}
						{!! Form::text('to_date', null, array('class' => 'form-control date-picker to_date', 'placeholder' =>  lang('reports.to_date'))) !!}
					</div>
				</div>
				<div class="col-sm-3 margintop25 paddingleft0">
					<div class="form-group">
						{!! Form::hidden('form-search', 1) !!}
						{!! Form::hidden('report_type', 1) !!}
						{!! Form::submit(lang('reports.filter'), array('class' => 'btn btn-primary', 'title' => lang('reports.filter'))) !!}
						<a href="{!! route($route) !!}" class="btn btn-primary" title="{!! lang('reports.reset_filter') !!}"> {!! lang('reports.reset_filter') !!}</a>
					</div>
				</div>
			</div>
			{!! Form::close() !!}
		</div>
	<div class="row">
      <div class="col-md-12">
		<!-- start: BASIC TABLE PANEL -->
		<div class="panel panel-default" style="position: static;">
			<div class="panel-heading">
				<i class="fa fa-external-link-square"></i> &nbsp;
				{!! lang('opd_master.list_procedures') !!}
			</div>
			<div class="panel-body">
				<div class="col-md-3 text-right pull-right padding0 marginbottom10">
					{!! lang('common.per_page') !!}: {!! Form::select('name', ['20' => '20', '40' => '40', '100' => '100', '200' => '200', '300' => '300'], '20', ['id' => 'per-page']) !!}
				</div>
				<div class="col-md-3 padding0 marginbottom10">
					{!! Form::hidden('page', 'search') !!}
					{!! Form::hidden('_token', csrf_token()) !!}
					{!! Form::text('name', null, array('class' => 'form-control live-search', 'placeholder' => 'Search Procedure')) !!}
				</div>
				<?php $route = \Route::currentRouteName(); ?>
				<table id="paginate-load" data-route="{{ route($route) }}" class="table table-hover margin0 col-md-12 padding0">
				</table>
			</div>
		</div>
		<!-- end: BASIC TABLE PANEL -->
	   </div>	
	</div>	
</div>
<!-- /#page-wrapper -->
@stop
