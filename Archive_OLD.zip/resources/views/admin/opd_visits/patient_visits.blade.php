@extends('layouts.admin')

@section('content_header')
	<section class="content-header">
		<h1>
			{!! lang('opd_master.view_patient_visits') !!}
		</h1>
		<ol class="breadcrumb">
			<li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> {!! lang('common.back') !!}</a></li>
			<li class="active">{!! lang('opd_master.view_patient_visits') !!}</li>
		</ol>
	</section>
@stop

@section('content')
<div id="page-wrapper">

    <div class="row">

		<div class="col-md-12">
			<!-- start: BASIC TABLE PANEL -->
			<div class="panel panel-default" style="position: static;">
				<div class="panel-heading">
					<i class="fa fa-external-link-square"></i> &nbsp;
					{!! lang('opd_master.view_patient_visits') !!}
				</div>
				<div class="panel-body padding0">
					<div class="col-md-6 hidden marginbottom10">
						{!! Form::hidden('page', '1') !!}
					</div>
					<div id="p-report">
					<?php $json = ""; ?>
					<table id="paginate-loadggg" class="table table-bordered margin0 col-md-12 padding0 font-14">
						<thead>
						<tr>
							<th width="10%">{!! lang('#') !!}</th>
							<th width="15%">{!! lang('opd_master.visit_date') !!}</th>
							<th width="10%">{!! lang('opd_master.doctor') !!}</th>
						</tr>
						</thead>
						<tbody>
						@if(count($previousVisits) > 0)
							@foreach($previousVisits as $key => $detail)
								<tr>
									<td>
										<a href="{!! route('patient.opd-visit-print', $detail->id) !!}" title="View OPD slip">
											{!! $detail->id !!}
										</a>
									</td>
									<td>
										{!! dateFormat('d.m.Y h:i A', $detail->visit_date) !!}
									</td>
									<td> {!! $detail->doctor !!} </td>
								</tr>
							@endforeach
						@endif
						@if (count($previousVisits) < 1)
							<tr>
								<td class="text-center" colspan="6"> {!! lang('messages.no_data_found') !!} </td>
							</tr>
						@endif
						</tbody>
					</table>
					</div>
				</div>
			</div>
			<!-- end: BASIC TABLE PANEL -->
		</div>

	</div>	
</div>
<!-- /#page-wrapper -->
@stop
