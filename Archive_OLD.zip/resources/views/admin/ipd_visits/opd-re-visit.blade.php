@extends('layouts.admin')

@section('content_header')
	<section class="content-header">
		<h1>
			{!! lang('opd_master.opd_revisit') !!}
		</h1>
	</section>
@stop

@section('content')
<div id="page-wrapper">
	{{-- for message rendering --}}
    @include('layouts.messages')

	<div class="col-md-12 padding0">
		{!! Form::open(array('method' => 'POST', 'route' => array('patient.opd-re-visit'), 'id' => 'ajaxForm')) !!}
		<div class="row">

			<div class="col-md-2 date">
				<div class="form-group">
					{!! Form::label('patient_name', lang('patient.first_name'), array('class' => 'control-label')) !!}
					{!! Form::text('patient_name', null, array('class' => 'form-control', 'placeholder' => lang('patient.first_name'))) !!}
				</div>
			</div>

			<div class="col-md-2 paddingleft0">
				<div class="form-group">
					{!! Form::label('opd_number', lang('patient.opd_number'), array('class' => 'control-label')) !!}
					{!! Form::text('opd_number', null, array('class' => 'form-control', 'placeholder' =>  lang('patient.opd_number'))) !!}
				</div>
			</div>

			<div class="col-md-2 paddingleft0">
				<div class="form-group">
					{!! Form::label('mobile', lang('patient.mobile'), array('class' => 'control-label')) !!}
					{!! Form::text('mobile', null, array('class' => 'form-control', 'placeholder' =>  lang('patient.mobile'))) !!}
				</div>
			</div>

			<div class="col-md-3 paddingleft0">
				<div class="form-group">
					{!! Form::label('address', lang('patient.address'), array('class' => 'control-label')) !!}
					{!! Form::text('address', null, array('class' => 'form-control', 'placeholder' =>  lang('patient.address'))) !!}
				</div>
			</div>

			<div class="col-sm-3 margintop20">
				<div class="form-group">
					{!! Form::hidden('form-search', 1) !!}
					{!! Form::submit(lang('reports.filter'), array('class' => 'btn btn-primary', 'title' => lang('reports.filter'))) !!}
					<a href="{!! route('patient.opd-re-visit') !!}" class="btn btn-primary" title="{!! lang('reports.reset_filter') !!}"> {!! lang('reports.reset_filter') !!}</a>
				</div>
			</div>
		</div>
		{!! Form::close() !!}
	</div>

    <div class="row">

		<div class="col-md-12">
			<!-- start: BASIC TABLE PANEL -->
			<div class="panel panel-default" style="position: static;">
				<div class="panel-heading">
					<i class="fa fa-external-link-square"></i> &nbsp;
					{!! lang('opd_master.opd_revisit') !!}
				</div>
				<div class="panel-body padding0">
					<div class="col-md-6 hidden marginbottom10">
						{!! Form::hidden('page', '1') !!}
					</div>
					<div id="p-report">
					{!! Form::open(array('method' => 'POST', 'route' => array('patient.opd-re-visit'), 'id' => 'ajaxSave')) !!}
						<?php $json = ""; ?>
						<table id="paginate-load" data-params='{!! $json !!}' data-route="{{ route('patient.opd-re-visit') }}" class="table table-bordered clearfix margin0 col-md-12 padding0 font-14">
						</table>
						{!! Form::hidden('form-save', 1) !!}
					</div>
					{!! Form::close() !!}
				</div>
			</div>
			<!-- end: BASIC TABLE PANEL -->
		</div>

	</div>	
</div>
<!-- /#page-wrapper -->
@stop
