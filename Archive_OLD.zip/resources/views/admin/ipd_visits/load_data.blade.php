<thead>
<tr>
    <th width="10%">{!! lang('ipd_master.ipd_number') !!}</th>
    <th width="10%">{!! lang('ipd_master.visit_date') !!}</th>
    <th width="10%">{!! lang('patient.patient_code') !!}</th>
    <th width="10%">{!! lang('patient.first_name') !!}</th>
    <th width="8%">{!! lang('common.age') !!}</th>
    <th width="6%">{!! lang('common.gender') !!}</th>
    <th width="10%">{!! lang('common.mobile') !!}</th>
    <th class="text-center">{!! lang('common.action') !!}</th>
</tr>
</thead>
<tbody>
<?php
$index = 1;
$genderArr = lang('common.genderArray');
?>
@if(count($data) > 0)
    @foreach($data as $key => $detail)
        <tr>
            <td> {!! $detail->ipd_number !!} </td>
            <td>
                {!! dateFormat('d.m.Y', $detail->admission_date) !!}
            </td>
            <td>
                {!! $detail->patient_code !!}
            </td>
            <td>
                {!! $detail->first_name !!}
            </td>
            <td>{!! $detail->age !!} @if($detail->age) Years @endif </td>
            <td>@if($detail->gender != '') {!! $genderArr[$detail->gender] !!} @endif </td>
            <td>{!! $detail->mobile !!}</td>
            <td class="text-center col-md-1">

                <a href="{!! route('patient.ipd-print', $detail->id) !!}" class="btn btn-xs btn-success"> <i class="fa fa-eye"></i> </a>
                @if($detail->is_discharged == 1)
                    <a href="{!! route('patient.ipd-discharge-summary', $detail->id) !!}" class="btn btn-xs btn-danger"> <i class="fa fa-print"></i> Discharge Summary </a>
                @endif
                @if($detail->is_discharged == 0)
                    <a class="btn btn-xs btn-primary" href="{!! route('patient.edit-ipd-entry', [$detail->id]) !!}"><i class="fa fa-edit"></i></a>
                    @if(isAdmin())
                        <a class="btn btn-xs btn-danger __drop" data-route="{!! route('patient.ipd-drop', [$detail->id]) !!}" data-message="{!! lang('messages.sure_delete', string_manip(lang('ipd_master.ipd_visit'))) !!}" href="javascript:void(0)"><i class="fa fa-times"></i></a>
                    @endif
                @endif
            </td>
        </tr>
    @endforeach
@endif
@if (count($data) < 1)
    <tr>
        <td class="text-center" colspan="6"> {!! lang('messages.no_data_found') !!} </td>
    </tr>
@endif
</tbody>