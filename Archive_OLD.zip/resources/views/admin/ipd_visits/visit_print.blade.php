@extends('layouts.admin')
@section('content_header')
<section class="content-header">
    <h1>
        <?php $route = \Route::currentRouteName(); ?>
        @if($route == 'patient.ipd-discharge-summary' && $result->is_discharged == 1)
            {!! lang('ipd_master.discharge_summary') !!}
        @else
            {!! lang('ipd_master.ipd_visit') !!}
            <small>{!! lang('common.view_heading', " Visit Detail") !!}</small>
        @endif
    </h1>
    <ol class="breadcrumb">
        <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> {!! lang('common.back') !!}</a></li>
        <li class="active">{!! lang('ipd_master.ipd_visit') !!}</li>
    </ol>
</section>
@stop
@section('content')
<div id="page-wrapper">
    <!-- start: PAGE CONTENT -->
    
    {{-- for message rendering --}}
    @include('layouts.messages')
    <div class="row">
        <div class="col-md-12 padding0">
            <!-- previous patient form id => patient-form -->
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading padding0">
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active">
                                <a href="#personal_tab" aria-controls="personal_tab" role="tab" data-toggle="tab">

                                    @if($route == 'patient.ipd-discharge-summary' && $result->is_discharged == 1)
                                        {!! lang('ipd_master.ipd_discharge_summary') !!}
                                    @else
                                        <i class="fa fa-external-link-square"></i>
                                        {!! lang('ipd_master.ipd_visit_detail') !!}
                                    @endif

                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <?php $linkCss = [asset('assets/css/bootstrap.min.css'),asset('assets/css/template.css')]; ?>
                            <a onclick="return reportPrint('p-report','{!! implode('|', $linkCss) !!}')" style="margin-right: 20px;" class="btn btn-success btn-sm pull-right marginbottom10">
                                &nbsp;<i class="fa fa-print"></i> {!! lang('common.print') !!} &nbsp;&nbsp;
                            </a>

                            @if($result->is_discharged == 0)
                                <a class="btn btn-sm btn-danger pull-right marginright10" href="{!! route('patient.ipd-discharge', $result->id) !!}">
                                    Discharge Patient
                                </a>
                            @endif

                            <div class="tab-content" id="p-report">

                                @include('layouts.template.college-name-head')

                                <div id="personal_tab" class="tab-pane fade in active">
                                    <?php
                                        $genderArr = lang('common.genderArray');
                                        $bloodGroupArr = lang('common.bloodGroupArr');
                                    ?>
                                    <div class="col-md-12">

                                        <h1 class="h-size">
                                            @if($route != 'patient.ipd-discharge-summary')
                                                Patient Detail
                                            @else <br/>
                                                <center>DISCHARGE SUMMARY</center>
                                            @endif
                                        </h1>
                                        <hr/>
                                        <table class="table table-bordered">
                                            <tr>
                                                <td><b>{!! lang('patient.patient_code') !!}</b></td>
                                                <td>{!! $patient->patient_code !!}</td>
                                                
                                                <td width="15%"><b>{!! lang('patient.first_name') !!}</b></td>
                                                <td width="18%">{!! $patient->first_name !!}</td>
                                                <td width="15%"><b>{!! lang('doctor.doctor') !!}</b></td>
                                                <td width="18%">{!! $result->doctor !!} </td>
                                            </tr>

                                            <tr>
                                                
                                                <td width="15%"><b>{!! lang('ipd_master.ipd_number') !!}</b></td>
                                                <td>{!! $result->ipd_number !!}</td>
                                                
                                                <td><b>{!! lang('department.department') !!}</b></td>
                                                <td>
                                                    {!! $result->department !!}
                                                </td>
                                                <td><b>{!! lang('ipd_master.visit_date') !!}</b></td>
                                                <td>
                                                    {!! dateFormat('d.m.Y', $result->admission_date) !!}
                                                </td>
                                            </tr>
                                            <tr>
                                                <td><b>{!! lang('patient.age') !!}</b>/<b>{!! lang('patient.gender') !!}</b></td>
                                                <td>{!! $patient->age !!} @if($patient->age) Years @endif  / @if($patient->gender != '') {!! $genderArr[$patient->gender] !!} @endif</td>                                                
                                                <td><b>{!! lang('ward.ward') !!}</b></td>
                                                <td>
                                                    {!! $result->ward !!}
                                                </td>
                                                @if($route == 'patient.ipd-discharge-summary' && $result->is_discharged == 1)
                                                    <td>
                                                        <b>Discharge Date</b> <br/>
                                                        <b>Total Admitted Day(s)</b>
                                                    </td>
                                                    <td>
                                                        {!! dateFormat('d.m.Y h:i A', $result->discharge_date) !!} <br/>
                                                        <b>{!! daysDiff($result->admission_date, $result->discharge_date) !!} Day(s)</b>
                                                    </td>
                                                @else
                                                    <td><b> </b></td>
                                                    <td> </td>
                                                @endif
                                            </tr>
                                            <tr>
                                                <td><b>{!! lang('patient.blood_group') !!}</b></td>
                                                <td>{!! $patient->blood_group !!}</td>
                                                <td><b>{!! lang('bed_master.bed_master') !!} No</b></td>
                                                <td>
                                                    {!! $result->bed !!}
                                                </td>
                                                @if($route == 'patient.ipd-discharge-summary' && $result->is_discharged == 1)
                                                    <td><b>Discharge Type</b></td>
                                                    <td>{!! dischargeType($result->discharge_type) !!}</td>
                                                @else
                                                    <td><b> </b></td>
                                                    <td> </td>
                                                @endif
                                            </tr>
                                            <tr>
                                                <td><b>{!! lang('patient.address') !!}</b></td>
                                                <td colspan="3">{!! $patient->address !!}</td>
                                                @if($route == 'patient.ipd-discharge-summary' && $result->is_discharged == 1)
                                                    <td><b>Discharged Doctor</b></td>
                                                    <td>{!! $result->discharge_doctor !!}</td>
                                                @else
                                                    <td><b> </b></td>
                                                    <td> </td>
                                                @endif
                                            </tr>
                                        </table>
                                    </div>

                                    @if($route == 'patient.ipd-discharge-summary' && $result->is_discharged == 1)
                                        <div class="col-md-12">
                                            <table class="table table-bordered">
                                                <tr>
                                                    <td width="15%"><b>{!! lang('ipd_master.discharge_summary') !!}</b></td>
                                                    <td colspan="5">{!! nl2br($result->discharge_summary) !!}</td>
                                                </tr>
                                                <tr>
                                                    <td width="15%"><b>{!! lang('ipd_master.treatment_given') !!}</b></td>
                                                    <td colspan="5">{!! nl2br($result->treatment_given) !!}</td>
                                                </tr>
                                                <tr>
                                                    <td width="15%"><b>{!! lang('ipd_master.treatment_advised') !!}</b></td>
                                                    <td colspan="5">{!! nl2br($result->treatment_advised) !!}</td>
                                                </tr>
                                            </table>
                                        </div>
                                    @endif
                                    @if($route != 'patient.ipd-discharge-summary')
                                        <div class="col-md-12">
                                            <h1 class="h-size">
                                                1. Examination
                                            </h1>
                                            <hr/>

                                            <table class="table table-bordered">
                                                <tr>
                                                    <td width="15%"><b>{!! lang('ipd_master.present_illness') !!}</b></td>
                                                    <td colspan="5">{!! nl2br($result->present_illness) !!}</td>
                                                </tr>
                                                <tr>
                                                    <td width="15%"><b>{!! lang('ipd_master.previous_medical') !!}</b></td>
                                                    <td colspan="5">{!! nl2br($result->previous_medical) !!}</td>
                                                </tr>
                                                <tr>
                                                    <td width="15%"><b>{!! lang('ipd_master.family_history') !!}</b></td>
                                                    <td colspan="5">{!! nl2br($result->family_history) !!}</td>
                                                </tr>
                                                <tr>
                                                    <td><b>{!! lang('ipd_master.pulse_rate') !!}</b></td>
                                                    <td>{!! nl2br($result->pulse_rate) !!}</td>
                                                    <td><b>{!! lang('ipd_master.blood_pressure') !!}</b></td>
                                                    <td>{!! nl2br($result->blood_pressure) !!}</td>
                                                    <td><b>{!! lang('ipd_master.temperature') !!}</b></td>
                                                    <td>{!! nl2br($result->temperature) !!}</td>
                                                </tr>

                                                <tr>
                                                    <td><b>{!! lang('ipd_master.hr') !!}</b></td>
                                                    <td>{!! nl2br($result->hr) !!}</td>
                                                    <td><b>{!! lang('ipd_master.rr') !!}</b></td>
                                                    <td>{!! nl2br($result->rr) !!}</td>
                                                    <td>&nbsp;</td>
                                                    <td>&nbsp;</td>
                                                </tr>
                                                <tr style="display: none;">
                                                    <td><b>{!! lang('ipd_master.other_information') !!}</b></td>
                                                    <td colspan="5">{!! nl2br($result->other_information) !!}</td>
                                                </tr>
                                                <tr>
                                                    <td><b>{!! lang('ipd_master.general_examination') !!}</b></td>
                                                    <td colspan="5">{!! str_replace('###','<br>',$result->general_examination) !!}</td>
                                                </tr>
                                                @if($result->admission_date < '2020-01-15')
                                                <tr>
                                                    <td width="15%"><b>{!! lang('ipd_master.present_treatment') !!}</b></td>
                                                    <td colspan="5">{!! str_replace('###',"<br>",$result->present_treatment) !!}</td>
                                                </tr>
                                                @endif
                                                
                                            </table>
                                        </div>

                                        <div class="col-md-12">
                                            <hr/>
                                            <h1 class="h-size">
                                                2. Procedures
                                            </h1>
                                            <hr/>
                                            <div class="col-md-8 padding0 clearfix">
                                                <div class="clearfix place-template">
                                                    <table class="table table-bordered">
                                                        <tr>
                                                            <th><b>{!! lang('ipd_master.procedure_date') !!}</b></th>
                                                            <th><b>{!! lang('ipd_master.procedure') !!}</b></th>
                                                            <th><b>{!! lang('ipd_master.medicine') !!}</b></th>
                                                            <th><b>{!! lang('ipd_master.dose') !!}</b></th>
                                                            <th><b>{!! lang('ipd_master.timing') !!}</b></th>
                                                            <th><b>{!! lang('ipd_master.remarks') !!}</b></th>
                                                        </tr>
                                                        @foreach($pMedicines as $detail)
                                                            <tr>
                                                                <td>{!! dateFormat('d.m.Y', $detail->procedure_date) !!}</td>
                                                                <td>{!! $detail->procedure !!}</td>
                                                                <td>{!! $detail->medicine !!}</td>
                                                                <td>{!! $detail->dose !!}</td>
                                                                <td>{!! $detail->timing !!}</td>
                                                                <td>{!! $detail->remarks !!}</td>
                                                            </tr>
                                                        @endforeach
                                                    </table>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <hr/>
                                            <h1 class="h-size">
                                                3. Medications
                                            </h1>
                                            <hr/>
                                            <div class="col-md-8 padding0 clearfix">

                                                <table class="table table-bordered">
                                                    <tr>
                                                        <th><b>{!! lang('ipd_master.medicine') !!}</b></th>
                                                        <th><b>{!! lang('ipd_master.dose') !!}</b></th>
                                                        <th><b>{!! lang('ipd_master.dose_unit') !!}</b></th>
                                                        <th><b>{!! lang('ipd_master.timing') !!}</b></th>
                                                        <th><b>{!! lang('ipd_master.remarks') !!}</b></th>
                                                    </tr>
                                                    @foreach($mMedicines as $detail)
                                                        <tr>
                                                            <td>{!! $detail->medicine !!}</td>
                                                            <td>{!! $detail->dose !!}</td>
                                                            <td>{!! $detail->dose_unit !!}</td>
                                                            <td>{!! $detail->timing !!}</td>
                                                            <td>{!! $detail->remarks !!}</td>
                                                        </tr>
                                                    @endforeach
                                                </table>
                                            </div>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end: TEXT FIELDS PANEL -->
            </div>
        </div>    
    </div>
</div>
<!-- /#page-wrapper -->
@stop
