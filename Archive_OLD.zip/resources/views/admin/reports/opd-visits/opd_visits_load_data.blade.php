<thead>
@if (count($result) > 0)
    @if(!isset($inputs['staff-search']))
        <tr>
            <td colspan="9" class="print_hide">
                <?php $linkCss = [asset('assets/css/bootstrap.min.css'),asset('assets/css/template.css')]; ?>
                <a onclick="return reportPrint('p-report','{!! implode('|', $linkCss) !!}')" class="btn btn-success btn-xs pull-right marginbottom10">
                    &nbsp;<i class="fa fa-print"></i> {!! lang('common.print') !!} &nbsp;&nbsp;
                </a>
            </td>
        </tr>
    @endif
    {{--<tr class="no-hover">
        <td colspan="12">
            <h3 style="text-align:center;margin-bottom: 0px; margin-top: 0px;margin-bottom:0;  font-family: times new roman; text-transform: uppercase; font-size: 2.6em; font-weight: 900;"> {!! $company->company_name !!} </h3>
            <div style="text-align: center; font-size: 1.0em;margin: 0;">
                {!! $company->permanent_address !!},
                {!! $company->city . ' - ' . $company->pincode !!}<br>
                <div>
                    @if((!empty($company->email1))) Email: {!! $company->email1 !!} @endif
                    @if((!empty($company->mobile1))) <br/> Mobile: {!! $company->mobile1 !!}, @endif
                    @if((!empty($company->phone))) Phone: {!! $company->phone !!} @endif
                </div>
            </div>
        </td>
    </tr>--}}
    <tr class="no-hover">
        <td colspan="10">
        <div style="text-align: center;margin: 0;">
            <p style="font-size: 1.5em;margin:0;">
                    <b> <span style="text-decoration: underline;"> OPD Visits </span> </b>
            </p>
            @if(!isset($inputs['staff-search']))
                <p style="font-size: 1.2em;margin:0;">
                <span style="font-weight: bold;">

                    @if($doctorName != "")
                        Doctor Wise: "{!! $doctorName !!}"
                    @endif

                    @if($departmentName != "")
                        Department Wise: "{!! $departmentName !!}"
                    @endif

                    @if($patientName != "")
                        Patient Wise: "{!! $patientName !!}"
                    @endif
                    <br/>
                    @if($inputs['report_type'] == 1 && isset($inputs['from_date']) && isset($inputs['to_date']))
                        (Dated: {!! dateFormat('d.m.Y', $inputs['from_date']) !!} - {!! dateFormat('d.m.Y', $inputs['to_date']) !!})
                    @elseif($inputs['report_type'] == 2)
                        (for the month of {!! getMonths($inputs['month']) !!})
                    @endif
                </span>
            </p>
            @endif
        </div>
    </td>
    </tr>
@endif
@if(count($result) > 0 && isAdmin())
        <tr>
        <th></th>    
        <th colspan=9><h2>Summary</h2></th>
    </tr>

    <tr>
        <th></th>
        <th>Department</th>
        <th colspan=8>Visits (Old + New = Total) <?php $gt=0; ?></th>
    </tr>   
            @foreach($summary as $key => $detail)
    <tr>
        <td></td>
        <td>{!! $detail->department !!} </td>
        <td colspan="8">{!! $detail->oldp !!} + {!! $detail->newp !!} = <span class="label label-success"> {!! $total = $detail->oldp + $detail->newp !!} <?php $gt += $total; ?></span></td>
    </tr>        
        @endforeach  
    <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>

        <td colspan="8"><span class="label label-danger">Total = <?php echo $gt; ?></span></td>
    </tr>     

@endif
<tr>
    <th width="2%">#</th>
    <th width="10%">{!! lang('opd_master.visit_date') !!}</th>
    <th width="10%">{!! lang('patient.patient_code') !!}</th>
    <th width="10%">{!! lang('opd_master.opd_number') !!}</th>
    <th width="10%">{!! lang('patient.first_name') !!}</th>
    <th width="8%">{!! lang('common.age') !!}</th>
    <th width="6%">{!! lang('common.gender') !!}</th>
    <th width="10%">{!! lang('common.mobile') !!}</th>
    <th width="10%">{!! lang('doctor.doctor') !!}</th>
    <th width="10%">{!! lang('department.department') !!}</th>

    @if(isset($inputs['staff-search']))
        <th width="10%">{!! lang('common.action') !!}</th>
    @endif
</tr>
</thead>

<tbody>
<?php $index = 1; $genderArr = lang('common.genderArray'); ?>
@if(count($result) > 0)
    @foreach($result as $key => $detail)
        <tr>
            <td>{!! $index++ !!} </td>
            <td>
                {!! dateFormat('d.m.Y', $detail->visit_date) !!}
            </td>
            <td> {!! $detail->patient_id !!} </td>
            <td> {!! $detail->opd_number !!} </td>
            <td>
                {!! $detail->patient !!}
            </td>
            <td>{!! $detail->age !!} @if($detail->age) Years @endif </td>
            <td>@if($detail->gender != '') {!! $genderArr[$detail->gender] !!} @endif </td>
            <td>{!! $detail->mobile !!}</td>
            <td>
                {!! $detail->doctor !!}
            </td>
            <td>
                {!! $detail->department !!}
            </td>
            
            @if(isset($inputs['staff-search']))
                <td>
                    <a href="{!! route('patient.opd-procedure-visit', $detail->id) !!}" target="_blank" class="btn btn-xs btn-success"> <i class="fa fa-eye"></i> </a>
                </td>
            @endif
        </tr>
    @endforeach
@endif
@if (count($result) < 1)
    <tr>
        <td class="text-center" colspan="8"> {!! lang('messages.no_data_found') !!} </td>
    </tr>
@endif
</tbody>