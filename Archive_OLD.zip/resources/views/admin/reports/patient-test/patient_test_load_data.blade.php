<thead>
@if (count($result) > 0)

    <tr>
        <td colspan="8" class="print_hide">
            <?php $linkCss = [asset('assets/css/bootstrap.min.css'),asset('assets/css/template.css')]; ?>
            <a onclick="return reportPrint('p-report','{!! implode('|', $linkCss) !!}')" class="btn btn-success btn-xs pull-right marginbottom10">
                &nbsp;<i class="fa fa-print"></i> {!! lang('common.print') !!} &nbsp;&nbsp;
            </a>
        </td>
    </tr>


    <tr class="no-hover">
        <td colspan="8">
        <div style="text-align: center;margin: 0;">
            <p style="font-size: 1.5em;margin:0;">
                    <b> <span style="text-decoration: underline;"> Patient Tests Summary </span> </b>
            </p>
            <p style="font-size: 1.2em;margin:0;">
                <span style="font-weight: bold;">
                    @if($doctorName != "")
                        Doctor Wise: "{!! $doctorName !!}" <br/>
                    @endif

                    @if($departmentName != "")
                        Department Wise: "{!! $departmentName !!}" <br/>
                    @endif

                    @if(isset($inputs['report_type']) && $inputs['report_type'] == 1 && isset($inputs['from_date']) && isset($inputs['to_date']))
                        (Dated: {!! dateFormat('d.m.Y', $inputs['from_date']) !!} - {!! dateFormat('d.m.Y', $inputs['to_date']) !!})
                    @elseif(isset($inputs['report_type']) && $inputs['report_type'] == 2)
                        (for the month of {!! getMonths($inputs['month']) !!})
                    @endif
                </span>
            </p>
        </div>
    </td>
    </tr>
@endif
<tr>
    <th width="5%" class="text-center">{!! "Sr. No" !!}</th>
    <th width="10%" >{!! lang('patient_test.receipt_no') !!}</th>
    <th>{!! lang('patient_test.test_date') !!}</th>
    <th>{!! lang('patient.first_name') !!}</th>
    <th>{!! lang('doctor.doctor') !!}</th>
    <th>{!! lang('department.department') !!}</th>
    <th>{!! lang('patient_test.amount') !!}</th>
</tr>
</thead>
<tbody>
<?php $index = 1; $total = 0; ?>
@if(count($result) > 0)
    @foreach($result as $key => $detail)
        <tr id="order_{{ $detail->id }}">
            <td class="text-center">{!! $index++ !!}</td>
            <td>
                {!!  lang('patient_test.rcpt') . $detail->receipt_no !!}
            </td>
            <td>{!! dateFormat('d M, Y', $detail->test_date) !!}</td>
            <td>{!! $detail->first_name !!} @if($detail->age != "") ({!! $detail->age !!} Y) @endif</td>
            <td>{!! $detail->doctor !!}</td>
            <td>{!! $detail->department !!}</td>
            <td>{!! numberFormat($detail->total) !!}</td>
            <?php $total += $detail->total; ?>
        </tr>
    @endforeach
    <tr>
        <td colspan="6" style="font-size: 20px;text-align: right;">
            <strong>Total Amount:</strong>
        </td>
        <td style="font-size: 20px;">
            <strong>{!! numberFormat($total) !!}</strong>
        </td>
    </tr>
@endif
@if (count($result) < 1)
    <tr>
        <td class="text-center" colspan="8"> {!! lang('messages.no_data_found') !!} </td>
    </tr>
@endif
</tbody>