<thead>
@if (count($result) > 0)
    @if(!isset($inputs['staff-search']))
        <tr>
            <td colspan="8" class="print_hide">
                <?php $linkCss = [asset('assets/css/bootstrap.min.css'),asset('assets/css/template.css')]; ?>
                <a onclick="return reportPrint('p-report','{!! implode('|', $linkCss) !!}')" class="btn btn-success btn-xs pull-right marginbottom10">
                    &nbsp;<i class="fa fa-print"></i> {!! lang('common.print') !!} &nbsp;&nbsp;
                </a>
            </td>
        </tr>
    @endif
    {{--<tr class="no-hover">
        <td colspan="10">
            <h3 style="text-align:center;margin-bottom: 0px; margin-top: 0px;margin-bottom:0;  font-family: times new roman; text-transform: uppercase; font-size: 2.6em; font-weight: 900;"> {!! $company->company_name !!} </h3>
            <div style="text-align: center; font-size: 1.0em;margin: 0;">
                {!! $company->permanent_address !!},
                {!! $company->city . ' - ' . $company->pincode !!}<br>
                <div>
                    @if((!empty($company->email1))) Email: {!! $company->email1 !!} @endif
                    @if((!empty($company->mobile1))) <br/> Mobile: {!! $company->mobile1 !!}, @endif
                    @if((!empty($company->phone))) Phone: {!! $company->phone !!} @endif
                </div>
            </div>
        </td>
    </tr>--}}
    <tr class="no-hover">
        <td colspan="8">
        <div style="text-align: center;margin: 0;">
            <p style="font-size: 1.5em;margin:0;">
                    <b> <span style="text-decoration: underline;"> Department Wise Bed Occupancy </span> </b>
            </p>
            @if(!isset($inputs['staff-search']))
                <p style="font-size: 1.2em;margin:0;">
                <span style="font-weight: bold;">
                    <br/>
                    @if($inputs['report_type'] == 1 && isset($inputs['from_date']) && isset($inputs['to_date']))
                        (Dated: {!! dateFormat('d.m.Y', $inputs['from_date']) !!} - {!! dateFormat('d.m.Y', $inputs['to_date']) !!})
                    @elseif($inputs['report_type'] == 2)
                        (for the month of {!! getMonths($inputs['month']) !!})
                    @endif
                </span>
            </p>
            @endif
        </div>
    </td>
    </tr>
@endif
<tr>
    <th width="10%">{!! lang('department.department') !!}</th>
    <th width="10%">{!! lang('ipd_master.occupied') !!}</th>
    <th width="10%">{!! lang('ipd_master.discharged') !!}</th>
    <th width="10%">{!! lang('ipd_master.bed_occupancy') !!}</th>    
</tr>
</thead>
<tbody>
<?php $index = 1; $atotal=$dtotal=$btotal=0;?>
@if(count($result) > 0)
    @foreach($result as $key => $detail)
        <tr>
            <td>
                {!! $key !!}
            </td>
            <td>
                {!! $detail->occupied !!}
            </td>
            <td>{!! $detail->discharged !!}</td>
            <td>{!! $detail->bo !!}</td>
            <?php 
            $atotal += $detail->occupied;
            $dtotal += $detail->discharged;
            $btotal += $detail->bo; ?>
        </tr>
    @endforeach
        <tr>
            <th>Total</th>
            <th>{!! $atotal !!}</th>
            <th>{!! $dtotal !!}</th>
            <th>{!! $btotal !!}</th>

        </tr>
        <tr>
            <?php $days = (strtotime($inputs['to_date']) - strtotime($inputs['from_date']))/86400 + 1; ?>
            <td colspan="4"> Total Days = {!! $days !!} , Bed Occupancy = {!!  round($btotal / $days,2) !!} % </td>
        </tr>
@endif

@if(count($detailedResult) > 0 && isset($inputs['show_details']) && $inputs['show_details']==1) 
    <tr>
        <th>Patient/Department</th>
        <th>Admission Date</th>
        <th>Discharge Date</th>
        <th>Bed Days in Time Range</th>
    </tr>
    <?php $sum = 0; ?>
    @foreach($detailedResult as $key => $detail)
        <tr>
            <td>{!! $detail->first_name !!} :: <b>({!! $detail->department !!})</b></td>
            <td>{!! $detail->admission_dt !!}</td>
            <td>{!! $detail->discharge_dt !!}</td>
            <td>{!! $detail->bedsinMonth !!}</td>
        </tr>
        <?php $sum+= $detail->bedsinMonth; ?>
    @endforeach
        <tr>
            <td colspan="2"></td>
            <td><b>Total</b></td>
            <td>{!! $sum !!}</td>
        </tr>
@endif

@if (count($result) < 1)
    <tr>
        <td class="text-center" colspan="8"> {!! lang('messages.no_data_found') !!} </td>
    </tr>
@endif
</tbody>