<thead>
@if (count($result) > 0)
    @if(!isset($inputs['staff-search']))
        <tr>
            <td colspan="8" class="print_hide">
                <?php $linkCss = [asset('assets/css/bootstrap.min.css'),asset('assets/css/template.css')]; ?>
                <a onclick="return reportPrint('p-report','{!! implode('|', $linkCss) !!}')" class="btn btn-success btn-xs pull-right marginbottom10">
                    &nbsp;<i class="fa fa-print"></i> {!! lang('common.print') !!} &nbsp;&nbsp;
                </a>
            </td>
        </tr>
    @endif
    {{--<tr class="no-hover">
        <td colspan="10">
            <h3 style="text-align:center;margin-bottom: 0px; margin-top: 0px;margin-bottom:0;  font-family: times new roman; text-transform: uppercase; font-size: 2.6em; font-weight: 900;"> {!! $company->company_name !!} </h3>
            <div style="text-align: center; font-size: 1.0em;margin: 0;">
                {!! $company->permanent_address !!},
                {!! $company->city . ' - ' . $company->pincode !!}<br>
                <div>
                    @if((!empty($company->email1))) Email: {!! $company->email1 !!} @endif
                    @if((!empty($company->mobile1))) <br/> Mobile: {!! $company->mobile1 !!}, @endif
                    @if((!empty($company->phone))) Phone: {!! $company->phone !!} @endif
                </div>
            </div>
        </td>
    </tr>--}}
    <tr class="no-hover">
        <td colspan="8">
        <div style="text-align: center;margin: 0;">
            <p style="font-size: 1.5em;margin:0;">
                    <b> <span style="text-decoration: underline;"> IPD Patients</span> </b>
            </p>
            @if(!isset($inputs['staff-search']))
                <p style="font-size: 1.2em;margin:0;">
                <span style="font-weight: bold;">

                    @if($doctorName != "")
                        Doctor Wise: "{!! $doctorName !!}"
                    @endif

                    @if($departmentName != "")
                        Department Wise: "{!! $departmentName !!}"
                    @endif

                    @if($patientName != "")
                        Patient Wise: "{!! $patientName !!}"
                    @endif
                    <br/>
                    @if($inputs['report_type'] == 1 && isset($inputs['from_date']) && isset($inputs['to_date']))
                        (Dated: {!! dateFormat('d.m.Y', $inputs['from_date']) !!} - {!! dateFormat('d.m.Y', $inputs['to_date']) !!})
                    @elseif($inputs['report_type'] == 2)
                        (for the month of {!! getMonths($inputs['month']) !!})
                    @endif
                </span>
            </p>
            @endif
        </div>
    </td>
    </tr>
@endif
<tr>
    <th width="1%">#</th>
    <th width="5%">{!! lang('ipd_master.visit_date') !!}</th>
    <th width="5%">{!! lang('patient.patient_code') !!}/<br>{!! lang('ipd_master.ipd_number') !!}</th>
    <th width="10%">{!! lang('patient.first_name') !!}</th>
    <th width="8%">{!! lang('common.age') !!}/{!! lang('common.gender') !!}</th>
    <th width="10%">{!! lang('doctor.doctor') !!}/{!! lang('department.department') !!}</th>
    <th width="10%">{!! lang('common.mobile') !!}</th>
    @if(isset($inputs['is_discharged']) && $inputs['is_discharged'] ==1)
        <th width="10%">{!! lang('ipd_master.discharge_date') !!}</th>
    @endif
    @if(isset($inputs['staff-search']))
        <th width="10%">{!! lang('common.action') !!}</th>
    @endif
</tr>
</thead>
<tbody>
<?php $index = 1; $genderArr = lang('common.genderArray'); ?>
@if(count($result) > 0)
    @foreach($result as $key => $detail)
        <tr>
            <td>{!! $index++ !!}</td>
            <td>{!! dateFormat('d.m.Y', $detail->admission_dt) !!}</td>
            @if(!isset($inputs['staff-search']))
            <td><a href="{!! route('patient.ipd-print', $detail->ipd_master_id   ) !!}" title="Show IPD Entries"> {!! $detail->ipd_number !!} </a></td>
            <td><a href="{!! route('patient.opd-visit-history', $detail->patient_id) !!}" title="Show OPD Visit History"> {!! $detail->first_name !!}</a></td>
            @else
            <td>P-{!! $detail->patient_id !!}/{!! $detail->ipd_number !!} </td>
            <td>{!! $detail->first_name !!}</td>
            @endif            
            <td>{!! $detail->age !!} @if($detail->age) @endif 
                @if($detail->gender != '') / {!! $genderArr[$detail->gender] !!} @endif </td>
            <td>{!! $detail->doctor !!} <span class="label label-success">{!! $detail->department !!}</span></td>                
            <td>{!! $detail->mobile !!}</td>
            @if(isset($inputs['is_discharged']) && $inputs['is_discharged'] ==1)
                <td width="10%"><a href="{!! route('patient.ipd-discharge-summary', $detail->ipd_master_id   ) !!}" title="Show Discharge Summary">{!! dateFormat('d.m.Y',$detail->discharge_date) !!}</a></td>
            @endif
            @if(isset($inputs['staff-search']))
                <td>
                    <a href="{!! route('patient.ipd-procedure-visit', $detail->ipd_master_id) !!}" target="_blank" class="btn btn-xs btn-success"> <i class="fa fa-eye"></i> </a>
                </td>
            @endif
        </tr>
    @endforeach
@endif

@if(count($summary) >0)
    <tr>
        <td colspan="13"><h3>Summary</h3></td>
    </tr>
    @foreach ($summary as $key => $value)
        <tr>
            <td colspan="13"> 
                {!! $value->department !!} : {!! $value->total !!}
            </td>
        </tr>            
    @endforeach
@endif




@if (count($result) < 1)
    <tr>
        <td class="text-center" colspan="8"> {!! lang('messages.no_data_found') !!} </td>
    </tr>
@endif
</tbody>