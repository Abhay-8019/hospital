@extends('layouts.admin')
@section('content_header')
    <section class="content-header">
        <h1>
            {!! lang('rog_type.rog_type') !!}
            <small>{!! lang('common.add_record') !!}</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> {!! lang('common.back') !!}</a></li>
            <li><a href="{!! route('rog-types.index') !!}">{!! lang('rog_type.rog_types') !!}</a></li>
            <li class="active">{!! lang('common.create_heading', lang('rog_type.rog_type')) !!}</li>
        </ol>
    </section>
@stop
@section('content')
{{-- for message rendering --}}
@include('layouts.messages')
<div class="row">
    <div class="col-md-12 col-lg-12 col-md-12 col-sm-12  padding0">
        @include('admin.rog-type.form_common')
    </div>
</div>
@stop