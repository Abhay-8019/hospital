@extends('layouts.admin')
@section('content_header')
    <section class="content-header">
        <h1>
            {!! lang('bed_master.bed_master') !!}
            <small>{!! lang('common.add_record') !!}</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="javascript:void(0)" class="_back"><i class="fa fa-arrow-left"></i> {!! lang('common.back') !!}</a></li>
            <li><a href="{!! route('beds.index') !!}">{!! lang('bed_master.bed_masters') !!}</a></li>
            <li class="active">{!! lang('common.create_heading', lang('bed_master.bed_master')) !!}</li>
        </ol>
    </section>
@stop
@section('content')
{{-- for message rendering --}}
@include('layouts.messages')
<div class="row">
    <div class="col-md-12 col-lg-12 col-md-12 col-sm-12  padding0">
        @include('admin.beds.form_common')
    </div>
</div>
@stop