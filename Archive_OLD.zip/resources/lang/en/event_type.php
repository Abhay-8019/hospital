<?php
/**
 * :: Event Type Language File ::
 * To manage Event Type related language phrases.
 *
 **/

return [

    'event_type_detail'         => 'Event Type Detail',
    'event_type'				=> 'Event Type',
    'event_types'				=> 'Event Types',
    'event_type_status'			=> 'Event Type Status',
    'event_type_list'			=> 'Event Type List',

];