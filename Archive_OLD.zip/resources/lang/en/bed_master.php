<?php 
/**
 * :: Bed Language File :: 
 * To manage bed_master related language phrases.
 *
 **/

return [

	'bed_master_detail'		=> 'Bed Detail',
	'bed_master'			=> 'Bed',
	'bed_masters'			=> 'Beds',
	'bed_master_status'		=> 'Bed Status',
	'bed_masters_list'		=> 'Beds List',
    'bed_master_in_use'     => 'Bed already in use',
	'add_bed_master'		=> 'Add Bed'
];