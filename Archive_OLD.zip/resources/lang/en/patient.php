<?php 
/**
 * :: Patient Language File ::
 * To manage patients related language phrases.
 *
 **/

return [

	'patient_detail'                                => 'Patient Detail',
	'patient'					                    => 'Patient',
	'patients'					                    => 'Patients',
	'patient_status'			                    => 'Patient Status',
	'patients_list'			                        => 'Patients List',
	'personal_detail'			                    => 'Personal Detail',
	'additional_detail'			                    => 'Additional Detail',
	'patient_code'			                        => 'Patient Code',
	'opd_id'										=> "OPD ID",
	'first_name'			                        => 'Patient Name',
	'last_name'			                            => 'Last Name',
	'user_name'			                            => 'User Name',
	'alternate_contact_no'		                    => 'Alternate Contact Number',
	'alternate_no'		                            => 'Alternate Number',
	'registration_date'		                        => 'Registration Date',
	'patient_code'		                            => 'Patient Code',
	'date_of_birth'		                            => 'Date Of Birth',
	'marital_status'		                        => 'Marital Status',
	'age'		                                    => 'Age',
	'blood_group'		                            => 'Blood Group',
	'gender'		                                => 'Gender',
	'relationship'		                            => 'Relationship',
	'address'		                                => 'Address',
	'city'		                                    => 'City',
	'state'		                                    => 'State',
	'zip_code'		                                => 'Zip Code',
	'country'		                                => 'Country',
	'please_fill_contact_no_along_std_code'		    => 'Please Fill Alternate Contact Number Along With STD Code',
	'please_fill_std_code_along_contact_no'		    => 'Please Fill STD Code Along With Alternate Contact Number',
	'in_patient'		                            => 'In Patient',
	'out_patient'		                            => 'Out Patient',
	'patient_type'		                            => 'Patient Type',
	'password'		                            	=> 'Password',
	'full_patient_detail'		                    => 'Full Patient Detail',
	'print_detail'		                   			=> 'Print Detail',
	'name'		                   					=> 'Name : ',
	'contact'		                   				=> 'Contact : ',
	'show_Age'		                   				=> 'Age : ',
	'show_Patient_code'		                        => 'Patient Code : ',
	'new_patient'									=> 'New Patient',
	'opd_number'									=> 'OPD Number',
	'opd_patient'									=> 'OPD Patient',
	'opd_patients'									=> 'OPD Patients',
	'opd_slip'										=> 'OPD Slip',
	'mobile'										=> 'Mobile',
	

];