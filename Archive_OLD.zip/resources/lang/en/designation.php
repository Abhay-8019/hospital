<?php 
/**
 * :: Designation Language File ::
 * To manage roles related language phrases.
 *
 **/

return [

	'designation_detail'        => 'Designation Detail',
	'designation'				=> 'Designation',
	'designations'				=> 'Designations',
	'designation_status'		=> 'Designation Status',
	'designation_list'			=> 'Designation List',
	'designation_code'			=> 'Designation Code',
	'designation_name'		    => 'Designation Name',

];