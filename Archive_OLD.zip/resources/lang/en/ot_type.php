<?php 
/**
 * :: OT Type Language File :: 
 * To manage ot_type related language phrases.
 *
 **/

return [

	'ot_type_detail'	=> 'OT Type Detail',
	'ot_type'			=> 'OT Type',
	'ot_types'			=> 'OT Types',
	'ot_type_status'	=> 'OT Type Status',
	'ot_types_list'		=> 'OT Types List',
    'ot_type_in_use'    => 'OT Type already in use',
	'add_ot_type'		=> 'Add OT Type'
];