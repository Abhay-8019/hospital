<?php 
/**
 * :: Patient Language File ::
 * To manage patients related language phrases.
 *
 **/

return [

	'doctor_detail'                                 => 'Doctor Detail',
	'doctor'					                    => 'Doctor',
	'doctors'					                    => 'Doctors',
	'doctor_status'			                        => 'Doctor Status',
	'registration_no'		                        => 'Registration No',
	'specialization'			               	    => 'Specialization',
	/*'doctors_list'			                        => 'Doctors List',*/
	'contact'										=> 'Contact',
	'duty'											=> 'Duty Type',
	/*'personal_detail'			                    => 'Personal Detail',*/
	'additional_detail'			                    => 'Additional Detail',
	/*'first_name'			                        => 'First Name',
	'last_name'			                            => 'Last Name',
	'user_name'			                            => 'User Name',*/
	/*'alternate_contact_no'		                    => 'Alternate Contact Number',
	'alternate_no'		                            => 'Alternate Number',
	'registration_date'		                        => 'Registration Date',*/
	/*'doctor_code'		                            => 'Doctor Code',*/
	'date_of_birth'		                            => 'Date Of Birth',
	'date_of_joining'		                        => 'Date Of Joining',
	'marital_status'		                        => 'Marital Status',
	'age'		                                    => 'Age',
	'qualification'		                            => 'Qualification',
	/*'relationship'		                            => 'Relationship',*/
	'address'		                                => 'Address',
	'city'		                                    => 'City',
	'state'		                                    => 'State',
	'zip_code'		                                => 'Zip Code',
	'country'		                                => 'Country',
	/*'please_fill_contact_no_along_std_code'		    => 'Please Fill Alternate Contact Number Along With STD CODE',
	'please_fill_std_code_along_contact_no'		    => 'Please Fill STD CODE Along With Alternate Contact Number',*/
	'doctor_type'		                            => 'Doctor Type',
	'department'									=> 'Department',
	'designation'									=> 'Designation',
	'fee'											=> 'Doctor Fees',
	'room_no'										=> 'Consultant Room',
	'days'											=> 'Days',
	'in_time'										=> 'Morning In Time',
	'out_time'										=> 'Morning Out Time',
	'outside_consulting_address'					=> 'Outside Consulting',
	'consulting_start'								=> 'Consulting Start',
	'consulting_end'								=> 'Consulting End',
	'outside_consulting_fee'						=> 'Outside Consulting Fee',
	'extra_fee'										=> 'Extra Fee',
	'doctor_image'									=> 'Doctor Image',
	'association'									=> 'Association',
	'specify'	   									=> 'Please Specify',
	'doctor_list'	   								=> 'Doctor List',
	'name'											=> 'Doctor Name',
	'eve_in_time'									=> 'Evening In Time',
	'eve_out_time'									=> 'Evening Out Time',
	'morning'										=> 'Morning',
	'evening'										=> 'Evening',

];