<?php
namespace App;
/**
 * :: Daily Procedure Visits Model ::
 * To manage Daily Procedure Visits CRUD operations
 *
 **/

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class DailyProcedureVisits extends Model
{
    use SoftDeletes;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'daily_procedure_history';

    /**
     * The attributes that are mass assignable.
     * @var array
     */
    protected $fillable = [
        'opd_master_id',
        'ipd_master_id',
        'patient_id',
        'doctor_id',
        'department_id',
        'procedure_id',
        'procedure_medicine_id',

        'procedure_held_date',
        'remarks',
        'created_by',
        'updated_by'
    ];

    /**
     * Method is used to validate roles
     * @param $inputs
     * @param int $id
     * @return \Response
     */
    public function validateAddProcedureVisit($inputs, $id = null)
    {
        //dd($inputs);
        if(isset($inputs['add_procedure']))
        {

            foreach($inputs['add_procedure'] as $key => $value)
            {
                $rules['add_procedure.'.$key] = 'required';
                $rules['procedure_remark.'.$key] = 'required';

                //dd($rules);

                $messages['add_procedure.'.$key.'.required'] = '* Required';
                $messages['procedure_remark.'.$key.'.required'] = '* Required';
            }

            return \Validator::make($inputs, $rules, $messages);
        }
    }

    /**
     * Method is used to save/update resource.
     *
     * @param   array $input
     * @param   int $id
     * @param bool $multiple
     * @return \Response
     */
    public function store($input, $id = null, $multiple = false)
    {
        if ($id) {
            return $this->find($id)->update($input);
        } else {
            if ($multiple) {
                return $this->insert($input);
            }
            return $this->create($input)->id;
        }
    }

    /**
     * Method is used to search news detail.
     *
     * @param array $search
     * @param int $skip
     * @param int $perPage
     * @return mixed
     */
    public function getProcedureVisits($search = [], $skip, $perPage)
    {
        $filter = 1; // default filter if no search
        $take = ((int)$perPage > 0) ? $perPage : 20;

        $fields = [
            'daily_procedure_history.*',
            'opd_master.opd_number',
            'ipd_master.ipd_number',
            'visit_date',
            'p.id as patient_id',
            'p.patient_code',
            'p.first_name',
            'p.email',
            'p.gender',
            'p.age',
            'p.address',
            'p.city',
            'p.zip_code',

            'department.name as department_name',
            'doctor.name as doctor_name',
            'proc.name as procedure_name'
        ];

        $orderEntity = 'daily_procedure_history.id';
        $orderAction = 'desc';

        //dd($search);

        if (is_array($search) && count($search) > 0)
        {
            $filter .= (array_key_exists('p_type', $search) && $search['p_type'] != "") ?
                " AND (daily_procedure_history.type = " . addslashes(trim($search['p_type'])) . ")" : "";

            $filter .= (array_key_exists('opd_id', $search) && $search['opd_id'] != "") ?
                " AND (opd_master.id = " . addslashes(trim($search['opd_id'])) . ")" : "";

            $filter .= (array_key_exists('doctor_id', $search) && $search['doctor_id'] != "") ?
                " AND (opd_master.doctor_id = " . addslashes(trim($search['doctor_id'])) . ")" : "";

            if((array_key_exists('from_date', $search) && $search['from_date'] != "")&&(array_key_exists('to_date', $search) && $search['to_date'] != "")) {
                $from = dateFormat("Y-m-d", $search['from_date'] . ' 00:00');  
                $to = dateFormat("Y-m-d", $search['to_date'] . ' 23:59');
            $filter .= " AND daily_procedure_history.procedure_held_date between '$from' AND '$to'";

            }
        }

        return $this->leftJoin('opd_master', 'opd_master.id', '=', 'daily_procedure_history.opd_master_id')
            ->leftJoin('ipd_master', 'ipd_master.id', '=', 'daily_procedure_history.ipd_master_id')
            ->leftJoin('patient_registration as p', 'p.id', '=', 'daily_procedure_history.patient_id')
            ->leftJoin('doctor', 'doctor.id', '=', 'daily_procedure_history.doctor_id')
            ->leftJoin('department', 'department.id', '=', 'daily_procedure_history.department_id')
            ->leftJoin('procedure_master as proc','daily_procedure_history.procedure_id', '=' , 'proc.id')
            ->whereRaw($filter)
            ->orderBy($orderEntity, $orderAction)
            ->skip($skip)->take($take)
            ->get($fields);
    }

    /**
     * @param array $search
     * @param $skip
     * @param $perPage
     * @return \Illuminate\Support\Collection
     */
    public function getProcedureVisitsByDepartment($search = [], $skip, $perPage)
    {
        $filter = 1; // default filter if no search
        $take = ((int)$perPage > 0) ? $perPage : 20;

        $fields = [
            'department.name as department_name',
            \DB::raw('count(*) as total')
        ];

        if (is_array($search) && count($search) > 0)
        {
            $filter .= (array_key_exists('p_type', $search) && $search['p_type'] != "") ?
                " AND (daily_procedure_history.type = " . addslashes(trim($search['p_type'])) . ")" : "";

            if((array_key_exists('from_date', $search) && $search['from_date'] != "")&&(array_key_exists('to_date', $search) && $search['to_date'] != "")) {
                $from = dateFormat("Y-m-d", $search['from_date'] . ' 00:00');  
                $to = dateFormat("Y-m-d", $search['to_date'] . ' 23:59');
                $filter .= " AND daily_procedure_history.procedure_held_date between '$from' AND '$to'";

            }
        }
        return $this->leftJoin('department', 'daily_procedure_history.department_id', '=', 'department.id')
                    ->whereRaw($filter)
                    ->groupBy('daily_procedure_history.department_id')
                    ->get($fields);
    }
  
    public function getProcedureVisitsByProcedure($search = [], $skip, $perPage)
    {
        $filter = 1; // default filter if no search
        $take = ((int)$perPage > 0) ? $perPage : 20;

        $fields = [
            'procedure_master.name as procedure_name',
            \DB::raw('count(*) as total')
        ];

        if (is_array($search) && count($search) > 0)
        {
            $filter .= (array_key_exists('p_type', $search) && $search['p_type'] != "") ?
                " AND (daily_procedure_history.type = " . addslashes(trim($search['p_type'])) . ")" : "";

            if((array_key_exists('from_date', $search) && $search['from_date'] != "")&&(array_key_exists('to_date', $search) && $search['to_date'] != "")) {
                $from = dateFormat("Y-m-d", $search['from_date'] . ' 00:00');  
                $to = dateFormat("Y-m-d", $search['to_date'] . ' 23:59');
                $filter .= " AND daily_procedure_history.procedure_held_date between '$from' AND '$to'";

            }
        }
        return $this->leftJoin('procedure_master', 'daily_procedure_history.procedure_id', '=', 'procedure_master.id')
                    ->whereRaw($filter)
                    ->groupBy('daily_procedure_history.procedure_id')
                    ->get($fields);
    }

    /**
     * Method is used to get total results.
     * @param array $search
     * @return mixed
     */
    public function totalProcedureVisits($search = null)
    {
        $filter = 1; // if no search add where

        // when search
        if (is_array($search) && count($search) > 0)
        {
            $filter .= (array_key_exists('p_type', $search) && $search['p_type'] != "") ?
                " AND (daily_procedure_history.type = " . addslashes(trim($search['p_type'])) . ")" : "";

            $filter .= (array_key_exists('opd_id', $search) && $search['opd_id'] != "") ?
                " AND (opd_master.id = " . addslashes(trim($search['opd_id'])) . ")" : "";

            $filter .= (array_key_exists('doctor_id', $search) && $search['doctor_id'] != "") ?
                " AND (opd_master.doctor_id = " . addslashes(trim($search['doctor_id'])) . ")" : "";
        }

        return $this->leftJoin('opd_master', 'opd_master.id', '=', 'daily_procedure_history.opd_master_id')
            ->leftJoin('patient_registration as p', 'p.id', '=', 'opd_master.patient_id')
            ->leftJoin('doctor', 'doctor.id', '=', 'opd_master.doctor_id')
            ->select(\DB::raw('count(*) as total'))
            ->whereRaw($filter)
            ->first();
    }

    /**
     * @param $id
     * @return bool|null
     * @throws \Exception
     */
    public function drop($id)
    {
        return $this->find($id)->delete();
    }
}