<?php
namespace App;
/**
 * :: Procedure Treatment Master Model ::
 * To manage Procedure Treatment Master CRUD operations
 *
 **/

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Response;

class OralMedicationMaster extends Model
{
    use SoftDeletes;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'oral_medicine_master';

    /**
     * The attributes that are mass assignable.
     * @var array
     */
    protected $fillable = [
        'opd_master_id',
        'medicine_id',
        'procedure_date',
        //'medicine_days',
        'dose',
        'dose_unit',
        'timing',
        'remarks',
        'is_active',
        'deleted_by',
    ];

    public $timestamps = false;

    /**
     * Method is used to save/update resource.
     *
     * @param   array $input
     * @param   int $id
     * @param bool $multiple
     * @return Response
     */
    public function store($input, $id = null, $multiple = false)
    {
        if ($id) {
            return $this->find($id)->update($input);
        } else {
            if($multiple) {
                return $this->insert($input);
            }
            return $this->create($input)->id;
        }
    }

    /**
     * Method is used to search news detail.
     *
     * @param array $search
     * @return mixed
     */
    public function getOPDOralMedicines($search = [])
    {
        $filter = 1; // default filter if no search

        $fields = [
            'oral_medicine_master.*',
            'product.product_name as medicine',
        ];

        $orderEntity = 'id';
        $orderAction = 'desc';

        if (is_array($search) && count($search) > 0)
        {
            $filter .= (array_key_exists('opd_id', $search) && $search['opd_id'] != "") ?
                " AND (oral_medicine_master.opd_master_id = " . addslashes(trim($search['opd_id'])) . ")" : "";
        }

        // dd($this
        //     ->leftJoin('product', 'product.id', 'oral_medicine_master.medicine_id')
        //     ->whereRaw($filter)
        //     ->orderBy($orderEntity, $orderAction)->toSql());
        return $this
            ->leftJoin('product', 'product.id', 'oral_medicine_master.medicine_id')
            ->whereRaw($filter)
            ->orderBy($orderEntity, $orderAction)
            ->get($fields);
    }

    /**
     * @param $pIds
     * @return bool
     */
    public function dropMedicines($mIds)
    {
        return $this->whereIn('id', $mIds)->update(['deleted_by' => authUserId(), 'deleted_at' => currentDate(true)]);
    }
}