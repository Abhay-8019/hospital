<?php

namespace App;

/**
 * :: DoctorRegistration Model ::
 * To manage DoctorRegistration CRUD operations
 *
 **/

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class DoctorRegistration extends Model
{
    use SoftDeletes;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'doctor_registration';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'hospital_id',
        'user_id',
        'designation_id',
        'doctor_code',
        'first_name',
        'last_name',
        'gender',
        'mobile',
        'alternate_contact_no',
        'email',
        'professional_detail',
        'education_detail',
        'speciality',
        'address',
        //'street',
        'city',
        'state',
        'zip_code',
        'country',
        'status',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    /**
     * Scope a query to only include active users.
     *
     * @param $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query)
    {
        return $query->where('status', 1);
    }

    /**
     * @param $query
     * @return null
     */
    public function scopeDoctorHospital($query)
    {
        return (!isSuperAdmin())?
            $query->where('doctor_registration.hospital_id', loggedInHospitalId()) : null;
    }
    /**
     * Method is used to validate roles
     *
     * @param $inputs
     * @param int $id
     * @return Response
     */
    public function validateDoctors($inputs, $id = null)
    {
        $inputs = array_filter($inputs);
        // validation rule
        $rules = ['first_name' => 'required'] ;
        if ($id) {
            $rules += [
                'doctor_code'          =>  'required|unique:doctor_registration,doctor_code,' . $id .',id,deleted_at,NULL,hospital_id,'.loggedInHospitalId(),
                'email'                 =>  'unique:doctor_registration,email,' . $id .',id,deleted_at,NULL,hospital_id,'.loggedInHospitalId(),
            ];

        } else {
            $rules += [
                'doctor_code'          =>  'required|unique:doctor_registration,doctor_code,NULL,id,deleted_at,NULL,hospital_id,'.loggedInHospitalId(),
                'email'                 =>  'email|unique:doctor_registration,email,NULL,id,deleted_at,NULL,hospital_id,'.loggedInHospitalId(),
                'status'                =>  'required',
            ];
        }
        if(isset($inputs['user_id']) && $inputs['user_id'] != '') {
            $rules['user_name'] = 'unique:users,username,'.$inputs['user_id'].',id,deleted_at,NULL';
        }else{
            $rules['user_name'] = 'unique:users,username,NULL,id,deleted_at,NULL';
        }

        $rules +=  [
            'mobile'                => 'required|min:10|numeric',
            'std_code'              => 'min:4|numeric',
            'alternate_contact_no'  => 'min:7|numeric',
            'registration_date'     => 'required|date',
            'date_of_birth'         => 'required|date',
            'age'                   => 'required|numeric',
            'zip_code'              => 'min:6|numeric',
        ];

        return \Validator::make($inputs, $rules);
    }

    /**
     * Method is used to save/update resource.
     *
     * @param   array $input
     * @param   int $id
     * @return  Response
     */
    public function store($input, $id = null)
    {
        if ($id) {
            return $this->find($id)->update($input);
        } else {
            return $this->create($input)->id;
        }
    }

    /**
     * @param null $code
     * @return mixed|string
     */
    public function getDoctorCode($code = null)
    {
        $result =  $this->doctorHospital()->where('doctor_code', $code)->first();
        if ($result) {
            $data =  $this->doctorHospital()->orderBy('id', 'desc')->take(1)->first(['doctor_code']);
        } else {
            $data =  $this->doctorHospital()->orderBy('id', 'desc')->take(1)->first(['doctor_code']);
        }

        if (count($data) == 0) {
            $number = 'P-01';
        } else {
            $number = number_inc($data->doctor_code); // new doctor_code increment by 1
        }
        return $number;
    }

    /**
     * Method is used to search news detail.
     *
     * @param array $search
     * @param int $skip
     * @param int $perPage
     *
     * @return mixed
     */
    public function getDoctors($search = null, $skip, $perPage)
    {
        $take = ((int)$perPage > 0) ? $perPage : 20;
        // default filter if no search
        $filter = 1;

        $fields = [
            'id',
            'hospital_id',
            'user_id',
            'doctor_code',
            'first_name',
            'last_name',
            'gender',
            'mobile',
            'alternate_contact_no',
            'email',
            'professional_detail',
            'education_detail',
            'designation_id',
            'speciality',
            'registration_date',
            'status',
        ];

        if (is_array($search) && count($search) > 0) {
            $partyName = (array_key_exists('keyword', $search)) ? " AND first_name LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' " : "";
            $filter .= $partyName;

            if (array_key_exists('keyword', $search)) {
                $filter .= " AND doctor_code like '%" . addslashes(trim($search['keyword'])) . "%'";
            }
        }

        return $this->whereRaw($filter)
            ->orderBy('id', 'DESC')->skip($skip)->take($take)->get($fields);
    }
    /**
     * Method is used to get total results.
     *
     * @param array $search
     *
     * @return mixed
     */
    public function totalDoctors($search = null)
    {
        $filter = 1; // if no search add where

        // when search
        if (is_array($search) && count($search) > 0) {
            $partyName = (array_key_exists('name', $search)) ? " AND first_name LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' " : "";
            $filter .= $partyName;

            if (array_key_exists('keyword', $search)) {
                $filter .= " AND doctor_code like '%" . addslashes(trim($search['keyword'])) . "%'";
            }
        }
        return $this->select(\DB::raw('count(*) as total'))
            ->whereRaw($filter)->first();
    }

    /**
     * @return mixed
     */
    public function getDoctorsService()
    {
        $result = $this->active()->pluck('name', 'id')->toArray();
        return ['' => '-Select Doctors-'] + $result;
    }

}
