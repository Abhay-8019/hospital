<?php

namespace App;

/**
 * :: PatientRegistration Model ::
 * To manage PatientRegistration CRUD operations
 *
 **/

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PatientRegistration extends Model
{

    use SoftDeletes;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'patient_registration';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'hospital_id',
        'user_id',
        'doctor_id',
        'dept_code',
        // 'ipd_number',
        'opd_id',
        'patient_code',
        'patient_type',
        'first_name',
        'last_name',
        'age',
        'date_of_birth',
        'gender',
        'blood_group',
        'marital_status',
        'relationship',
        'mobile',
        'alternate_contact_no',
        'email',
        'registration_date',
        'address',
        //'street',
        'city',
        'state',
        'zip_code',
        'country',
        'status',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    /**
     * Scope a query to only include active users.
     *
     * @param $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query)
    {
        return $query->where('status', 1);
    }

    /**
     * @param $query
     * @return null
     */
    public function scopePatientHospital($query)
    {
        return (!isSuperAdmin()) ?
            $query->where('patient_registration.hospital_id', loggedInHospitalId()) : null;
    }

    /**
     * Method is used to validate roles
     *
     * @param $inputs
     * @param int $id
     * @return Response
     */
    public function validatePatients($inputs, $id = null)
    {
        $inputs = array_filter($inputs);

        // validation rule
        $rules = [
            //'patient_type' => 'required',
            'first_name'   => 'required',
            'gender'   => 'required',
            'doctor_id'   => 'required',
            'department'  => 'required',
        ];

        if ($id) {
            $rules += [
                //'patient_code'          =>  'required|unique:patient_registration,patient_code,' . $id .',id,deleted_at,NULL,hospital_id,'.loggedInHospitalId(),
                'email' =>  'unique:patient_registration,email,' . $id .',id,deleted_at,NULL,hospital_id,'.loggedInHospitalId(),
            ];

        } else {
            $rules += [
                //'patient_code'          =>  'required|unique:patient_registration,patient_code,NULL,id,deleted_at,NULL,hospital_id,'.loggedInHospitalId(),
                'email' =>  'email|unique:patient_registration,email,NULL,id,deleted_at,NULL,hospital_id,'.loggedInHospitalId(),
                'status' =>  'required',
            ];
        }
        if(isset($inputs['user_id']) && $inputs['user_id'] != '') {
            $rules['user_name'] = 'unique:users,username,'.$inputs['user_id'].',id,deleted_at,NULL';
        }else{
            $rules['user_name'] = 'unique:users,username,NULL,id,deleted_at,NULL';
        }

        $rules +=  [
            'mobile'                => 'numeric|digits_between:7,11',
            //'std_code'              => 'numeric|digits_between:3,4',
            //'alternate_contact_no'  => 'numeric|digits_between:7,7',
            //'registration_date'     => 'required|date',
            //'date_of_birth'         => 'required|date',
            'age'                   => 'required|numeric',
            'zip_code'              => 'min:6|numeric',
        ];

        $messages = [
            'doctor_id.required' => 'The doctor field is required.',
            'mobile.digits_between'  => 'The mobile must be 10 digits.',
            'std_code.digits_between'  => 'The std code must be 4 digits.',
            'alternate_contact_no.digits_between'  => 'The contact no must be 7 digits.',
        ];

        return \Validator::make($inputs, $rules, $messages);
    }

    /**
     * Method is used to save/update resource.
     *
     * @param   array $input
     * @param   int $id
     * @return  Response
     */
    public function store($input, $id = null)
    {
        if ($id) {
            return $this->find($id)->update($input);
        } else {
            return $this->create($input)->id;
        }
    }

    /**\
     * @param null $code
     * @return mixed|string
     */
    public function getPatientCode($code = null)
    {
        $result =  $this->patientHospital()->where('patient_code', $code)->first();

        

        if ($result) {
            $data =  $this->patientHospital()->orderBy('id', 'desc')->take(1)->first(['patient_code']);
        } else {
            $data =  $this->patientHospital()->orderBy('id', 'desc')->take(1)->first(['patient_code']);
        }
        if (count($data) == 0) {
            $number = 'P-01';
        } else {
            $number = number_inc($data->patient_code); // new patient_code increment by 1
        }
        return $number;
    }

    /**
     * Method is used to search news detail.
     *
     * @param array $search
     * @param int $skip
     * @param int $perPage
     *
     * @return mixed
     */
    public function getPatients($search = null, $skip, $perPage)
    {
        $take = ((int)$perPage > 0) ? $perPage : 20;
        // default filter if no search
        $filter = 1;
        $fields = [
            'id',
            //'user_id',
            //'ipd_number',
            'patient_code',
            'first_name',
            'last_name',
            'age',
            'gender',
            'blood_group',
            'marital_status',
            'relationship',
            'mobile',
            'alternate_contact_no',
            'email',
            'registration_date',
            'status',
        ];
        
        if (is_array($search) && count($search) > 0)
        {
            $filter .= (array_key_exists('keyword', $search) && $search['keyword'] != "") ? " AND (first_name LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' OR mobile LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' OR ipd_number LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' OR address LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' OR city LIKE '%" .
                addslashes(trim($search['keyword'])) . "%') " : "";

            $filter .= (array_key_exists('patient_name', $search) && $search['patient_name'] != "") ?
                " AND (first_name LIKE '%" . addslashes(trim($search['patient_name'])) . "%') " : "";

            $filter .= (array_key_exists('patient_code', $search) && $search['patient_code'] != "") ?
                " AND (patient_code LIKE '%" . addslashes(trim($search['patient_code'])) . "%') " : "";

            $filter .= (array_key_exists('opd_number', $search) && $search['opd_number'] != "") ?
                " AND (ipd_number LIKE '%" . addslashes(trim($search['opd_number'])) . "%') " : "";

            $filter .= (array_key_exists('opd_id', $search) && $search['opd_id'] != "") ?
                " AND (opd_id LIKE '%" . addslashes(trim($search['opd_id'])) . "%') " : "";

            $filter .= (array_key_exists('mobile', $search) && $search['mobile'] != "") ?
                " AND (mobile LIKE '%" . addslashes(trim($search['mobile'])) . "%') " : "";

            $filter .= (array_key_exists('address', $search) && $search['address'] != "") ?
                " AND (address LIKE '%" . addslashes(trim($search['address'])) . "%') " : "";
        }

        // $sql = $this->whereRaw($filter)->where('patient_registration.hospital_id', loggedInHospitalId())->orderBy('id', 'DESC')->skip($skip)->take($take)->toSql();

        //dd($sql);
        //dd($this->whereRaw($filter)->where('patient_registration.hospital_id', loggedInHospitalId())->orderBy('id', 'DESC')->skip($skip)->take($take)->get($fields));

        return $this->whereRaw($filter)
            ->where('patient_registration.hospital_id', loggedInHospitalId())
            ->orderBy('id', 'DESC')
            ->skip($skip)->take($take)->get($fields);
    }

    /**
     * Method is used to get total results.
     *
     * @param array $search
     *
     * @return mixed
     */
    public function totalPatients($search = null)
    {
        $filter = 1; // if no search add where

        // when search
        if (is_array($search) && count($search) > 0)
        {
            $filter .= (array_key_exists('keyword', $search) && $search['keyword'] != "") ? " AND (first_name LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' OR mobile LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' OR ipd_number LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' OR address LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' OR city LIKE '%" .
                addslashes(trim($search['keyword'])) . "%') " : "";

            $filter .= (array_key_exists('patient_name', $search) && $search['patient_name'] != "") ?
                " AND (first_name LIKE '%" . addslashes(trim($search['patient_name'])) . "%') " : "";

            $filter .= (array_key_exists('opd_number', $search) && $search['opd_number'] != "") ?
                " AND (ipd_number LIKE '%" . addslashes(trim($search['opd_number'])) . "%') " : "";

            $filter .= (array_key_exists('mobile', $search) && $search['mobile'] != "") ?
                " AND (mobile LIKE '%" . addslashes(trim($search['mobile'])) . "%') " : "";

            $filter .= (array_key_exists('address', $search) && $search['address'] != "") ?
                " AND (address LIKE '%" . addslashes(trim($search['address'])) . "%') " : "";

            if (array_key_exists('keyword', $search) && $search['keyword'] != "") {
                $filter .= " AND patient_code like '%" . addslashes(trim($search['keyword'])) . "%'";
            }
        }
        return $this->select(\DB::raw('count(*) as total'))
            ->whereRaw($filter)->first();
    }

    /**
     * @return mixed
     */
    public function getPatientsService()
    {
        $result = $this->active()
            ->patientHospital()
            ->pluck('first_name', 'id')->toArray();
        return ['' => '-Select Patients-'] + $result;
    }

    /**
     * @param $id
     * @return mixed
     */
    public function getPatientDetail($id)
    {
        return $this->find($id);
    }

    /**
     * @param array $search
     * @return \Illuminate\Support\Collection
     */
    public function filterPatients($search = [])
    {
        $filter = 1;

        $fields = [
            'id',
            //'user_id',
            //'ipd_number',
            'patient_code',
            'first_name',
            'last_name',
            'age',
            'gender',
            'blood_group',
            'marital_status',
            'relationship',
            'mobile',
            'alternate_contact_no',
            'email',
            'registration_date',
            'status',
        ];

        if (is_array($search) && count($search) > 0 && isset($search['form-search']))
        {
            $filter .= (array_key_exists('keyword', $search) && $search['keyword'] != "") ? " AND (first_name LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' OR mobile LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' OR ipd_number LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' OR address LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' OR city LIKE '%" .
                addslashes(trim($search['keyword'])) . "%') " : "";

            $filter .= (array_key_exists('patient_name', $search) && $search['patient_name'] != "") ?
                " AND (first_name LIKE '%" . addslashes(trim($search['patient_name'])) . "%') " : "";
            
            $filter .= (array_key_exists('opd_number', $search) && $search['opd_number'] != "") ?
                " AND (ipd_number LIKE '%" . addslashes(trim($search['opd_number'])) . "%') " : "";
            
            $filter .= (array_key_exists('mobile', $search) && $search['mobile'] != "") ?
                " AND (mobile LIKE '%" . addslashes(trim($search['mobile'])) . "%') " : "";
            
            $filter .= (array_key_exists('address', $search) && $search['address'] != "") ?
                " AND (address LIKE '%" . addslashes(trim($search['address'])) . "%') " : "";

            return $this->whereRaw($filter)
                ->where('patient_registration.hospital_id', loggedInHospitalId())
                ->orderBy('first_name', 'ASC')
                ->get($fields);
        }
        return null;
    }

    /**
     * @param array $search
     * @return array
     */
    public function getPatientAjax($search = [])
    {
        $result = $this->filterPatients($search);
        $json = [];
        foreach ($result as $key => $value) {
            $json[] = [
                'id' => $value->id,
                'text' => $value->patient_code . ' --> ' . $value->first_name . ' (' . $value->age . ' Y)',
            ];
        }
        return $json;
    }
}
