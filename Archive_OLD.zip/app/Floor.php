<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Floor extends Model
{
    use SoftDeletes;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'floor';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'hospital_id',
        'building_id',
        'code',
        'name',
        'total_rooms',
        'status',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    /**
     * @param $query
     * @return mixed
     */
    public function scopeActive($query)
    {
        return $query->where(['status' => 1]);
    }

    /**
     * @param $query
     * @return null
     */
    public function scopeFloorHospital($query)
    {
        return (!isSuperAdmin())?
            $query->where('floor.hospital_id', loggedInHospitalId()) : null;
    }

    /**
     * @param null $code
     * @return mixed|string
     */
    public function getFloorCode($code = null)
    {
        $result =  $this->active()->floorHospital()->where('code', $code)->first();
        if ($result) {
            $data =  $this->active()->floorHospital()->orderBy('id', 'desc')->take(1)->first(['code']);
        } else {
            $data =  $this->active()->floorHospital()->orderBy('id', 'desc')->take(1)->first(['code']);
        }

        if (count($data) == 0) {
            $number = 'F-01';
        } else {
            $number = number_inc($data->code); // new code increment by 1
        }
        return $number;
    }

    /**
     * @return array
     */
    public function getFloorName()
    {
        $result = $this->active()->floorHospital()
            ->pluck('name', 'id')->toArray();
        return ['' => '-- Select Floor Acc. to building --'] + $result;
    }

    /**
     * @param $inputs
     * @param null $id
     * @return mixed
     */
    public function validateFloor($inputs, $id = null, $isArray = false)
    {
        $inputs = array_filter($inputs);
        // validation rule
        $message = [];
        if($isArray) {
            if(isset($inputs['name']) && isset($inputs['total_rooms']))
            {
                foreach($inputs['name'] as $key => $value)
                {
                    $message = [
                        'name required'            => lang('messages.product_required'),
                        'total_rooms required'     => lang('messages.quantity_required'),

                    ];
                    $rules['code.'.   $key]       = 'required:floor,code,NULL,id,deleted_at,NULL,hospital_id,'.loggedInHospitalId();
                    $rules['name.'. $key]         = 'required:floor,name,NULL,id,deleted_at,NULL,hospital_id,'.loggedInHospitalId();
                    $rules['total_rooms.'. $key]  = 'required|numeric';
                }
            }
        }else {
            if ($id) {
                $rules['name'] = 'required:floor,name,' . $id .',id,deleted_at,NULL,hospital_id,'.loggedInHospitalId();
                $rules['code'] = 'required:floor,code,' . $id .',id,deleted_at,NULL,hospital_id,'.loggedInHospitalId();
            } else {
                $rules['name'] = 'required:floor,name,NULL,id,deleted_at,NULL,hospital_id,'.loggedInHospitalId();
                $rules['code'] = 'required:floor,code,NULL,id,deleted_at,NULL,hospital_id,'.loggedInHospitalId();
            }
            $rules['building_name'] = "required";
            $rules['total_rooms'] = "required|numeric";
        }

        return \Validator::make($inputs, $rules, $message);
    }

    /**
     * @param $input
     * @param null $id
     * @return bool|mixed
     */
    public function store($input, $id = null, $isMultiple = false)
    {
        if ($id) {
            return $this->find($id)->update($input);
        } else {
            if($isMultiple){
                return $this->insert($input);
            }else{
                return $this->create($input)->id;
            }
        }
    }

    /**
     * @param null $search
     * @param $skip
     * @param $perPage
     * @return \Illuminate\Support\Collection
     */
    public function getFloor($search = null, $skip, $perPage)
    {
        $take = ((int)$perPage > 0) ? $perPage : 20;
        // default filter if no search
        $filter = 1;

        $fields = [
            'floor.id',
            'floor.hospital_id',
            'floor.building_id',
            'floor.code',
            'floor.name',
            'floor.total_rooms',
            'building.name as building_name',
            'floor.status',
        ];

        if (is_array($search) && count($search) > 0) {
            $partyName = (array_key_exists('keyword', $search)) ? " AND floor.name LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' " : "";
            $filter .= $partyName;
        }
        return $this->leftJoin('building', 'building.id', 'floor.building_id')
            ->where('floor.hospital_id', loggedInHospitalId())
            ->whereRaw($filter)
            ->orderBy('id', 'ASC')->skip($skip)->take($take)->get($fields);
    }
    /**
     * Method is used to get total results.
     *
     * @param array $search
     *
     * @return mixed
     */
    public function totalFloor($search = null)
    {
        $filter = 1; // if no search add where

        // when search
        if (is_array($search) && count($search) > 0) {
            $partyName = (array_key_exists('name', $search)) ? " AND floor.name LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' " : "";
            $filter .= $partyName;
        }
        return $this->select(\DB::raw('count(*) as total'))
            ->whereRaw($filter)->first();
    }

}
