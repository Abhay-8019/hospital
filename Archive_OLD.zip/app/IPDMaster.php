<?php
namespace App;
/**
 * :: IPD Master Model ::
 * To manage IPD Master CRUD operations
 *
 **/

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class IPDMaster extends Model
{
    use SoftDeletes;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'ipd_master';

    /**
     * The attributes that are mass assignable.
     * @var array
     */
    protected $fillable = [
        'ipd_number',
        'doctor_id',
        'department_id',
        'patient_id',
        'ward_id',
        'bed_id',
        'admission_date',
        'is_discharged',
        'discharge_date',
        'discharge_type',
        'discharge_doctor',
        'previous_medical',
        'present_illness',
        'present_treatment',
        'family_history',
        'pulse_rate',
        'blood_pressure',
        'temperature',
        'hr',
        'rr',
        'other_information',
        'general_examination',
        'nadi',
        'mutra',
        'mala',
        'condition_on_discharge',
        'further_advice_on_discharge',
        'discharge_summary',
        'treatment_given',
        'treatment_advised',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    /**
     * Method is used to validate roles
     * @param $inputs
     * @param int $id
     * @return Response
     */
    public function validateIPDVisit($inputs, $id = null)
    {
        $rules = [
            'ipd_number' => 'required',
            'admission_date' => 'required',
            'doctor' => 'required',
            'department' => 'required',
            'ward' => 'required',
            'bed' => 'required',
            //'pulse_rate' => 'required',
            //'blood_pressure' => 'required',
            //'temperature' => 'required',
        ];

        $messages = [
            'ipd_number.required' => '* Required',
            'admission_date.required' => '* Required',
            'ward.required' => '* Required',
            'bed.required' => '* Required',
            'doctor.required' => '* Required',
            'department.required' => '* Required',
            'pulse_rate.required' => '* Required',
            'blood_pressure.required' => '* Required',
            'temperature.required' => '* Required',
        ];

        //dd($inputs);
        if($inputs['addpro'] == 1)
        {
            foreach($inputs['procedure_medicine'] as $key => $value)
            {
                $rules['procedure.'.$key] = 'required';
                $rules['procedure_medicine.'.$key] = 'required';
                $rules['procedure_dose.'.$key] = 'required';
                $rules['timing.'.$key] = 'required';

                $messages['procedure.'.$key.'.required'] = '* Required';
                $messages['procedure_medicine.'.$key.'.required'] = '* Required';
                $messages['procedure_dose.'.$key.'.required'] = '* Required';
                $messages['timing.'.$key.'.required'] = '* Required';

            }
        }

        if($inputs['addmedi'] == 1)
        {
            foreach ($inputs['medicine'] as $key => $value)
            {
                $rules['medicine.' . $key] = 'required';
                $rules['medicine_dose.' . $key] = 'required';
                $rules['medicine_dose_unit.' . $key] = 'required';
                $rules['medicine_timing.' . $key] = 'required';

                $messages['medicine.' . $key . '.required'] = '* Required';
                $messages['medicine_dose.' . $key . '.required'] = '* Required';
                $messages['medicine_dose_unit.' . $key . '.required'] = '* Required';
                $messages['medicine_timing.' . $key . '.required'] = '* Required';
            }
        }

        return \Validator::make($inputs, $rules, $messages);
    }

    /**
     * Method is used to validate roles
     * @param $inputs
     * @param int $id
     * @return Response
     */
    public function validateIPDDischarge($inputs, $id = null)
    {
        $rules = [
            'discharge_date' => 'required',
            'discharge_type' => 'required',
            'doctor' => 'required',
            'discharge_summary' => 'required',
            //'further_advice_on_discharge' => 'required',
        ];

        $messages = [
            'discharge_date.required' => '* Required',
            'discharge_type.required' => '* Required',
            'doctor.required' => '* Required',
            'discharge_summary.required' => '* Required',
            //'further_advice_on_discharge.required' => '* Required',
        ];
        return \Validator::make($inputs, $rules, $messages);
    }

    /**
     * @return int|mixed
     */
    public function getLastIPDNumber()
    {
        $opdNumber = 1;
        $result = $this->orderBy('id', 'DESC')->take(1)->first();
        if(count($result) > 0) {
            $opdNumber = ++$result->id;
        }
        return $opdNumber;
    }

    /**
     * Method is used to save/update resource.
     *
     * @param   array $input
     * @param   int $id
     * @return  Response
     */
    public function store($input, $id = null)
    {
        if ($id) {
            return $this->find($id)->update($input);
        } else {
            return $this->create($input)->id;
        }
    }

    /**
     * Method is used to search news detail.
     *
     * @param array $search
     * @param int $skip
     * @param int $perPage
     * @return mixed
     */
    public function getVisits($search = null, $skip, $perPage)
    {
        $take = ((int)$perPage > 0) ? $perPage : 20;
        $filter = 1; // default filter if no search

        $fields = [
            'ipd_master.id',
            'ipd_master.ipd_number',
            'ipd_master.admission_date',
            'ipd_master.is_discharged',
            'p.id as patient_id',
            'p.patient_code',
            'p.first_name',
            'p.email',
            'p.gender',
            'p.age',
            'p.address',
            'p.city',
            'p.zip_code'
        ];

        $orderEntity = 'id';
        $orderAction = 'desc';

        //dd($search);

        if (is_array($search) && count($search) > 0)
        {
            $filter .= (array_key_exists('keyword', $search))?
                " AND (first_name LIKE '%".addslashes(trim($search['keyword'])).
                "%' OR patient_code LIKE '%".addslashes(trim($search['keyword']))."%')"
                : "";

            $filter .= (array_key_exists('doctor_id', $search) && $search['doctor_id'] != "") ?
                " AND (ipd_master.doctor_id = " . addslashes(trim($search['doctor_id'])) . ")" : "";
        }

        // dd($this->leftJoin('patient_registration as p', 'p.id', '=', 'ipd_master.patient_id')
        //     ->leftJoin('doctor', 'doctor.id', '=', 'ipd_master.doctor_id')
        //     ->whereRaw($filter)
        //     ->orderBy($orderEntity, $orderAction)
        //     ->toSql());
        return $this->leftJoin('patient_registration as p', 'p.id', '=', 'ipd_master.patient_id')
            ->leftJoin('doctor', 'doctor.id', '=', 'ipd_master.doctor_id')
            ->whereRaw($filter)
            ->orderBy($orderEntity, $orderAction)
            ->get($fields);
    }

    /**
     * Method is used to get total results.
     * @param array $search
     * @return mixed
     */
    public function totalIPDVisits($search = null)
    {
        $filter = 1; // if no search add where

        // when search
        if (is_array($search) && count($search) > 0)
        {
            $filter .= (array_key_exists('keyword', $search))?
                " AND (first_name LIKE '%".addslashes(trim($search['keyword'])).
                "%' OR patient_code LIKE '%".addslashes(trim($search['keyword']))."%')"
                : "";

            $filter .= (array_key_exists('doctor_id', $search) && $search['doctor_id'] != "") ?
                " AND (ipd_master.doctor_id = " . addslashes(trim($search['doctor_id'])) . ")" : "";
        }
        
        return $this->leftJoin('patient_registration as p', 'p.id', '=', 'ipd_master.patient_id')
            ->select(\DB::raw('count(*) as total'))
            ->whereRaw($filter)
            ->first();
    }

    /**
     * Method is used to search news detail.
     *
     * @param array $search
     * @return mixed
     */
    public function getIPDVisits($search = [])
    {
        $filter = 1; // default filter if no search

        $fields = [
            'ipd_master.id',
            'p.id as patient_id',
            'p.patient_code',
            'p.first_name',
            'p.email',
            'p.gender',
            'p.age',
            'p.address',
            'p.city',
            'p.zip_code'
        ];

        $orderEntity = 'id';
        $orderAction = 'desc';

        if (is_array($search) && count($search) > 0)
        {
            $filter .= (array_key_exists('keyword', $search) && $search['keyword'] != "") ?
                " AND (p.name LIKE '%".addslashes(trim($search['keyword']))."%' 
                OR p.contact LIKE '%".addslashes(trim($search['keyword']))."%' 
                OR p.email LIKE '%".addslashes(trim($search['keyword']))."%')"
                : "";

            $filter .= (array_key_exists('ipd_id', $search) && $search['ipd_id'] != "") ?
                " AND (ipd_master.id = " . addslashes(trim($search['ipd_id'])) . ")" : "";

            $filter .= (array_key_exists('doctor_id', $search) && $search['doctor_id'] != "") ?
                " AND (ipd_master.doctor_id = " . addslashes(trim($search['doctor_id'])) . ")" : "";
        }

        return $this->leftJoin('patient_registration as p', 'p.id', '=', 'ipd_master.patient_id')
            ->leftJoin('doctor', 'doctor.id', '=', 'ipd_master.doctor_id')
            ->whereRaw($filter)
            ->orderBy($orderEntity, $orderAction)
            ->get($fields);
    }

    /**
     * @param $id
     * @return Model|null|static
     */
    public function getIPDVisitDetail($id)
    {
        $fields = [
            'ipd_master.*',
            'p.first_name',
            'p.email',
            'p.mobile',
            'p.blood_group',
            'p.gender',
            'p.age',
            'p.address',
            'p.city',
            'p.zip_code',
            'doctor.name as doctor',
            'department.name as department',
            'ward_master.name as ward',
            'bed_master.name as bed',
            'discharged.name as discharge_doctor',
        ];

        return $this->leftJoin('patient_registration as p', 'p.id', '=', 'ipd_master.patient_id')
            ->leftJoin('doctor', 'doctor.id', '=', 'ipd_master.doctor_id')
            ->leftJoin('doctor as discharged', 'discharged.id', '=', 'ipd_master.discharge_doctor')
            ->leftJoin('department', 'department.id', '=', 'ipd_master.department_id')
            ->leftJoin('ward_master', 'ward_master.id', '=', 'ipd_master.ward_id')
            ->leftJoin('bed_master', 'bed_master.id', '=', 'ipd_master.bed_id')
            ->where('ipd_master.id', $id)
            ->groupBy('ipd_master.id')
            ->first($fields);
    }

    /**
     * @param array $search
     * @return \Illuminate\Support\Collection|null
     */
    public function filterIPDVisits($search = [])
    {
        $filter = 1;

        $fields = [
            'ipd_master.doctor_id',
            'p.id as patient_id',
            'ipd_number',
            'admission_date',
            'patient_code',
            'first_name',
            'last_name',
            'age',
            'gender',
            'blood_group',
            'marital_status',
            'relationship',
            'mobile',
            'alternate_contact_no',
            'email',
            'registration_date',
            'status',
        ];

        if (is_array($search) && count($search) > 0 && isset($search['form-search']))
        {
            $filter .= (array_key_exists('keyword', $search) && $search['keyword'] != "") ? " AND (first_name LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' OR mobile LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' OR address LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' OR city LIKE '%" .
                addslashes(trim($search['keyword'])) . "%') " : "";

            $filter .= (array_key_exists('patient_name', $search) && $search['patient_name'] != "") ?
                " AND (first_name LIKE '%" . addslashes(trim($search['patient_name'])) . "%') " : "";

            $filter .= (array_key_exists('ipd_number', $search) && $search['ipd_number'] != "") ?
                " AND (ipd_number LIKE '%" . addslashes(trim($search['ipd_number'])) . "%') " : "";

            $filter .= (array_key_exists('mobile', $search) && $search['mobile'] != "") ?
                " AND (mobile LIKE '%" . addslashes(trim($search['mobile'])) . "%') " : "";

            $filter .= (array_key_exists('address', $search) && $search['address'] != "") ?
                " AND (address LIKE '%" . addslashes(trim($search['address'])) . "%') " : "";

            return $this->rightJoin('patient_registration as p', 'p.id', '=', 'ipd_master.patient_id')
                ->whereRaw($filter)
                ->where('p.hospital_id', loggedInHospitalId())
                ->orderBy('p.first_name', 'ASC')
                ->groupBy('patient_id')
                ->get($fields);
        }
        return null;
    }

    /**
     * @param null $pId
     * @return \Illuminate\Support\Collection
     */
    public function getPatientVisits($pId = null)
    {
        $fields = [
            'ipd_master.*',
            'p.first_name',
            'p.address',
            'p.city',
            'doctor.name as doctor',
        ];

        return $this->leftJoin('patient_registration as p', 'p.id', '=', 'ipd_master.patient_id')
            ->leftJoin('doctor', 'doctor.id', '=', 'ipd_master.doctor_id')
            ->where('ipd_master.patient_id', $pId)
            ->get($fields);
    }

    /**
     * @param $id
     * @return bool|null
     * @throws \Exception
     */
    public function drop($id)
    {
        $this->find($id)->delete();
        //->update(['deleted_by' => authUser()->id, 'deleted_at' => currentDate(true)]);
    }
}