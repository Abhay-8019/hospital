<?php

namespace App\Http\Controllers;

use App\AddTest;
use App\PatientRegistration;
use App\ResultTest;
use Illuminate\Http\Request;

class ResultTestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admin.resultTest.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $patientList=(new PatientRegistration)->getPatientsService();
        $listTest = (new AddTest)->ListTest();
        return view('admin.resultTest.create',compact('listTest','patientList'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $inputs = $request->all();
        $validator = (new ResultTest)->validateResultTest($inputs);
        if($validator->fails()){
            return validationResponse(false, 206, "", "", $validator->messages());
        }
        try{
            \DB::beginTransaction();
            unset($inputs['_token']);

            $inputs =$inputs + [
                    'created_by' => authUserId(),
                    /*  'hospital_id' => loggedInHospitalId()*/
                ];

            (new ResultTest)->store($inputs);
            \DB::commit();
            $route = route('result-test.index');
            return validationResponse(true, 201, lang('messages.created', lang('test.test')), $route);
        }catch(\Exception $exception){
            \DB::rollBack();
            return validationResponse(false, 207, $exception->getMessage().' '.lang('messages.server_error'));
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(ResultTest $resultTest)
    {
        $result = $resultTest;
        if(!$result){
            abort(404);
        }
        $patientList=(new PatientRegistration)->getPatientsService();
        $listTest = (new AddTest)->ListTest();
        return view('admin.resultTest.edit', compact('result', 'listTest', 'patientList'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ResultTest $resultTest)
    {
        $result = $resultTest;
        if(!$result){
            return validationResponse(false, 206, lang('messages.invalid_id', string_manip(lang('test.test'))));
        }

        $id = $result->id;

        $inputs = $request->all();

        $validator = (new ResultTest)-> validateResultTest($inputs, $id);
        if($validator->fails()){
            return validationResponse(false, 206, "", "", $validator->messages());
        }
        try{
            \DB::beginTransaction();

            $inputs =$inputs + [
                    'status' => isset($inputs['status']) ? 1 : 0,
                    'updated_by' => authUserId()
                ];

            (new ResultTest)->store($inputs, $id);
            \DB::commit();
            $route = route('result-test.index');
            return validationResponse(true, 201, lang('messages.updated', lang('test.test')), $route);
        }catch(\Exception $exception){
            \DB::rollBack();
            return validationResponse(false, 207, $exception->getMessage().' '.lang('messages.server_error'));
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return "In Progress";
    }

    public function resultTestToggle($id = null){
        if(!\Request::ajax()){
            return lang('messages.server_error');
        }
        $result = ResultTest::find($id);
        try{

            $result->update(['status'=>!$result->status]);
            $response=['status'=>1, 'data'=>(int)$result->status . '.gif'];
            return json_encode($response);
        }catch(\Exception $exception){
            return lang('messages.invalid_id',string_manip(lang('test.test')));
        }
    }

    public function resultTestPaginate(Request $request, $pageNumber = null)
    {
        if (!\Request::isMethod('post') && !\Request::ajax()) { //
            return lang('messages.server_error');
        }

        $inputs = $request->all();
        $page = 1;
        if (isset($inputs['page']) && (int)$inputs['page'] > 0) {
            $page = $inputs['page'];
        }

        $perPage = 20;
        if (isset($inputs['perpage']) && (int)$inputs['perpage'] > 0) {
            $perPage = $inputs['perpage'];
        }

        $start = ($page - 1) * $perPage;
        if (isset($inputs['form-search']) && $inputs['form-search'] != '') {
            $inputs = array_filter($inputs);
            unset($inputs['_token']);

            $data = (new ResultTest)->getResultTest($inputs, $start, $perPage);
            $totalResultTest = (new ResultTest)->totalResultTest($inputs);
            $total = $totalResultTest->total;
        } else {

            $data = (new ResultTest)->getResultTest($inputs, $start, $perPage);
            $totalResultTest = (new ResultTest)->totalResultTest($inputs);
            $total = $totalResultTest->total;
        }

        return view('admin.resultTest.load_data', compact('data', 'total', 'page', 'perPage'));
    }

}
