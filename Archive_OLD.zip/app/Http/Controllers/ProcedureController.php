<?php
namespace App\Http\Controllers;
/**
 * :: Procedure Master Controller ::
 * To manage procedure master.
 *
 **/

use App\Http\Controllers\Controller;
use App\Procedures;
use Maatwebsite\Excel\Facades\Excel;

class ProcedureController extends Controller {
	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		return view('admin.procedure.index');
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		$procedures = (new Procedures)->getProcedureService(['main_only' => 1]);
		return view('admin.procedure.create', compact('procedures'));
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$inputs = \Input::all();
		$validator = (new Procedures)->validateProcedure($inputs);
		if ($validator->fails()) {
			return validationResponse(false, 206, "", "", $validator->messages());

		}
		try {
			\DB::beginTransaction();

			$inputs = $inputs + [
				'status' => (isset($inputs['status'])) ? 1 : 0,
				'main_procedure_id' => ($inputs['is_sub_procedure'] == 1) ? $inputs['main_procedure'] : 0,
				'created_by' => authUserId(),
				'company_id' => loggedInHospitalId()
			];
			$id = (new Procedures)->store($inputs);
			$submitData = [];
			if(!empty($inputs['isAjax'])) {
				$submitData = ['id' => $id, 'name' => $inputs['name']];
			}
			$route = route('procedures.index');
			$lang = lang('messages.created', lang('procedure.procedure'));
			\DB::commit();
			return validationResponse(true, 201, $lang, $route, [], $submitData);

		} catch (\Exception $exception) {
			\DB::rollBack();
			return validationResponse(false, 207, lang('messages.server_error'));
		}
	}

	/**
	 * Show the form for editing the specified resource.
	 * @param int $id
	 * @return Response
	 */
	public function edit($id = null)
	{
		$result = (new Procedures)->company()->find($id);
		if (!$result) {
			abort(401);
		}
		$procedures = (new Procedures)->getProcedureService(['main_only' => 1]);
		return view('admin.procedure.edit', compact('result', 'procedures'));
	}

	/**
	 * Update the specified resource in storage.
	 * @param int $id
	 * @return Response
	 */
	public function update($id = null)
	{
		$result = (new Procedures)->company()->find($id);
		if (!$result) {
			abort(401);
		}

		$result = (new Procedures)->company()->find($id);
		if (!$result) {
			return redirect()->route('procedures.index')
				->with('error', lang('messages.invalid_id', string_manip(lang('procedure.procedure'))));
		}

		$inputs = \Input::all();
		$validator = (new Procedures)->validateProcedure($inputs, $id);
		if ($validator->fails()) {
			return validationResponse(false, 206, "", "", $validator->messages());
		}

		try {
			\DB::beginTransaction();
			$inputs = $inputs + [
				'status' => (isset($inputs['status'])) ? 1 : 0,
				'main_procedure_id' => ($inputs['is_sub_procedure'] == 1) ? $inputs['main_procedure'] : 0,
				'updated_by' => authUserId()
			];
			(new Procedures)->store($inputs, $id);
			\DB::commit();
			$route = route('procedures.index');
			$lang = lang('messages.updated', lang('procedure.procedure'));
			return validationResponse(true, 201, $lang, $route);

		} catch (\Exception $exception) {
			\DB::rollBack();
			return validationResponse(false, 207, lang('messages.server_error'));
		}
	}

	/**
	 * Remove the specified resource from storage.
	 * @param int $id
	 * @return Response
	 */
	public function drop($id)
	{
		if (!\Request::ajax()) {
			return lang('messages.server_error');
		}

		try {
			$check = (new Procedures)->procedureExists($id);
			if($check) {
				$response = ['status' => 1, 'message' => lang('procedure.procedure_in_use')];
			} else {
				(new Procedures)->drop($id);
				$response = ['status' => 1, 'message' => lang('messages.deleted', lang('procedure.procedure'))];
			}

		} catch (\Exception $exception) {
			$response = ['status' => 0, 'message' => lang('messages.server_error')];
		}

		return json_encode($response);
	}

	/**
	 * Used to update procedure active status.
	 * @param int $id
	 * @return Response
	 */
	public function procedureToggle($id = null)
	{
		if (!\Request::ajax()) {
			return lang('messages.server_error');
		}

		try {
			$result = Procedures::find($id);
		} catch (\Exception $exception) {
			return lang('messages.invalid_id', string_manip(lang('procedure.procedure')));
		}

		$result->update(['status' => !$result->status]);
		$response = ['status' => 1, 'data' => (int)$result->status . '.gif'];
		return json_encode($response);
	}

	/**
	 * Used to load more records and render to view.
	 * @param int $pageNumber
	 * @return Response
	 */
	public function procedurePaginate($pageNumber = null)
	{
		if (!\Request::isMethod('post') && !\Request::ajax()) { //
			return lang('messages.server_error');
		}

		$inputs = \Input::all();
		$page = 1;
		if (isset($inputs['page']) && (int)$inputs['page'] > 0) {
			$page = $inputs['page'];
		}

		$perPage = 20;
		if (isset($inputs['perpage']) && (int)$inputs['perpage'] > 0) {
			$perPage = $inputs['perpage'];
		}

		$start = ($page - 1) * $perPage;
		if (isset($inputs['form-search']) && $inputs['form-search'] != '') {
			$inputs = array_filter($inputs);
			unset($inputs['_token']);

			$data = (new Procedures)->getProcedures($inputs, $start, $perPage);
			$totalProcedures = (new Procedures)->totalProcedures($inputs);
			$total = $totalProcedures->total;
		}

		else {

			$data = (new Procedures)->getProcedures($inputs, $start, $perPage);
			$totalProcedures = (new Procedures)->totalProcedures();
			$total = $totalProcedures->total;
		}

		return view('admin.procedure.load_data', compact('data', 'total', 'page', 'perPage', 'inputs'));
	}
	/**
	 * Submit Modal Form
	 * @return Success Or Failure
	 */
	public function procedureModal()
	{
		$isAjax = 1;
		return view('admin.procedure.procedure_modal', compact('isAjax'));
	}

	/**
	 * Get Lists
	 * @return Success Or Failure
	 */
	public function procedureLists()
	{
		$rogs = (new Procedures)->getProcedureService();
		return response()->json($rogs);
	}

	/**
	 * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\JsonResponse|\Illuminate\View\View
	 */
	public function uploadExcel()
	{
		$inputs = \Input::all();
		if (count($inputs) > 0) {
			$validator = (new Procedures)->validateProcedureExcel($inputs);
			if ($validator->fails()) {
				return validationResponse(false, 206, "", "", $validator->messages());
			}
			ini_set('memory_limit', '-1');
			Excel::load($inputs['file'], function ($reader)
			{
				try {
					$data = [];
					$reader->each(function($sheet)
					{
						\DB::beginTransaction();
						//$product = (new Product)->findProductCode($sheet->product_code);
						$name = trim($sheet->procedurename);
						if($name != "")
						{
							$data = [
								'name' => $name,
								'procedure_type' => 1,
								'is_sub_procedure' => 0,
								'created_by' => authUserId(),
								'company_id' => loggedInHospitalId(),
							];
							//dd($data);
							(new Procedures)->store($data);
						}
						\DB::commit();
					});
				}
				catch (\Exception $e) {
					\DB::rollBack();
					return redirect()->back()
						->with('error', lang('messages.server_error'));

				}
			});
			//$route = route('products.index');
			$lang = lang('procedure.procedure_uploaded');
			return validationResponse(true, 201, $lang);
		}
		return view('admin.procedure.upload_excel');
	}

}