<?php

namespace App\Http\Controllers;

use App\AddTest;
use App\Department;
use App\Doctor;
use App\PatientTestsDetail;
use App\ViewIPDPatients;
use App\ViewOPDVisits;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function opdVisits()
    {
        $inputs = \Input::all();
        $doctors = (new Doctor)->getDoctorList();
        $departments = (new Department)->getDepartmentService();

        $doctorName = $departmentName = $patientName = "";
        if (\Request::isMethod('post') && \Request::ajax())
        {
            $inputs = array_filter($inputs);
            unset($inputs['keyword']);

            unset($inputs['_token']);
            unset($inputs['page']);
            unset($inputs['perpage']);

            if (isset($inputs['doctor'])) {
                $doctorName = $doctors[$inputs['doctor']];
            } elseif (isset($inputs['department'])) {
                $departmentName = $departments[$inputs['department']];
            } elseif(isset($inputs['patient_name'])) {
                $patientName = $inputs['patient_name'];
            }

            try {
                
                $result = (new ViewOPDVisits)->filterOPDVisits($inputs);
                $summary = (new ViewOPDVisits)->filterGroupOPDVisits($inputs); 
                
            } catch (\Exception $exception) {
                return $exception->getMessage() . $exception->getLine() . $exception->getFile();
            }

            return view('admin.reports.opd-visits.opd_visits_load_data', compact('result', 'inputs', 'patientName',
                'doctorName', 'departmentName','summary'));
        }
        return view('admin.reports.opd-visits.opd-visits', compact('doctors', 'departments'));
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function ipdPatients()
    {
        $inputs = \Input::all();
        $doctors = (new Doctor)->getDoctorList();
        $departments = (new Department)->getDepartmentService();

        $doctorName = $departmentName = $patientName = "";
        if (\Request::isMethod('post') && \Request::ajax())
        {
            $inputs = array_filter($inputs);
            unset($inputs['_token']);
            unset($inputs['page']);
            unset($inputs['keyword']);
            unset($inputs['perpage']);

            if (isset($inputs['doctor'])) {
                $doctorName = $doctors[$inputs['doctor']];
            } elseif (isset($inputs['department'])) {
                $departmentName = $departments[$inputs['department']];
            } elseif(isset($inputs['patient_name'])) {
                $patientName = $inputs['patient_name'];
            }

            try {
                $result = (new ViewIPDPatients)->filterIPDPatients($inputs);
                $summary = (new ViewIPDPatients)->filterGroupIPDPatients($inputs);
                        

            } catch (\Exception $exception) {
                return $exception->getMessage() . $exception->getLine() . $exception->getFile();
            }

            return view('admin.reports.ipd-patient.ipd_patient_load_data', compact('result', 'inputs', 'patientName',
                'doctorName', 'departmentName','summary'));
        }
        return view('admin.reports.ipd-patient.ipd-patient', compact('doctors', 'departments'));
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function bedOccupancy()
    {
        $inputs = \Input::all();
        //$doctors = (new Doctor)->getDoctorList();
        //$departments = (new Department)->getDepartmentService();
        //$doctorName = $departmentName = $patientName = "";
        if (\Request::isMethod('post') && \Request::ajax())
        {
            $inputs = array_filter($inputs);
            unset($inputs['_token']);
            unset($inputs['page']);
            unset($inputs['keyword']);
            unset($inputs['perpage']);

            try {
                $result = (new ViewIPDPatients)->bedOccupancySummary($inputs);
                $detailedResult = (new ViewIPDPatients)->bedOccupancyDetail($inputs);
                //dd($result->toArray());
            } catch (\Exception $exception) {
                return $exception->getMessage() . $exception->getLine() . $exception->getFile();
            }
            return view('admin.reports.ipd-patient.bed_occupancy_load_data', compact('result', 'detailedResult','inputs'));
        }
        return view('admin.reports.ipd-patient.bed-occupancy', compact('doctors', 'departments'));
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View|string
     */
    public function patientTestSummary()
    {
        $inputs = \Input::all();
        $doctors = (new Doctor)->getDoctorList();
        $departments = (new Department)->getDepartmentService();
        if (\Request::isMethod('post') && \Request::ajax())
        {
            $inputs = array_filter($inputs);
            unset($inputs['_token']);
            unset($inputs['page']);
            unset($inputs['keyword']);
            unset($inputs['perpage']);

            $doctorName = $departmentName = "";
            if (isset($inputs['doctor'])) {
                $doctorName = $doctors[$inputs['doctor']];
            } elseif (isset($inputs['department'])) {
                $departmentName = $departments[$inputs['department']];
            }
            
            try {
                $result = (new PatientTestsDetail)->patientTestSummary($inputs);
            } catch (\Exception $exception) {
                return $exception->getMessage() . $exception->getLine() . $exception->getFile();
            }
            return view('admin.reports.patient-test.patient_test_load_data', compact('result', 'inputs',
                'doctorName', 'departmentName'));
        }
        return view('admin.reports.patient-test.patient-test', compact('doctors', 'departments'));
    }
}
