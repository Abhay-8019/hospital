<?php

namespace App\Http\Controllers;

use App\Department;
use App\Doctor;
use App\DoctorFee;
use App\Hospital;
use App\OPDMaster;
use Illuminate\Http\Request;
use App\PatientRegistration;
use App\User;

class PatientRegistrationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admin.patient_registration.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $doctorArray= (new Doctor)->getDoctorList();
        $patientCode = (new PatientRegistration)->getPatientCode();
        $genderArr = lang('common.genderArray');
        $patientTypeArray = lang('common.patientTypeArray');
        $bloodGroupArr = lang('common.bloodGroupArr');
        $maritalStatusArr = lang('common.maritalStatusArr');
        $departments = (new Department)->getDepartmentService();
        return view('admin.patient_registration.create', compact('doctorArray', 'patientCode', 'departments',
            'patientType', 'genderArr', 'patientTypeArray', 'bloodGroupArr', 'maritalStatusArr'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $inputs = $request->all();

        // if(isset($inputs['std_code']) && $inputs['std_code'] != '' && $inputs['alternate_contact_no'] == '') {
        //     $message = lang('patient.please_fill_contact_no_along_std_code');
        //     return validationResponse(false, 207, $message);
        // }else if(isset($inputs['alternate_contact_no']) && $inputs['alternate_contact_no'] != '' && $inputs['std_code'] == '') {
        //     $message = lang('patient.please_fill_std_code_along_contact_no');
        //     return validationResponse(false, 207, $message);
        // }

        $validator = (new PatientRegistration)->validatePatients($inputs);
        if ($validator->fails()) {
            return validationResponse(false, 206, "", "", $validator->messages());
        }
        try {
            \DB::beginTransaction();
            unset($inputs['_token']);

            $patientType = $inputs['patient_type'];
            unset($inputs['patient_type']);

            $inputs['date_of_birth'] = ($inputs['date_of_birth']!= '')
                ? dateFormat('Y-m-d', $inputs['date_of_birth']) : null;

           /* $inputs['registration_date'] = ($inputs['registration_date']!= '')?
              convertToUtc($inputs['registration_date'].date('H:i:s'), 'Y-m-d H:i:s') : null;*/

            $alternateContactNo = $inputs['std_code'].'-'.$inputs['alternate_contact_no'];
            unset($inputs['std_code']); unset($inputs['alternate_contact_no']);

            $inputs['registration_date'] = convertToUtc();

            $status = isset($inputs['status']) ? 1 : 0;
            $inputs = $inputs + [
                'status'               => $status,
                'patient_type'         => $patientType,
                'alternate_contact_no' => $alternateContactNo,
                'dept_code'             => $inputs['department'],
                'hospital_id'          => loggedInHospitalId(),
                'created_by'           => authUserId(),
            ];

            //dd($inputs);
            $registerId = (new PatientRegistration)->store($inputs);
            $lastOPDId = (new OPDMaster)->getLastOPDNumber();
            //(new PatientRegistration)->store($update, $registerId);

            $opdSave = [
                'opd_number'  => date('Ym') . $lastOPDId,
                'doctor_id'  => $inputs['doctor_id'],
                'department_id'  => $inputs['department'],
                'patient_id'  => $registerId,
                'visit_date'  => currentDate(true),
                'created_by'  => authUserId(),
                'is_completed'  => 0,
                'flag' => 'new'
            ];
            $opdId = (new OPDMaster)->store($opdSave);
            // reassign the patient code & opd_id to patient.
            (new PatientRegistration)->store(['opd_id' => $opdId, 'patient_code' => "P-".$registerId], $registerId);

            \DB::commit();
            $route   = route('patient-registration.index');
            $message = lang('messages.created', lang('patient.patient'));
            return validationResponse(true, 201, $message, $route);
        } catch (\Exception $e) {
            \DB::rollBack();
            return validationResponse(false, 207, lang('messages.server_error'));
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\PatientRegistration  $PatientRegistration
     * @return \Illuminate\Http\Response
     */
    public function edit(PatientRegistration $PatientRegistration)
    {
        $result = $PatientRegistration;
        if(!$result) {
            abort(404);
        }
        if($result->hospital_id != loggedInHospitalId()) {
            abort(401);
        }
        $doctorArray= (new Doctor)->getDoctorList();
        $genderArr = lang('common.genderArray');
        $patientTypeArray = lang('common.patientTypeArray');
        $bloodGroupArr = lang('common.bloodGroupArr');
        $maritalStatusArr = lang('common.maritalStatusArr');

        $user = null;//User::find($result->user_id);

        $number = explode('-', $result->alternate_contact_no, 2);

        $stdCode = (!empty($number[0])) ? $number[0] : '';
        $alternateNo = (!empty($number[1])) ? $number[1] : '';
        $departments = (new Department)->getDepartmentService();

        return view('admin.patient_registration.edit', compact('doctorArray', 'result',
            'genderArr', 'patientTypeArray', 'bloodGroupArr', 'maritalStatusArr', 'departments',
            'user', 'stdCode', 'alternateNo'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param PatientRegistration $patientRegistration
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PatientRegistration $patientRegistration)
    {
        $patientRegistrationId = $patientRegistration->id;
        $inputs = $request->all();
        /*$inputs['user_id'] = $patientRegistration->user_id;*/

        // if(isset($inputs['std_code']) && $inputs['std_code'] != '' && $inputs['alternate_contact_no'] == '') {
        //     $message = lang('patient.please_fill_contact_no_along_std_code');
        //     return validationResponse(false, 207, $message);
        // }else if(isset($inputs['alternate_contact_no']) && $inputs['alternate_contact_no'] != '' && $inputs['std_code'] == '') {
        //     $message = lang('patient.please_fill_std_code_along_contact_no');
        //     return validationResponse(false, 207, $message);
        // }

        $validator = (new PatientRegistration)->validatePatients($inputs, $patientRegistrationId);
        if ($validator->fails()) {
            return validationResponse(false, 206, "", "", $validator->messages());
        }
        try {
            \DB::beginTransaction();

            $patientType = $inputs['patient_type'];
            unset($inputs['patient_type']);

            $inputs['date_of_birth'] = ($inputs['date_of_birth']!= '')? dateFormat('Y-m-d', $inputs['date_of_birth']) : null;

            /*$inputs['registration_date'] = ($inputs['registration_date']!= '')?
                convertToUtc($inputs['registration_date'].Date('H:i:s'), 'Y-m-d H:i:s') : null;*/

            $alternateContactNo = $inputs['std_code'].'-'.$inputs['alternate_contact_no'];
            unset($inputs['std_code']); unset($inputs['alternate_contact_no']);

            $status = isset($inputs['status']) ? 1 : 0;
            $inputs = $inputs + [
                'status'               => $status,
                'patient_type'         => $patientType,
                'alternate_contact_no' => $alternateContactNo,
                'dept_code'            => $inputs['department'],
                'updated_by'           => authUserId(),
            ];
            (new PatientRegistration)->store($inputs, $patientRegistrationId);

            $save = [
                'doctor_id' => $inputs['doctor_id'],
                'department_id' => $inputs['department']
            ];
            (new OPDMaster)->store($save, $patientRegistration->opd_id);

            // changed - 03.01.2019
            /*$opd = (new OPDMaster)->where("patient_id","=",$patientRegistrationId)->orderBy('id','desc')->first();
            //(new OPDMaster)->store(['doctor_id' => $inputs['doctor_id']], $patientRegistration->opd_id);
            if(count($opd)) {
                (new OPDMaster)->store(['doctor_id' => $inputs['doctor_id']], $opd->id);
            }*/
            (new PatientRegistration)->store($inputs, $patientRegistrationId);
            \DB::commit();
            $message = lang('messages.updated', lang('patient.patient'));
            $route = route('patient-registration.index');
            return validationResponse(true, 201, $message, $route);

        } catch (\Exception $e) {
            \DB::rollBack();
            return validationResponse(false, 207, lang('messages.server_error'));
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\PatientRegistration  $PatientRegistration
     * @return \Illuminate\Http\Response
     */
    public function destroy(PatientRegistration $PatientRegistration)
    {
        return "In progress";
    }

    /**
     * Used to load more records and render to view.
     *
     * @param int $pageNumber
     *
     * @return Response
     */
    public function patientRegistrationPaginate(Request $request, $pageNumber = null)
    {
        if (!\Request::isMethod('post') && !\Request::ajax()) { //
            return lang('messages.server_error');
        }

        $inputs = $request->all();
        $page = 1;
        if (isset($inputs['page']) && (int)$inputs['page'] > 0) {
            $page = $inputs['page'];
        }

        $perPage = 20;
        if (isset($inputs['perpage']) && (int)$inputs['perpage'] > 0) {
            $perPage = $inputs['perpage'];
        }

        $start = ($page - 1) * $perPage;
        if (isset($inputs['form-search']) && $inputs['form-search'] != '') {
            $inputs = array_filter($inputs);
            unset($inputs['_token']);

            $data = (new PatientRegistration)->getPatients($inputs, $start, $perPage);
            $totalDepartment = (new PatientRegistration)->totalPatients($inputs);
            $total = $totalDepartment->total;
        } else {

            $data = (new PatientRegistration)->getPatients($inputs, $start, $perPage);
            $totalDepartment = (new PatientRegistration)->totalPatients($inputs);
            $total = $totalDepartment->total;
        }
        return view('admin.patient_registration.load_data', compact('data', 'total', 'page', 'perPage'));
    }

    /**
     * @param null $id
     * @return string
     */
    public function patientRegistrationToggle($id = null)
    {
        if (!\Request::isMethod('post') && !\Request::ajax()) {
            return lang('messages.server_error');
        }
        // get the User w.r.t id
        $results = PatientRegistration::find($id);

        try {

            $results->update(['status' => !$results->status]);
            $response = ['status' => 1, 'data' => (int)$results->status . '.gif'];
            // return json response
            return json_encode($response);

        } catch (\Exception $exception) {
            return lang('messages.invalid_id', string_manip(lang('patient.patient')));
        }
    }

    public function printDetail()
    {
        //$hospitalDetail = (new Hospital)->getData() ;
        //$patientDetail = (new PatientRegistration)->getData() ;
        //$feeDetail = (new DoctorFee)->getData();
        return view('admin.patient_registration.slip');
    }

    /**
     * @return string
     */
    public function getPatients()
    {
        $inputs = \Input::all();
        $inputs['form-search'] = 1;
        $json = (new PatientRegistration)->getPatientAjax($inputs);
        return json_encode($json);
    }
}
