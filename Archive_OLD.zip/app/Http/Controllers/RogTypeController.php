<?php
namespace App\Http\Controllers;
/**
 * :: RogType Master Controller ::
 * To manage rog_type master.
 *
 **/

use App\Http\Controllers\Controller;
use App\RogType;

class RogTypeController extends Controller {
	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		return view('admin.rog-type.index');
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		return view('admin.rog-type.create');
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$inputs = \Input::all();
		$validator = (new RogType)->validateRogType($inputs);
		if ($validator->fails()) {
			return validationResponse(false, 206, "", "", $validator->messages());

		}
		try {
			\DB::beginTransaction();

			$inputs = $inputs + [
				'status' => (isset($inputs['status'])) ? 1 : 0,
				'created_by' => authUserId(),
				'company_id' => loggedInHospitalId()
			];
			$id = (new RogType)->store($inputs);
			$submitData = [];
			if(!empty($inputs['isAjax'])) {
				$submitData = ['id' => $id, 'name' => $inputs['name']];
			}
			$route = route('rog-types.index');
			$lang = lang('messages.created', lang('rog_type.rog_type'));
			\DB::commit();
			return validationResponse(true, 201, $lang, $route, [], $submitData);

		} catch (\Exception $exception) {
			\DB::rollBack();
			return validationResponse(false, 207, lang('messages.server_error'));
		}
	}

	/**
	 * Show the form for editing the specified resource.
	 * @param int $id
	 * @return Response
	 */
	public function edit($id = null)
	{
		$result = (new RogType)->company()->find($id);
		if (!$result) {
			abort(401);
		}

		return view('admin.rog-type.edit', compact('result'));
	}

	/**
	 * Update the specified resource in storage.
	 * @param int $id
	 * @return Response
	 */
	public function update($id = null)
	{
		$result = (new RogType)->company()->find($id);
		if (!$result) {
			abort(401);
		}

		$result = (new RogType)->company()->find($id);
		if (!$result) {
			return redirect()->route('rog-types.index')
				->with('error', lang('messages.invalid_id', string_manip(lang('rog_type.rog_type'))));
		}

		$inputs = \Input::all();
		$validator = (new RogType)->validateRogType($inputs, $id);
		if ($validator->fails()) {
			return validationResponse(false, 206, "", "", $validator->messages());
		}

		try {
			\DB::beginTransaction();
			$inputs = $inputs + [
				'status' => (isset($inputs['status'])) ? 1 : 0,
				'updated_by' => authUserId()
			];
			(new RogType)->store($inputs, $id);
			\DB::commit();
			$route = route('rog-types.index');
			$lang = lang('messages.updated', lang('rog_type.rog_type'));
			return validationResponse(true, 201, $lang, $route);

		} catch (\Exception $exception) {
			\DB::rollBack();
			return validationResponse(false, 207, lang('messages.server_error'));
		}
	}

	/**
	 * Remove the specified resource from storage.
	 * @param int $id
	 * @return Response
	 */
	public function drop($id)
	{
		if (!\Request::ajax()) {
			return lang('messages.server_error');
		}

		try {
			$check = (new RogType)->rogTypeExists($id);
			if($check) {
				$response = ['status' => 1, 'message' => lang('rog_type.rog_type_in_use')];
			} else {
				(new RogType)->drop($id);
				$response = ['status' => 1, 'message' => lang('messages.deleted', lang('rog_type.rog_type'))];
			}

		} catch (\Exception $exception) {
			$response = ['status' => 0, 'message' => lang('messages.server_error')];
		}

		return json_encode($response);
	}

	/**
	 * Used to update rog_type active status.
	 * @param int $id
	 * @return Response
	 */
	public function rogTypeToggle($id = null)
	{
		if (!\Request::ajax()) {
			return lang('messages.server_error');
		}

		try {
			$result = RogType::find($id);
		} catch (\Exception $exception) {
			return lang('messages.invalid_id', string_manip(lang('rog_type.rog_type')));
		}

		$result->update(['status' => !$result->status]);
		$response = ['status' => 1, 'data' => (int)$result->status . '.gif'];
		return json_encode($response);
	}

	/**
	 * Used to load more records and render to view.
	 * @param int $pageNumber
	 * @return Response
	 */
	public function rogTypePaginate($pageNumber = null)
	{
		if (!\Request::isMethod('post') && !\Request::ajax()) { //
			return lang('messages.server_error');
		}

		$inputs = \Input::all();
		$page = 1;
		if (isset($inputs['page']) && (int)$inputs['page'] > 0) {
			$page = $inputs['page'];
		}

		$perPage = 20;
		if (isset($inputs['perpage']) && (int)$inputs['perpage'] > 0) {
			$perPage = $inputs['perpage'];
		}

		$start = ($page - 1) * $perPage;
		if (isset($inputs['form-search']) && $inputs['form-search'] != '') {
			$inputs = array_filter($inputs);
			unset($inputs['_token']);

			$data = (new RogType)->getRogTypes($inputs, $start, $perPage);
			$totalRogType = (new RogType)->totalRogTypes($inputs);
			$total = $totalRogType->total;
		}

		else {

			$data = (new RogType)->getRogTypes($inputs, $start, $perPage);
			$totalRogType = (new RogType)->totalRogTypes();
			$total = $totalRogType->total;
		}

		return view('admin.rog-type.load_data', compact('data', 'total', 'page', 'perPage', 'inputs'));
	}
	/**
	 * Submit Modal Form
	 * @return Success Or Failure
	 */
	public function rogTypeModal()
	{
		$isAjax = 1;
		return view('admin.rog-type.rog_type_modal', compact('isAjax'));
	}

	/**
	 * Get Lists
	 * @return Success Or Failure
	 */
	public function rog_typeLists()
	{
		$rogs = (new RogType)->getRogTypeService();
		return response()->json($rogs);
	}

}