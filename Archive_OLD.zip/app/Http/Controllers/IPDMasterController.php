<?php

namespace App\Http\Controllers;

use App\BedMaster;
use App\DailyProcedureVisits;
use App\Department;
use App\Doctor;
use App\IPDMaster;
use App\IPDOralMedications;
use App\IPDProcedureTreatments;
use App\OPDMaster;
use App\PatientRegistration;
use App\Procedures;
use App\Product;
use App\WardMaster;
use Illuminate\Http\Request;

class IPDMasterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param null $id
     * @return \Illuminate\Http\Response
     */
    public function index($id = null)
    {
        $result = OPDMaster::find($id);
        if(!$result) {
            return redirect()->back()->with('error', 'Error: Invalid OPD.');
        }
        $isExist = (new IPDMaster)->where(['patient_id' => $result->patient_id, 'is_discharged' => '0'])->count();
        if($isExist > 0) {
            return redirect()->back()->with('error', "Patient is already exist in IPD.");
        }

        $patient = (new PatientRegistration)->getPatientDetail($result->patient_id);
        $ipdNumber = (new IPDMaster)->getLastIPDNumber();
        $doctors= (new Doctor)->getDoctorList();
        $departments = (new Department)->getDepartmentService();
        $wards = (new WardMaster)->getWardService();
        $beds = (new BedMaster)->getBedService(['not_booked' => 1]);
        $procedures = (new Procedures)->getProcedureService(['main_only' => 1]);

        //dd($procedures);
        $medicines = (new Product)->getProductsService();
        return view('admin.ipd_visits.create', compact('result', 'patient', 'departments', 'doctors',
            'wards', 'beds',  'ipdNumber', 'procedures', 'medicines'));
    }

    /**
     * @param null $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function saveIPDDetail($id = null)
    {
        $inputs = \Input::all();
        $validator = (new IPDMaster)->validateIPDVisit($inputs);
        if ($validator->fails()) {
            return validationResponse(false, 206, "", "", $validator->messages());
        }

        try
        {
            \DB::beginTransaction();

            $admDate = $inputs['admission_date'] . date(' H:i:s');
            unset($inputs['admission_date']);
            $inputs['admission_date'] = dateFormat('Y-m-d H:i:s', $admDate);

            $inputs['opd_id'] = $id;
            $inputs['patient_id'] = $inputs['p_id'];
            $inputs['doctor_id'] = $inputs['doctor'];
            $inputs['department_id'] = $inputs['department'];
            $inputs['ward_id'] = $inputs['ward'];
            $inputs['bed_id'] = $inputs['bed'];
            $inputs['created_by'] = authUserId();

            //dd($inputs);

            $id = (new IPDMaster)->store($inputs);
            (new BedMaster)->store(['is_booked' => 1], $inputs['bed']);

            $savePTreatment = [];

            if($inputs['addpro'] == 1)
            {
                $procedureMedicines = (is_array($inputs['procedure_medicine']) && count($inputs['procedure_medicine']) > 0)
                    ? $inputs['procedure_medicine'] : [];

                foreach($procedureMedicines as $key => $value)
                {
                    $procedure = $inputs['procedure'][$key];
                    $pMedicine = $inputs['procedure_medicine'][$key];
                    $pDose = $inputs['procedure_dose'][$key];
                    $pTiming = $inputs['timing'][$key];
                    $pRemarks = $inputs['remarks'][$key];

                    $savePTreatment[] = [
                        'ipd_master_id'  => $id,
                        'procedure_id'  => $procedure,
                        'procedure_date'  => currentDate(true),
                        'procedure_medicine_id'  => $pMedicine,
                        'dose'  => $pDose,
                        'timing'  => $pTiming,
                        'remarks'  => $pRemarks,
                    ];
                }

                if(count($savePTreatment) > 0) {
                    (new IPDProcedureTreatments)->store($savePTreatment, null, true);
                }
            }

            if($inputs['addmedi'] == 1)
            {
                $saveMedicines = [];
                $procedureMedicines = (is_array($inputs['medicine']) && count($inputs['medicine']) > 0)
                    ? $inputs['medicine'] : [];
                foreach($procedureMedicines as $key => $value)
                {
                    $mMedicine = $inputs['medicine'][$key];
                    $mDose = $inputs['medicine_dose'][$key];
                    $mUnit = $inputs['medicine_dose_unit'][$key];
                    $mTiming = $inputs['medicine_timing'][$key];
                    $mRemarks = $inputs['medicine_remarks'][$key];

                    $saveMedicines[] = [
                        'ipd_master_id'  => $id,
                        'medicine_id'  => $mMedicine,
                        'procedure_date'  => currentDate(true),
                        //'medicine_days'  => $pMedicine,
                        'dose'  => $mDose,
                        'dose_unit'  => $mUnit,
                        'timing'  => $mTiming,
                        'remarks'  => $mRemarks,
                    ];
                }

                if(count($saveMedicines) > 0) {
                    (new IPDOralMedications)->store($saveMedicines, null, true);
                }
            }

            \DB::commit();
            $route   = route('patient.ipd-list');
            $message = lang('messages.created', lang('ipd_master.ipd_visit'));
            return validationResponse(true, 201, $message, $route);
        } catch (\Exception $e) {
            \DB::rollBack();
            return validationResponse(false, 207, lang('messages.server_error'));
        }
    }

    /**
     * Display a listing of the resource.
     *
     * @param null $id
     * @return \Illuminate\Http\Response
     */
    public function printIPDDetail($id = null)
    {
        $result = (new IPDMaster)->getIPDVisitDetail($id);
        if(!is_object($result)) {
            return abort(404);
        }

        $patient = (new PatientRegistration)->getPatientDetail($result->patient_id);

        $pMedicines = (new IPDProcedureTreatments)->getIPDProcedureTreatments(['ipd_id' => $id]);
        $mMedicines = (new IPDOralMedications)->getIPDOralMedicines(['ipd_id' => $id]);

       

        return view('admin.ipd_visits.visit_print', compact('result', 'patient', 'pMedicines', 'mMedicines'));
    }

    /**
     * @param null $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\RedirectResponse|\Illuminate\View\View|void
     */
    public function edit($id = null)
    {
        $result = (new IPDMaster)->getIPDVisitDetail($id);
        if(!is_object($result)) {
            return abort(404);
        }

        if($result->is_discharged == 1) {
            return redirect()->back()->with("error", "IPD patient has been discharged so, editing not allowed now.");
        }


        if (isDoctor() && $result->doctor_id != authUser()->doctor_id) {
            return redirect()->back()->with("error", "Permission denied to access this record.");
        }

        $patient = (new PatientRegistration)->getPatientDetail($result->patient_id);

        $pMedicines = (new IPDProcedureTreatments)->getIPDProcedureTreatments(['ipd_id' => $id]);
        $mMedicines = (new IPDOralMedications)->getIPDOralMedicines(['ipd_id' => $id]);

        $doctors= (new Doctor)->getDoctorList();
        $departments = (new Department)->getDepartmentService();
        $wards = (new WardMaster)->getWardService();
        $beds = (new BedMaster)->getBedService(['not_booked' => 1]);
        $procedures = (new Procedures)->getProcedureService(['main_only' => 1]);
        $medicines = (new Product)->getProductsService();
        return view('admin.ipd_visits.edit', compact('result', 'procedures', 'patient', 'medicines', 'doctors',
            'departments', 'wards', 'beds', 'pMedicines', 'mMedicines'));
    }

    /**
     * @param null $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function updateIPDDetail($id = null)
    {

        $inputs = \Input::all();
        $validator = (new IPDMaster)->validateIPDVisit($inputs);
        if ($validator->fails()) {
            return validationResponse(false, 206, "", "", $validator->messages());
        }

        try
        {
            \DB::beginTransaction();

            $admDate = $inputs['admission_date'] . date(' H:i:s');
            unset($inputs['admission_date']);
            $inputs['admission_date'] = dateFormat('Y-m-d H:i:s', $admDate);

            $inputs['patient_id'] = $inputs['p_id'];
            $inputs['doctor_id'] = $inputs['doctor'];
            $inputs['department_id'] = $inputs['department'];
            $inputs['ward_id'] = $inputs['ward'];
            $inputs['bed_id'] = $inputs['bed'];
            $inputs['updated_by'] = authUserId();
            
            $result = (new IPDMaster)->getIPDVisitDetail($id);
            if ($result->bed_id != $inputs['bed']) {
                (new BedMaster)->store(['is_booked' => 0], $result->bed_id);
                (new BedMaster)->store(['is_booked' => 1], $inputs['bed']);
            }

            (new IPDMaster)->store($inputs, $id);

            $savePTreatment = [];

            if($inputs['addpro'] == 1) 
            {
                $procedureMedicines = (is_array($inputs['procedure_medicine']) && count($inputs['procedure_medicine']) > 0)
                    ? $inputs['procedure_medicine'] : [];

                foreach ($procedureMedicines as $key => $value)
                {
                    $procedure = $inputs['procedure'][$key];
                    $pMedicine = $inputs['procedure_medicine'][$key];
                    $pDose = $inputs['procedure_dose'][$key];
                    $pTiming = $inputs['timing'][$key];
                    $pRemarks = $inputs['remarks'][$key];

                    $procedureId = isset($inputs['pro_id'][$key]) ? $inputs['pro_id'][$key] : 0;

                    if ($procedureId > 0) {
                        $updatePTreatment = [
                            'ipd_master_id' => $id,
                            'procedure_id' => $procedure,
                            //'procedure_date'  => currentDate(true),
                            'procedure_medicine_id' => $pMedicine,
                            'dose' => $pDose,
                            'timing' => $pTiming,
                            'remarks' => $pRemarks,
                        ];
                        (new IPDProcedureTreatments)->store($updatePTreatment, $procedureId);

                    } else {

                        $savePTreatment[] = [
                            'ipd_master_id' => $id,
                            'procedure_id' => $procedure,
                            'procedure_date' => currentDate(true),
                            'procedure_medicine_id' => $pMedicine,
                            'dose' => $pDose,
                            'timing' => $pTiming,
                            'remarks' => $pRemarks,
                        ];

                    }
                }

                $oldProcedures = [];
                $pMedicines = (new IPDProcedureTreatments)->getIPDProcedureTreatments(['ipd_id' => $id]);
                if (is_object($pMedicines)) {
                    $oldProcedures = array_column($pMedicines->toArray(), 'id');
                }

                if (count($savePTreatment) > 0) {
                    (new IPDProcedureTreatments)->store($savePTreatment, null, true);
                }

                $newProcedures = (isset($inputs['pro_id']) && count($inputs['pro_id']) > 0) ? $inputs['pro_id'] : [];

                $deletedProcedures = array_diff($oldProcedures, $newProcedures);
                if (count($deletedProcedures) > 0) {
                    (new IPDProcedureTreatments)->dropProcedures($deletedProcedures);
                }
            }

            if($inputs['addmedi'] == 1)
            {
                $saveMedicines = [];
                $procedureMedicines = (is_array($inputs['medicine']) && count($inputs['medicine']) > 0)
                    ? $inputs['medicine'] : [];

                foreach($procedureMedicines as $key => $value)
                {
                    $mMedicine = $inputs['medicine'][$key];
                    $mDose = $inputs['medicine_dose'][$key];
                    $mUnit = $inputs['medicine_dose_unit'][$key];
                    $mTiming = $inputs['medicine_timing'][$key];
                    $mRemarks = $inputs['medicine_remarks'][$key];

                    $medicineId = isset($inputs['med_id'][$key]) ? $inputs['med_id'][$key] : 0;

                    if ($medicineId > 0)
                    {
                        $updateMedicine = [
                            'ipd_master_id'  => $id,
                            'medicine_id'  => $mMedicine,
                            //'procedure_date'  => currentDate(true),
                            //'medicine_days'  => $pMedicine,
                            'dose'  => $mDose,
                            'dose_unit'  => $mUnit,
                            'timing'  => $mTiming,
                            'remarks'  => $mRemarks,
                        ];
                        (new IPDOralMedications)->store($updateMedicine, $medicineId);


                    } else {

                        $saveMedicines[] = [
                            'ipd_master_id'  => $id,
                            'medicine_id'  => $mMedicine,
                            'procedure_date'  => currentDate(true),
                            //'medicine_days'  => $pMedicine,
                            'dose'  => $mDose,
                            'dose_unit'  => $mUnit,
                            'timing'  => $mTiming,
                            'remarks'  => $mRemarks,
                        ];

                    }
                }

                $oldMedicines = [];
                $mMedicines = (new IPDOralMedications)->getIPDOralMedicines(['ipd_id' => $id]);
                if (is_object($mMedicines)) {
                    $oldMedicines = array_column($mMedicines->toArray(), 'id');
                }
                if(count($saveMedicines) > 0) {
                    (new IPDOralMedications)->store($saveMedicines, null, true);
                }

                $newMedicines = (isset($inputs['med_id']) && count($inputs['med_id']) > 0) ? $inputs['med_id'] : [];
                $deletedMedicines = array_diff($oldMedicines, $newMedicines);
                if (count($deletedMedicines) > 0) {
                    (new IPDOralMedications)->dropMedicines($deletedMedicines);
                }
            }

            \DB::commit();
            $route   = route('patient.ipd-list');
            $message = lang('messages.updated', lang('ipd_master.ipd_visit'));
            return validationResponse(true, 201, $message, $route);
        } catch (\Exception $e) {
            \DB::rollBack();
            return validationResponse(false, 207, lang('messages.server_error'));
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
    public function drop($id)
    {
        if (!\Request::ajax()) {
            //return lang('messages.server_error');
        }

        $result = (new IPDMaster)->getIPDVisitDetail($id);
        if(!is_object($result)) {
            return abort(404);
        }

        if (isDoctor() && $result->doctor_id != authUser()->doctor_id) {
            return redirect()->back()->with("error", "Permission denied to access this visit.");
        }


        try
        {
            $update = ['deleted_by' => authUserId()];
            (new IPDMaster)->store($update, $id);
            (new IPDMaster)->drop($id);
            $response = ['status' => 1, 'message' => lang('messages.deleted', lang('ipd_master.ipd_visit'))];

        } catch (\Exception $exception) {
            $response = ['status' => 0, 'message' => lang('messages.server_error')];
        }
        return json_encode($response);
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function listIPD()
    {
        if (\Request::isMethod('post') && \Request::ajax())
        {
            $inputs = \Input::all();
            $page = 1;
            if (isset($inputs['page']) && (int)$inputs['page'] > 0) {
                $page = $inputs['page'];
            }

            $perPage = 20;
            if (isset($inputs['perpage']) && (int)$inputs['perpage'] > 0) {
                $perPage = $inputs['perpage'];
            }

            if (isDoctor()) {
                $inputs['doctor_id'] = authUser()->doctor_id;
            }

            $start = ($page - 1) * $perPage;
            if (isset($inputs['form-search']) && $inputs['form-search'] != '') {
                $inputs = array_filter($inputs);
                unset($inputs['_token']);
                $data = (new IPDMaster)->getVisits($inputs, $start, $perPage);
                $totalRst = (new IPDMaster)->totalIPDVisits($inputs);
                $total = $totalRst->total;
            } else {

                $data = (new IPDMaster)->getVisits($inputs, $start, $perPage);
                $totalRst = (new IPDMaster)->totalIPDVisits($inputs);
                $total = $totalRst->total;
            }
            return view('admin.ipd_visits.load_data', compact('data', 'total', 'page', 'perPage'));
        }
        return view('admin.ipd_visits.index');
    }

    /**
     * Display a listing of the resource.
     *
     * @param null $id
     * @return \Illuminate\Http\Response
     */
    public function dischargeIPDPatient($id = null)
    {
        $result = (new IPDMaster)->getIPDVisitDetail($id);
        if(!is_object($result)) {
            return abort(404);
        }

        $inputs = \Input::all();
        if (count($inputs) > 0)
        {
            try
            {
                \DB::beginTransaction();
                $validator = (new IPDMaster)->validateIPDDischarge($inputs);
                if ($validator->fails()) {
                    return validationResponse(false, 206, "", "", $validator->messages());
                }

                $disDate = $inputs['discharge_date'] . date(' H:i:s');
                unset($inputs['discharge_date']);
                $inputs['discharge_date'] = dateFormat('Y-m-d H:i:s', $disDate);
                $inputs['is_discharged'] = 1;
                $inputs['discharge_doctor'] = $inputs['doctor'];
                $inputs['updated_by'] = authUserId();

                (new BedMaster)->store(['is_booked' => 0], $result->bed_id);
                (new IPDMaster)->store($inputs, $id);
                \DB::commit();

                $message = "IPD patient discharged successfully.";
                $route   = route('patient.ipd-list');
                return validationResponse(true, 201, $message, $route);

            } catch (\Exception $e) {
                \DB::rollBack();
                return validationResponse(false, 207, lang('messages.server_error'));
            }
        }
        $patient = (new PatientRegistration)->getPatientDetail($result->patient_id);
        $pMedicines = (new IPDProcedureTreatments)->getIPDProcedureTreatments(['ipd_id' => $id]);
        $mMedicines = (new IPDOralMedications)->getIPDOralMedicines(['ipd_id' => $id]);
        $doctors = (new Doctor)->getDoctorList();
        return view('admin.ipd_visits.patient_discharge', compact('result', 'patient', 'doctors',
            'pMedicines', 'mMedicines'));
    }

    /**
     * Display a listing of the resource.
     *
     * @param null $id
     * @param null $pid
     * @return \Illuminate\Http\Response
     */
    public function addProcedureEntry($id = null, $pid = null)
    {
        $result = (new IPDMaster)->getIPDVisitDetail($id);
        if(!is_object($result)) {
            return abort(404);
        }
        $inputs = \Input::all();

        if(count($inputs) > 0)
        {
            if (!isset($inputs['add_procedure'])) {
                return validationResponse(false, 207, "Please select atleast one procedure to add.");
            }
            $validator = (new DailyProcedureVisits)->validateAddProcedureVisit($inputs);
            if ($validator->fails()) {
                return validationResponse(false, 206, "", "", $validator->messages());
            }

            $procedureId = $inputs['pid'];
            $patient_id = $inputs['patient_id'];
            $department_id = $inputs['department_id'];
            $doctor_id = $inputs['doctor_id'];


            $save = [];
            foreach ($inputs['add_procedure'] as $key => $value)
            {
                $pm = explode("##", $key);
                $procedure_id = $pm[0];
                $procedure_medicine_id = $pm[1];
                $procedureRemark = $inputs['procedure_remark'][$key];

                if ($procedureId < 1)
                {
                    $save[] = [
                        'type' => 2,
                        'ipd_master_id' => $id,
                        'patient_id'    => $patient_id,
                        'doctor_id' => $doctor_id,
                        'department_id' => $department_id,
                        'procedure_id' => $procedure_id,
                        'procedure_medicine_id' => $procedure_medicine_id,
                        'procedure_held_date' => currentDate(),
                        'remarks' => $procedureRemark,
                        'created_at' => currentDate(true),
                        'updated_at' => currentDate(true),
                        'created_by' => authUserId(),
                        'updated_by' => authUserId(),
                    ];

                } else {
                    $update = [
                        'remarks' => $procedureRemark,
                    ];
                    (new DailyProcedureVisits)->store($update, $procedureId);
                }

            }
            //dd($save);
            if (count($save) > 0) {
                (new DailyProcedureVisits)->store($save, '', true);
            }

            $htmlcode = "<!DOCTYPE html><html><head><title></title></head><body onload='window.close()'></body></html>";
            return $htmlcode;
            //return validationResponse(true, 201, "Procedure entry successfully saved.",route('patient.opd-procedure-list'));
        }
        $procedure = (new DailyProcedureVisits)->where('id', $pid)->first();
        $pMedicines = (new IPDProcedureTreatments)->getIPDProcedureTreatments(['ipd_id' => $id]);
        return view('admin.ipd_visits.add_procedure_entry', compact('result', 'procedure', 'pMedicines'));
    }
}
