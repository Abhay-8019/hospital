<?php

namespace App\Http\Controllers;

use App\AddTest;
use App\Department;
use App\Doctor;
use App\PatientRegistration;
use App\PatientTest;
use App\PatientTestsDetail;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class PatientTestsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admin/patient-test.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $tests = (new AddTest)->getAddTestService();
        $count = (new PatientTest)->getLastReceiptNo();
        $doctors = (new Doctor)->getDoctorList();
        $departments = (new Department)->getDepartmentService();
        //$patients = [];//(new PatientRegistration)->getPatientsService();
        return view('admin/patient-test.create', compact('tests', 'count', 'doctors', 'departments'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return \Illuminate\Http\Response
     */
    public function store()
    {
        $inputs = \Input::all();
        $validator = (new PatientTest)->validatePatientTest($inputs);
        if ($validator->fails()) {
            return validationResponse(false, 206, "", "", $validator->messages());
        }

        $totalTests = array_filter($inputs['test']);
        if (count($totalTests) < 1) {
            return validationResponse(false, 207, 'Please add atleat one test');
        }

        try {
            \DB::beginTransaction();
            $testSave = [
                'receipt_no'    => $inputs['receipt_no'],
                'hospital_id'   => loggedInHospitalId(),
                'test_date'     => dateFormat('Y-m-d H:i:s', $inputs['test_date']),
                //'report_generate_date' => dateFormat('Y-m-d H:i:s', date('d-m-Y H:i:s')),
                'patient_id'    => $inputs['patient'],
                'doctor_id'    => $inputs['doctor'],
                'department_id'    => $inputs['department'],
                //'deliver_date'  => dateFormat('Y-m-d', $inputs['deliver_date']),
                'created_by'    => authUserId()
            ];
            

            $patientTestId = (new PatientTest)->store($testSave);

           


            $testData = [];
            foreach($inputs['test'] as $key => $id)
            {
                $testId = $inputs['test'][$key];
                $subTestSave = null;
                $subTests = AddTest::find($testId);
                if(is_object($subTests))
                {
                    $subTestIds = $subTests->sub_test_ids;
                    if($subTestIds != "")
                    {
                        $ids = explode(',', $subTestIds);
                        foreach ($ids as $value) {
                            $subTestDetail[$value] = "-";
                        }
                        $subTestSave = json_encode($subTestDetail);
                    }
                }
                $testRate = $inputs['test_rate'][$key];

                if ($testId != "")
                {
                    $testData[] = [
                        'patient_test_id'   => $patientTestId,
                        'sub_tests_result'   => $subTestSave,
                        'test_id'           => $testId,
                        'test_rate'         => $testRate,
                        'created_at'        => new \DateTime
                    ];
                }
            }

            if (count($testData) > 0) {
                (new PatientTestsDetail)->store($testData);
            }

            \DB::commit();
            $lang = lang('messages.created', lang('patient_test.patient_test'));
            $route = route('patient-test.index', $patientTestId);
            return validationResponse(true, 201, $lang, $route);

        } catch (\Exception $exception) {
            \DB::rollBack();
            return validationResponse(false, 207, lang('messages.server_error'));
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $result = PatientTest::find($id);
        if (!$result) {
            abort(404);
        }

        //$patients = [];//(new PatientRegistration)->getPatientsService();
        $patient = PatientRegistration::find($result->patient_id);
        $tests = (new AddTest)->getAddTestService();
        $doctors = (new Doctor)->getDoctorList();
        $departments = (new Department)->getDepartmentService();
        return view('admin/patient-test.edit', compact('result', 'tests', 'patient', 'doctors', 'departments'));
    }

    /**
     * Show the form for editing the specified resource.$subTestDetail[$value] = "-";
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $result = PatientTest::find($id);
        if (!$result) {
            abort(404);
        }
        $patient = PatientRegistration::find($result->patient_id);
        return view('admin/patient-test.show', compact('result', 'patient', 'action'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update($id)
    {
        $result = PatientTest::find($id);
        if (!$result) {
            return redirect()->route('patienttest.index')
                ->with('error', lang('messages.invalid_id', string_manip(lang('patient_test.patient_test'))));
        }

        $inputs = \Input::all();
        $validator = (new PatientTest)->validatePatientTest($inputs);
        if ($validator->fails()) {
            return validationResponse(false, 206, "", "", $validator->messages());
        }

        $totalTests = array_filter($inputs['test']);
        if (count($totalTests) < 1) {
            return validationResponse(false, 207, 'Please add atleat one test');
        }

        try {
            \DB::beginTransaction();
            // delete the old test
            if($inputs['delete_test_id'] != "") {
                (new PatientTestsDetail)->deleteTestsDetail($inputs['delete_test_id']);
            }

            $testSave = [
                'patient_id'    => $inputs['patient'],
                'doctor_id'    => $inputs['doctor'],
                'department_id'    => $inputs['department'],
                'test_date'     => dateFormat('Y-m-d', $inputs['test_date']),
                'updated_by'    => authUserId()
            ];
            $patientTestId = (new PatientTest)->store($testSave, $id);
            $testAddNew = [];
            foreach($inputs['test'] as $key => $id) 
            {
                $testId = $inputs['test'][$key];

                $subTestSave = null;
                $subTests = AddTest::find($testId);
                if(is_object($subTests))
                {
                    $subTestIds = $subTests->sub_test_ids;
                    if($subTestIds != "")
                    {
                        $ids = explode(',', $subTestIds);
                        foreach ($ids as $value) {
                            $subTestDetail[$value] = "-";
                        }
                        $subTestSave = json_encode($subTestDetail);
                    }
                }

                $testRate = $inputs['test_rate'][$key];
                if (isset($inputs['patient_test_id'][$key])) 
                {
                    $testDetailId = $inputs['patient_test_id'][$key];
                    $testData = [
                        'test_id' => $testId,
                        'sub_tests_result' => $subTestSave,
                        'test_rate' => $testRate,
                        'updated_at' => new \DateTime
                    ];
                    (new PatientTestsDetail)->store($testData, $testDetailId);
                    
                } else {
                    
                    if ($testId != "") 
                    {
                        $testAddNew[] = [
                            'patient_test_id' => $patientTestId,
                            'sub_tests_result'   => $subTestSave,
                            'test_id' => $testId,
                            'test_rate' => $testRate,
                            'created_at' => new \DateTime
                        ];
                    }
                }
            }

            if (count($testAddNew) > 0) {
                (new PatientTestsDetail)->store($testAddNew);
            }
            \DB::commit();
            $lang = lang('messages.updated', lang('patient_test.patient_test'));
            $route = route('patient-test.index', $patientTestId);
            return validationResponse(true, 201, $lang, $route);

        } catch (\Exception $exception) {
            \DB::rollBack();
            return validationResponse(false, 207, lang('messages.serveRAJAN PURI r_error'));
        }
    }

    /**
     * Used to load more records and render to view.
     *
     * @param int $pageNumber
     * @return \Illuminate\Http\Response
     */
    public function patientTestsPaginate($pageNumber = null)
    {
        if (!\Request::isMethod('post') && !\Request::ajax()) {
            return lang('messages.server_error');
        }

        $inputs = \Input::all();
        $page = 1;
        if (isset($inputs['page']) && (int)$inputs['page'] > 0) {
            $page = $inputs['page'];
        }

        $perPage = 20;
        if (isset($inputs['perpage']) && (int)$inputs['perpage'] > 0) {
            $perPage = $inputs['perpage'];
        }

        $start = ($page - 1) * $perPage;
        if (isset($inputs['form-search']) && $inputs['form-search'] != '') {
            $inputs = array_filter($inputs);
            unset($inputs['_token']);
            $data = (new PatientTest)->getPatientTest($inputs, $start, $perPage);
            $total = (new PatientTest)->totalPatientTest($inputs);
            echo $total = $total->total;
        } else {
            $data = (new PatientTest)->getPatientTest($inputs, $start, $perPage);
            $total = (new PatientTest)->totalPatientTest($inputs);
            $total = $total->total;
        }

        return view('admin/patient-test.load_data', compact('data', 'total', 'page', 'perPage'));
    }

    /**
     * @param $id
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Http\RedirectResponse|\Illuminate\View\View
     */
    public function generateReport($id = null)
    {
        $result = PatientTest::find($id);
        if (!$result) {
            abort(404);
        }
        $inputs = \Input::all();
        if (count($inputs) > 0)
        {
            $tests = array_filter($inputs['test']);
            //dd($tests);
            $data = [
                'report_generate_date' => dateFormat('Y-m-d', $inputs['test_date'])
            ];
            (new PatientTest)->store($data, $id);
            foreach($tests as $key => $value)
            {
                if(!is_array($value))
                {
                    $testResult = [
                        'test_result' => $value
                    ];
                } else {

                    $subTestValues = json_encode($value);
                    $testResult = [
                        'sub_tests_result' => $subTestValues
                    ];
                    //dd($testResult);
                }
                (new PatientTestsDetail)->updateTestResult($testResult, $key);
            }

            $lang = lang('messages.report_generated');
            //$route = route('patient-test.generate_report', ['id' => $id]);
            $route = route('patient-test.index');
            return validationResponse(true, 201, $lang, $route);

        } else {

            $patient = PatientRegistration::find($result->patient_id);
            $testDetail = (new PatientTestsDetail)->getPatientTests($id);
            $tests = [];
            if (is_object($testDetail)) {
                $tests = array_column($testDetail->toArray(), null, 'id');
            }
            return view('admin/patient-test.report-generate', compact('result', 'patient', 'tests'));
            
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function printReport($id)
    {
        $result = PatientTest::find($id);
        if (!$result) {
            abort(404);
        }
        $patient = PatientRegistration::find($result->patient_id);
        $testDetail = (new PatientTestsDetail)->getPatientTests($id);
        $tests = [];
        if (is_object($testDetail)) {
            $tests = array_column($testDetail->toArray(), null, 'id');
        }
        return view('admin/patient-test.report-print', compact('result', 'patient', 'tests'));
    }
}