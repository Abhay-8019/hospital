<?php

namespace App\Http\Controllers;

use App\Department;
use App\Designation;
use App\Doctor;
use App\DoctorFee;
use App\Rooms;
use App\Specialization;
use App\User;
use Illuminate\Http\Request;

class DoctorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admin.doctor.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $doctorCode = (new Doctor)->getDoctorCode();
        $associationName = lang('common.associationArray');
        $designationName = (new Designation)->getDesignationService();
        $roomName = (new Rooms)->getRoomService();
        $specializationName = (new Specialization)->getSpecializationName();
        $departmentName = (new Department)->getDepartmentService();
        $maritalStatus = lang('common.maritalStatusArr');
        $gender = lang('common.genderArray');
        $days = lang('common.days');
        unset($days['']);
        $dutyType = lang('common.duty_type');
        unset($dutyType['']);
        $bloodGroup = lang('common.bloodGroupArr');
        return view('admin.doctor.create',compact('gender', 'doctorCode', 'maritalStatus', 'dutyType', 'departmentName', 'bloodGroup','days', 'specializationName', 'roomName', 'designationName', 'associationName'));

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $inputs = $request->all();

        $validator = (new Doctor)->validateDoctor($inputs);
        if($validator->fails()){
            return validationResponse(false, '206', "", "", $validator->messages());
        }
        try{
            \DB::beginTransaction();
            unset($inputs['_token']);

            $inputs = $inputs + [
                'created_by' => authUserId(),
                'hospital_id' => loggedInHospitalId()
            ];
            $inputs['date_of_birth'] = ($inputs['date_of_birth'] != '') ? dateFormat('Y-m-d', $inputs['date_of_birth']) : null;
            $inputs['joining_date'] = ($inputs['joining_date'] != '') ? dateFormat('Y-m-d', $inputs['joining_date']) : null;

            $inputs['in_time'] = ($inputs['in_time']!= '')?
                convertToUtc($inputs['in_time'], 'Y-m-d H:i:s') : null;

            $inputs['out_time'] = ($inputs['out_time']!= '')?
                convertToUtc($inputs['out_time'], 'Y-m-d H:i:s') : null;

            $inputs['eve_in_time'] = ($inputs['eve_in_time']!= '')?
                convertToUtc($inputs['eve_in_time'], 'Y-m-d H:i:s') : null;

            $inputs['eve_out_time'] = ($inputs['eve_out_time']!= '')?
                convertToUtc($inputs['eve_out_time'], 'Y-m-d H:i:s') : null;

            $duty = ($inputs['duty_type']);
            $duty = implode(",", $duty);
            $inputs['duty_type'] = $duty;

            $d = ($inputs['days']);
            $days = implode(",", $d);
            $inputs['days'] = $days;

            $doctorId = (new Doctor)->store($inputs);

            $saveInputs = [
                'doctor_id'       => $doctorId,
                'consultation_fee'  => $inputs['consultation_fee'],
                //'outside_consultant_fee' => $inputs['outside_consultant_fee'],
                //'extra_fee'     => $inputs['extra_fee'],
                'wef'           => convertToUtc(),
                'wet'           => null,
                'is_active'     => 1,
            ];
            (new DoctorFee)->store($saveInputs);

            $addUser = [
                'hospital_id' => loggedInHospitalId(),
                'doctor_id' => $doctorId,
                'role_id' => 3,
                'name' => $inputs['name'],
                'username' => $inputs['email'],
                'email' => $inputs['email'],
                'password'      => \Hash::make($inputs['registration_no']),
                'status' => 1,
                'created_by' => authUserId(),
            ];
            (new User)->store($addUser);

            if($request->hasFile('image') && $doctorId > 0)
            {
                $imageName = fileUploader('image', $doctorId);
                $update = ['image'  => $imageName];
                (new Doctor)->store($update, $doctorId);
            }
            \DB::commit();
            $route = route('doctor.index');
            return validationResponse(true, 201, lang('messages.created', lang('doctor.doctor')), $route);
        } catch(\Exception $exception){
            \DB:: Rollback();
            return validationResponse(false, 207, lang('messages.server_error'));
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $result = Doctor::find($id);
        if(!$result){
            abort(404);
        }
        $associationName = lang('common.associationArray');
        $designationName = (new Designation)->getDesignationService();
        $roomName = (new Rooms)->getRoomService();
        $specializationName = (new Specialization)->getSpecializationName();
        $maritalStatus = lang('common.maritalStatusArr');
        $departmentName = (new Department)->getDepartmentService();
        $gender = lang('common.genderArray');
        $bloodGroup = lang('common.bloodGroupArr');
        $search = [
            'doctor_id'   => $id
        ];
        $doctorFee = (new DoctorFee)->getDoctorFee($search);

        $dutyTypeArr = lang('common.duty_type');
        unset($dutyTypeArr['']);
        $dutyType = ($result->duty_type != '')? array_map('intval', explode(',', $result->duty_type)) : null;

        $daysArr = lang('common.days');
        unset($daysArr['']);
        $days = ($result->days != '')? array_map('intval', explode(',', $result->days)) : null;

        return view('admin.doctor.edit', compact('days', 'dutyTypeArr', 'result', 'daysArr', 'doctorFee', 'gender', 'maritalStatus', 'dutyType', 'departmentName', 'bloodGroup','days', 'specializationName', 'roomName', 'designationName', 'associationName'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $result = Doctor :: Find($id);

        if(!$result){
            return validationResponse(false, 206, lang('messages.invalid_id', string_manip(lang('doctor.doctor'))));
        }

        $inputs = $request->except('image');

        $doctorFee=(new DoctorFee)->getEffectedDoctor(true, ['doctor_id' => $id]);
        $validator = (new Doctor)-> validateDoctor($inputs, $id);
        if($validator->fails()){
            return validationResponse(false, 206, "", "", $validator->messages());
        }
        try{
            \DB::beginTransaction();

            $inputs['date_of_birth'] = ($inputs['date_of_birth']!= '')? dateFormat('Y-m-d', $inputs['date_of_birth']) : null;
            $inputs['joining_date'] = ($inputs['joining_date']!= '')? dateFormat('Y-m-d', $inputs['joining_date']) : null;

            $inputs['in_time'] = ($inputs['in_time']!= '')?
                convertToUtc($inputs['in_time'], 'Y-m-d H:i:s') : null;

            $inputs['out_time'] = ($inputs['out_time']!= '')?
                convertToUtc($inputs['out_time'], 'Y-m-d H:i:s') : null;

            $inputs['eve_in_time'] = ($inputs['eve_in_time']!= '')?
                convertToUtc($inputs['eve_in_time'], 'Y-m-d H:i:s') : null;

            $inputs['eve_out_time'] = ($inputs['eve_out_time']!= '')?
                convertToUtc($inputs['eve_out_time'], 'Y-m-d H:i:s') : null;

            $duty = ($inputs['duty_type']);
            $duty = implode(",", $duty);
            $inputs['duty_type']=$duty;

            $d = ($inputs['days']);
            $days = implode(",", $d);
            $inputs['days'] = $days;

            $prevImage = $result->image;

            $inputs =$inputs + [

                'status' => isset($inputs['status']) ? 1 : 0,
                'updated_by' => authUserId()
            ];

            $id=(new Doctor)->store($inputs, $id);

            if($request->hasFile('image') && $id > 0) {
                $imageName = fileUploader('image', $id);
                $update = ['image'  => $imageName];
                (new Doctor)->store($update, $id);

                $fileExist = file_exists(ROOT . \Config::get('constants.UPLOADS') . $prevImage);
                if($prevImage && $fileExist) {
                    unlink(ROOT . \Config::get('constants.UPLOADS') . $prevImage);
                }
            }

            $charges = 0;
            $outside_consultant_fee = 0;
            $extra_fee =0;
            $inputs['doctor_id'] = $id;

            if ($doctorFee) {
                $charges = $doctorFee->consultation_fee;
                $outside_consultant_fee = $doctorFee->outside_consultant_fee;
                $extra_fee = $doctorFee->extra_fee;

                if (($charges > 0 && $charges != $inputs['consultation_fee'])||($outside_consultant_fee > 0 && $outside_consultant_fee != $inputs['outside_consultant_fee'])||($extra_fee > 0 && $extra_fee != $inputs['extra_fee'])) {

                    //update older costs
                    $update = [
                        'is_active' => 0,
                        'wet' => convertToUtc(),
                    ];
                    (new DoctorFee)->store($update, $doctorFee->id);
                    unset($inputs['wet']);
                    //add new costs
                    $inputs['is_active'] = 1;
                    $inputs['wef'] = convertToUtc();
                    (new DoctorFee)->store($inputs);
                }
            } else {
                //add new costs
                $inputs['is_active'] = 1;
                $inputs['wef'] = convertToUtc();
                (new DoctorFee)->store($inputs, $doctorFee->id);
            }
            \DB::commit();
            $route = route('doctor.index');
            return validationResponse(true, 201, lang('messages.updated', lang('doctor.doctor')), $route);
        }catch(\Exception $exception){
            \DB::rollBack();
            return validationResponse(false, 207, $exception->getMessage().' '.lang('messages.server_error'));
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return "In Progress";
    }

    public function doctorToggle($id = null){
        if(!\Request::ajax()){
            return lang('messages.server_error');
        }
        $result = Doctor::find($id);
        try{

            $result->update(['status'=>!$result->status]);
            $response=['status'=>1, 'data'=>(int)$result->status . '.gif'];
            return json_encode($response);
        }catch(\Exception $exception){
            return lang('messages.invalid_id',string_manip(lang('doctor.doctor')));
        }
    }

    public function doctorPaginate(Request $request, $pageNumber = null)
    {
        if (!\Request::isMethod('post') && !\Request::ajax()) {
            return lang('messages.server_error');
        }

        $inputs = $request->all();
        $page = 1;
        if (isset($inputs['page']) && (int)$inputs['page'] > 0) {
            $page = $inputs['page'];
        }

        $perPage = 20;
        if (isset($inputs['perpage']) && (int)$inputs['perpage'] > 0) {
            $perPage = $inputs['perpage'];
        }

        $start = ($page - 1) * $perPage;
        if (isset($inputs['form-search']) && $inputs['form-search'] != '') {
            $inputs = array_filter($inputs);
            unset($inputs['_token']);

            $data = (new Doctor)->getDoctor($inputs, $start, $perPage);
            $totalDoctor = (new Doctor)->totalDoctor($inputs);
            $total = $totalDoctor->total;
        } else {

            $data = (new Doctor)->getDoctor($inputs, $start, $perPage);
            $totalDoctor = (new Doctor)->totalDoctor($inputs);
            $total = $totalDoctor->total;
        }

        return view('admin.doctor.load_data', compact('data', 'total', 'page', 'perPage'));
    }
}
