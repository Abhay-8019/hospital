<?php
namespace App;
/**
 * :: Procedure Treatment Master Model ::
 * To manage Procedure Treatment Master CRUD operations
 *
 **/

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Response;

class IPDOralMedications extends Model
{
    use SoftDeletes;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'ipd_oral_medicines';

    /**
     * The attributes that are mass assignable.
     * @var array
     */
    protected $fillable = [
        'ipd_master_id',
        'medicine_id',
        'procedure_date',
        //'medicine_days',
        'dose',
        'dose_unit',
        'timing',
        'remarks',
        'is_active',
        'deleted_by',
    ];

    public $timestamps = false;

    /**
     * Method is used to save/update resource.
     *
     * @param   array $input
     * @param   int $id
     * @param bool $multiple
     * @return Response
     */
    public function store($input, $id = null, $multiple = false)
    {
        if ($id) {
            return $this->find($id)->update($input);
        } else {
            if($multiple) {
                return $this->insert($input);
            }
            return $this->create($input)->id;
        }
    }

    /**
     * Method is used to search news detail.
     *
     * @param array $search
     * @return mixed
     */
    public function getIPDOralMedicines($search = [])
    {
        $filter = 1; // default filter if no search

        $fields = [
            'ipd_oral_medicines.*',
            'product.product_name as medicine',
        ];

        $orderEntity = 'id';
        $orderAction = 'desc';

        if (is_array($search) && count($search) > 0)
        {
            $filter .= (array_key_exists('ipd_id', $search) && $search['ipd_id'] != "") ?
                " AND (ipd_oral_medicines.ipd_master_id = " . addslashes(trim($search['ipd_id'])) . ")" : "";
        }

        return $this
            ->leftJoin('product', 'product.id', 'ipd_oral_medicines.medicine_id')
            ->whereRaw($filter)
            ->orderBy($orderEntity, $orderAction)
            ->get($fields);
    }

    /**
     * @param $pIds
     * @return bool
     */
    public function dropMedicines($mIds)
    {
        return $this->whereIn('id', $mIds)->update(['deleted_by' => authUserId(), 'deleted_at' => currentDate(true)]);
    }
}