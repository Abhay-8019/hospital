<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PatientTestsDetail extends Model
{

    /**
     * The database table used by the model.
     * @var string
     */
    protected $table = 'patient_tests_detail';

    /**
     * The attributes that are mass assignable.
     * @var array
     */
    protected $fillable = [
        'patient_test_id',
        'test_id',
        'test_rate',
        'test_result',
        'sub_tests_result',
        'test_date'
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function patientTest()
    {

        return $this->belongsTo('App\PatientTest');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function diagnostics()
    {
        return $this->hasOne('App\AddTest', 'id', 'test_id');
    }

    /**
     * @param array $inputs
     * @param int $id
     *
     * @return mixed
     */
    public function store($inputs, $id = null)
    {
        if ($id) {
            $this->find($id)->update($inputs);
        } else {
            $this->insert($inputs);
        }
    }

    /**
     * @param $ids
     */
    public function deleteTestsDetail($ids)
    {
        $testIds = explode(',', $ids);
        $testIds = array_unique(array_filter($testIds));
        if (count($testIds) > 0) {
            $this->whereIn('id', $testIds)->delete();
        }
    }

    /**
     * @param $id
     *
     * @return mixed
     */
    public function getPatientTests($id)
    {
        return $this->where('patient_test_id', $id)->get();
            //->pluck('test_id', \DB::raw('CONCAT_WS(",",id,test_result) result'))
            //->toArray();
    }

    /**
     * @param $data
     * @param $id
     */
    public function updateTestResult($data, $id)
    {
        $this->find($id)->update($data);
    }

    /**
     * @param array $search
     * @return int|string
     */
    public function getFilters($search = [])
    {
        $filter = 1; // default filter if no search
        if (is_array($search) && count($search) > 0)
        {
            $filter .= (array_key_exists('test', $search) && $search['test'] != "") ? " AND (patient_tests_detail.test_id = '" .
                addslashes($search['test']) . "')" : "";

            $filter .= (array_key_exists('doctor', $search) && $search['doctor'] != "") ? " AND (patient_test.doctor_id = '" .
                addslashes($search['doctor']) . "')" : "";

            $filter .= (array_key_exists('department', $search) && $search['department'] != "") ? " AND (patient_test.department_id = '" .
                addslashes($search['department']) . "')" : "";


            if (array_key_exists('from_date', $search) && $search['from_date'] != "" &&
                array_key_exists('to_date', $search) && $search['to_date'] == "")
            {
                $date = dateFormat("Y-m-d", $search['from_date']);
                $filter .=  " AND (patient_test.test_date >= '" . addslashes(trim($date)) . "')";
            }

            if (array_key_exists('from_date', $search) && $search['from_date'] != "" &&
                array_key_exists('to_date', $search) && $search['to_date'] != "" && $search['report_type'] == '1'
            )
            {
                $from = dateFormat("Y-m-d", $search['from_date'] . ' 00:00');
                $to = dateFormat("Y-m-d", $search['to_date'] . ' 23:59');
                $filter .= " AND (patient_test.test_date between '" . addslashes(trim($from)) . "' and '" . addslashes(trim($to)) . "') ";
            }
        }
        return $filter;
    }

    /**
     * @param array $search
     * @return \Illuminate\Support\Collection
     */
    public function patientTestSummary($search = [])
    {

        $filter = $this->getFilters($search);

        if (isset($search['form-search']))
        {
            return $this->leftJoin('patient_test', 'patient_tests_detail.patient_test_id', '=', 'patient_test.id')
                ->leftJoin('patient_registration', 'patient_registration.id', '=', 'patient_test.patient_id')
                ->leftJoin('doctor', 'doctor.id', '=', 'patient_test.doctor_id')
                ->leftJoin('department', 'department.id', '=', 'patient_test.department_id')
                ->whereRaw($filter)
                ->orderBy('patient_test.id', 'ASC')
                ->groupBy('patient_test.id')
                ->get(
                    [
                        'patient_test.receipt_no',
                        'patient_test.test_date',
                        \DB::raw('SUM(patient_tests_detail.test_rate) as total'),

                        'patient_registration.first_name',
                        'patient_registration.age',
                        'patient_registration.blood_group',
                        'patient_registration.mobile',

                        'doctor.name as doctor',
                        'department.name as department',
                    ]
                );
        }
        return null;
    }
}
