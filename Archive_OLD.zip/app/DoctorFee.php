<?php

namespace App;

/**
 * :: DoctorFee Model ::
 * To manage DoctorFee CRUD operations
 *
 **/

use Illuminate\Database\Eloquent\Model;

class DoctorFee extends Model
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'doctor_fee';
    public    $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'doctor_id',
        'consultation_fee',
        'outside_consultant_fee',
        'extra_fee',
        'wef',
        'wet',
        'is_active',
    ];

    /**
     * Scope a query to only include active users.
     *
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query)
    {
        return $query->where(['is_active' => 1]);
    }

    /**
     * @param $doctorId
     * @return mixed
     */
    public function findBy($doctorId)
    {
        return $this->active()->where(['doctor_id' => $doctorId])->first();
    }
    /**
     * Method is used to save/update resource.
     *
     * @param   array $input
     * @param   int $id
     * @return  Response
     */
    public function store($input, $id = null)
    {
        if ($id) {
            return $this->find($id)->update($input);
        } else {
            return $this->create($input)->id;
        }
    }
    /**
     * Method is used to search news detail.
     *
     * @param array $search
     *
     * @param bool $active
     * @return mixed
     */
    public function getEffectedDoctor($active = true, $search = [])
    {
        $filter = 1;
        if (is_array($search) && count($search) > 0) {
            $doctor = (array_key_exists('doctor_id', $search)) ? " AND doctor_id = '" .
                addslashes(trim($search['doctor_id'])) . "'" : "";
            $filter .= $doctor;

            $from = (array_key_exists('from', $search)) ? " AND wef = '" .
                addslashes(trim($search['from'])) . "' " : "";
            $filter .= $from;
        }

        if ($active) {
            $active = " AND is_active = 1";
            $filter .= $active;
        }
        return $this->whereRaw($filter)->first();
    }
    /**
     * Method is used to get effected doctor cost.
     * @param array $search
     * @param bool $active
     * @return mixed
     */
    public function getEffectedDoctorCost($id, $date)
    {
        return $this->where('doctor_id', $id)
            ->where(function($query) use ($date) {
                $query->where(function($inner) use ($date) {
                    $inner->where('wef', '<=', $date)
                        ->where('wet', '>=', $date);
                });
                $query->oRWhere(function($inner) use ($date) {
                    $inner->where('wef', '<=', $date)
                        ->whereNull('wet');
                });
            })->first();
    }

    public function getDoctorFee($search = [])
    {
        // default filter if no search
        $filter = 1;

        $fields = [
            'doctor_id',
            'consultation_fee',
            'outside_consultant_fee',
            'extra_fee',
            'wef',
            'wet',
            'is_active',
        ];

        if (is_array($search) && count($search) > 0) {
            if(array_key_exists('keyword', $search) && $search['keyword'] != '') {
                $filter .= " AND doctor_fee LIKE '%" . addslashes(trim($search['keyword'])) . "%' ";
            }
            if (array_key_exists('doctor_id', $search) && $search['doctor_id'] != "") {
                $filter .= " AND doctor_id = '" . addslashes(trim($search['doctor_id'])) . "'";
            }
        }
        return $this
            ->whereRaw($filter)
            ->orderBy('id', 'ASC')->first($fields);
    }
}
