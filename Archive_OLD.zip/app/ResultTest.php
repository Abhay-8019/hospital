<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ResultTest extends Model
{
    use SoftDeletes;

    protected $table = 'result_test';

    protected $fillable = [
        'id',
        'hospital_id',
        'patient_registration_id',
        'add_test_id',
        'result',
        'description',
        'status',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    public function scopeResultTestHospital($query)
    {
        return (!isSuperAdmin())?
            $query->where('result_test.hospital_id', loggedInHospitalId()) : null;
    }

    public function scopeActive($query)
    {
        return $query->where(['status' => 1]);
    }

    public function store($inputs, $id= null)
    {
        if($id){
            $this->find($id)->update($inputs);
        } else {
            $this->create($inputs)->id;
        }
    }

    public function validateResultTest($inputs, $id=null){
        if($id){
            $rules['patient_registration_id'] ='required:result_test,patient_registration_id,'. $id .',id,deleted_at,NULL,hospital_id,'.loggedInHospitalId();
            $rules['add_test_id'] ='required:result_test,add_test_id,'. $id .',id,deleted_at,NULL,hospital_id,'.loggedInHospitalId();
        } else {
            $rules['patient_registration_id'] ='required:result_test,patient_registration_id,NULL,id,deleted_at,NULL,hospital_id,'.loggedInHospitalId();
            $rules['add_test_id'] ='required:result_test,add_test_id,NULL,id,deleted_at,NULL,hospital_id,'.loggedInHospitalId();
        }
        $rules['result'] ='required';
        return \Validator::make($inputs, $rules);
    }

    public function getResultTest($search = null, $skip, $perPage)
    {
        $take = ((int)$perPage > 0) ? $perPage : 20;
        // default filter if no search
        $filter = 1;

        $fields = [
            'result_test.id',
            'result_test.patient_registration_id',
            'result_test.add_test_id',
            'result_test.result',
            'result_test.status',
            'add_test.name as test_name',
            'patient_registration.first_name as first_name',
            'patient_registration.last_name as last_name',
        ];
        /**
         *
         */
        if (is_array($search) && count($search) > 0) {
            $partyName = (array_key_exists('keyword', $search)) ? " AND patient_registration_id LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' " : "";
            $filter .= $partyName;
        }
        return $this
            ->leftJoin('add_test', 'add_test.id', '=', 'result_test.add_test_id')
            ->leftJoin('patient_registration', 'patient_registration.id', '=', 'result_test.patient_registration_id')
            ->whereRaw($filter)
            ->where('result_test.hospital_id', loggedInHospitalId())
            ->orderBy('id', 'ASC')
            ->skip($skip)->take($take)->get($fields);
    }

    public function totalResultTest($search = null)
    {
        $filter = 1; // if no search add where

        // when search
        if (is_array($search) && count($search) > 0) {
            $partyName = (array_key_exists('patient_id', $search)) ? " AND result_test.patient_id LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' " : "";
            $filter .= $partyName;
        }
        return $this->select(\DB::raw('count(*) as total'))
            ->whereRaw($filter)->first();
    }
}
