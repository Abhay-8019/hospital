<?php

namespace App;

/**
 * :: Rooms Model ::
 * To manage Rooms CRUD operations
 *
 **/

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Rooms extends Model
{
    use SoftDeletes;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'rooms';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'hospital_id',
        'floor_id',
        'room_code',
        'room_name',
        'room_type',
        'status',
        'created_by',
        'updated_by',
        'deleted_by',
    ];
    /**
     * Scope a query to only include active users.
     *
     * @param $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query)
    {
        return $query->where('status', 1);
    }
    /**
     * @param $query
     * @return null
     */
    public function scopeRoomHospital($query)
    {
        return (!isSuperAdmin())?
            $query->where('rooms.hospital_id', loggedInHospitalId()) : null;
    }
    /**
     * Method is used to validate roles
     *
     * @param $inputs
     * @param int $id
     * @return Response
     */
    public function validateRoom($inputs, $id = null, $isArray =false)
    {
        $inputs = array_filter($inputs);
        $message =[];
        // validation rule
        if($isArray){
           if(isset($inputs['room_name']) && isset($inputs['room_code']) && isset($inputs['room_type']) && isset($inputs['room_charges'])){
               foreach($inputs['room_name'] as $key => $value)
               {
                   $message = [
                     'room_name required'        => lang('messages.product_required'),
                     'room_code required'        => lang('messages.quantity_required'),
                     'room_type required'        => lang('messages.quantity_required'),
                     'room_charges required'     => lang('messages.quantity_required'),

                   ];
                   $rules['room_name.' .$key]       = 'required:rooms,room_name,NULL,id,deleted_at,NULL,hospital_id,'.loggedInHospitalId();
                   $rules['room_code.' .$key]       = 'required:rooms,room_code,NULL,id,deleted_at,NULL,hospital_id,'.loggedInHospitalId();
                   $rules['room_type.' .$key]       = 'required';
                   $rules['room_charges.' .$key]    = 'required';
               }
           }
        } else {
        if ($id) {
            $rules['room_name'] = 'required|unique:rooms,room_name,' . $id .',id,deleted_at,NULL,hospital_id,'.loggedInHospitalId();
            $rules['room_code'] = 'required|unique:rooms,room_code,' . $id .',id,deleted_at,NULL,hospital_id,'.loggedInHospitalId();
        } else {
            $rules['room_name'] = 'required|unique:rooms,room_name,NULL,id,deleted_at,NULL,hospital_id,'.loggedInHospitalId();
            $rules['room_code'] = 'required|unique:rooms,room_code,NULL,id,deleted_at,NULL,hospital_id,'.loggedInHospitalId();
            $rules['status']    = 'required';
        }
        $rules['floor']        =  'required|numeric';
        $rules['room_charges'] =  'required|numeric|min:1';
        }

        return \Validator::make($inputs, $rules, $message);
    }
    /**
     * Method is used to save/update resource.
     *
     * @param   array $input
     * @param   int $id
     * @return  Response
     */
    public function store($input, $id = null, $isMultiple = false)
    {
        if ($id) {
            return $this->find($id)->update($input);
        } else {
            if($isMultiple){
                return $this->insert($input);
            }else{
                return $this->create($input)->id;
        }
        }
    }

    /**\
     * @param null $code
     * @return mixed|string
     */
    public function getRoomCode($code = null)
    {
        $result =  $this->roomHospital()->where('room_code', $code)->first();
        if ($result) {
            $data =  $this->roomHospital()->orderBy('id', 'desc')->take(1)->first(['room_code']);
        } else {
            $data =  $this->roomHospital()->orderBy('id', 'desc')->take(1)->first(['room_code']);
        }

        if (count($data) == 0) {
            $number = 'R-01';
        } else {
            $number = number_inc($data->room_code); // new room_code increment by 1
        }
        return $number;
    }

    /**
     * Method is used to search news detail.
     *
     * @param array $search
     * @param int $skip
     * @param int $perPage
     *
     * @return mixed
     */
    public function getRoom($search = null, $skip, $perPage)
    {
        $take = ((int)$perPage > 0) ? $perPage : 20;
        // default filter if no search
        $filter = 1;

        $fields = [
            'rooms.id',
            'rooms.hospital_id',
            'rooms.floor_id',
            'rooms.room_code',
            'rooms.room_name',
            'rooms.room_type',
            'rooms.status',
            'floor.name as floor_name',
            'room_costs.room_charges',
        ];

        if (is_array($search) && count($search) > 0) {
            $partyName = (array_key_exists('keyword', $search)) ? " AND room_name LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' " : "";
            $filter .= $partyName;
        }
        return $this->leftJoin('floor', 'floor.id', '=', 'rooms.floor_id')
            ->leftJoin('room_costs', 'room_costs.room_id', '=', \DB::Raw('rooms.id and is_active = 1'))
            ->whereRaw($filter)
            ->where('rooms.hospital_id', loggedInHospitalId())
            ->orderBy('id', 'ASC')
            ->skip($skip)->take($take)->get($fields);
    }
    /**
     * Method is used to get total results.
     *
     * @param array $search
     *
     * @return mixed
     */
    public function totalRoom($search = null)
    {
        $filter = 1; // if no search add where

        // when search
        if (is_array($search) && count($search) > 0) {
            $partyName = (array_key_exists('name', $search)) ? " AND room_name LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' " : "";
            $filter .= $partyName;
        }
        return $this->select(\DB::raw('count(*) as total'))
            ->whereRaw($filter)->first();
    }

    /**
     * @return mixed
     */
    public function getRoomService()
    {
        $result = $this->active()
            ->roomHospital()
            ->pluck('room_name', 'id')->toArray();
        return ['' => '-- Select Room --'] + $result;
    }
}
