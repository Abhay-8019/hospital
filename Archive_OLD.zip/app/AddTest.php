<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AddTest extends Model
{
    use SoftDeletes;


    protected $table = 'add_test';

    protected $fillable = [
        'id',
        'hospital_id',
        'test_category_id',
        'sub_test_ids',
        'name',
        'minval',
        'maxval',
        'cost',
        'description',
        'status',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    /**
     * @param $query
     * @return mixed
     */
    public function scopeActive($query)
    {
        return $query->where(['status' => 1]);
    }

    /**
     * @param $query
     * @return null
     */
    public function scopeAddTestHospital($query)
    {
        return (!isSuperAdmin()) ?
            $query->where('add_test.hospital_id', loggedInHospitalId()) : null;
    }

    /**
     * @param $inputs
     * @param null $id
     */
    public function store($inputs, $id= null){
       if($id){
           $this->find($id)->update($inputs);
       } else {
           $this->create($inputs)->id;
       }
    }

    /**
     * @param $inputs
     * @param null $id
     * @return mixed
     */
    public function validateAddTest($inputs, $id=null)
    {
        if($id){
            $rules['name'] ='required|alpha_spaces|unique:add_test,name,'. $id .',id,deleted_at,NULL,hospital_id,'.loggedInHospitalId();
            //$rules['description'] ='required:add_test,description,'. $id .',id,deleted_at,NULL,hospital_id,'.loggedInHospitalId();
        } else {
            $rules['name'] ='required|alpha_spaces|unique:add_test,name,NULL,id,deleted_at,NULL,hospital_id,'.loggedInHospitalId();
            //$rules['description'] ='required:add_test,description,NULL,id,deleted_at,NULL,hospital_id,'.loggedInHospitalId();
        }
        $rules['cost'] ='required|numeric';
        $rules['test_category'] ='required';
        return \Validator::make($inputs, $rules);
    }

    /**
     * @param null $search
     * @param $skip
     * @param $perPage
     * @return \Illuminate\Support\Collection
     */
    public function getAddTest($search = null, $skip, $perPage)
    {
        $take = ((int)$perPage > 0) ? $perPage : 20;
        // default filter if no search
        $filter = 1;

        $fields = [
            'id',
            'name',
            'cost',
            'minval',
            'maxval',
            'status',
        ];
        /**
         *
         */
        if (is_array($search) && count($search) > 0)
        {
            $filter .= (array_key_exists('keyword', $search)) ? " AND name LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' " : "";
        }
             return $this->whereRaw($filter)
                 ->where('add_test.hospital_id', loggedInHospitalId())
                 ->orderBy('id','ASC')->skip($skip)->take($take)->get($fields);
    }

    /**
     * @param null $search
     * @return Model|null|static
     */
    public function totalAddTest($search = null)
    {
        $filter = 1; // if no search add where

        // when search
        if (is_array($search) && count($search) > 0)
        {
            $filter .= (array_key_exists('name', $search)) ? " AND add_test.name LIKE '%" .
                addslashes(trim($search['keyword'])) . "%' " : "";
        }
        return $this->select(\DB::raw('count(*) as total'))
            ->whereRaw($filter)->first();
    }

    /**
     * @param bool $label
     * @return array
     */
    public function getAddTestService($label = true)
    {
        $result = $this->active()
            ->addTestHospital()
            ->pluck('name', 'id')
            ->toArray();

        if ($label) {
            return ['' => '-Select Test-'] + $result;
        }
        return $result;
    }

    /**
     * @param array $search
     * @return Model|null|static
     */
    public function getTestName($search = [])
    {
        $filter = 1;
        if (is_array($search) && count($search) > 0)
        {
            $filter .= (array_key_exists('id', $search)) ? " AND add_test.id = '" .
                addslashes(trim($search['id'])) . "' " : "";
        }
        return $this->whereRaw($filter)->first();
    }
}
